# Comprehensive Architectural & Implementation Plan: WebAuthn Passkey Authentication Subsystem

## Goal Description
Implement the complete production-grade WebAuthn Passkey authentication subsystem for Kosh on a dedicated Trunk-Based Development branch (`feat/passkey-auth`).

Following the completion of Root Envelope Encryption and Recovery Rotation (Milestone 1), this plan defines the implementation of:
1. **Relying Party Configuration & Test Ergonomics:** Adding KDL fields (`rp_id`, `rp_origin`, `rp_name`) with non-breaking test fallbacks in `AppStateBuilder`.
2. **Lossless User Identifier Projection:** Zero-loss mathematical bijection mapping SQLite `user_id: i64` to WebAuthn `Uuid` user handles without secondary tables or O(N) database scans.
3. **Protected Passkey Registration:** Enrolling hardware authenticators (FaceID, TouchID, YubiKey, Windows Hello) with client-encrypted metadata labels.
4. **1-Touch Biometric Login (Discoverable / Resident Keys):** True passwordless, email-free login returning both an active Bearer session token and the 60-byte encrypted root vault key envelope.
5. **Credential Management & Model Hardening:** Full CRUD unit test coverage for `model::passkey::Record`, credential listing, and single-passkey revocation.
6. **Low-Resource Hardware Efficiency:** Zero disk I/O on ceremony start endpoints to protect mechanical HDD spindles and flash media on low-power devices (Raspberry Pi / 512MB RAM VPS).

---

## User Review Required

> [!IMPORTANT]
> **Lossless Mathematical Projection (`UserId` <-> `Uuid`):**
> WebAuthn Level 3 specifications require a 16-byte user handle (`user.id`). Kosh identifies users internally via `user_id: i64` (`users.id`).
> Instead of one-way hashing (e.g. UUIDv5, which cannot be reversed during discoverable login without an O(N) database scan), a positive 64-bit integer fits losslessly into a 128-bit UUID:
> - Forward: `Uuid::from_u128(u128::from(u64::try_from(user_id)?))`
> - Reverse: `i64::try_from(uuid.as_u128())?`
> This is an O(1) mathematical bijection: zero database seeking, zero heap allocations, 100% reversible, and strictly free of `as` casts (`-D clippy::as_conversions`).

> [!IMPORTANT]
> **Non-Breaking `AppStateBuilder` Test Fallbacks:**
> `AppStateBuilder::new()` is instantiated across 14 existing unit and integration test suites. To prevent breaking existing test harnesses, `AppStateBuilder::build()` will automatically provide fallback local development defaults (`"localhost"`, `"http://localhost:6969"`, `"Kosh Vault"`) if `webauthn` is not explicitly set.

> [!NOTE]
> **TBD Branch Scope Boundary:**
> This branch (`feat/passkey-auth`) is strictly focused on WebAuthn passkey registration, discoverable resident login, credential management, and Relying Party configuration.
> The Ephemeral ECDH Blind Mailbox Relay (`/api/v1/devices/mailbox`) for cross-device QR code key sync remains deferred to the subsequent branch (`feat/ecdh-mailbox`).

---

## Architecture & Ceremony Sequence

```mermaid
sequenceDiagram
    autonumber
    actor User as User / Browser
    participant API as Kosh Server
    participant Cache as Moka (RAM)
    participant DB as SQLite (Disk)

    Note over User,DB: Phase 1: Passkey Registration (Authenticated)
    User->>API: POST /api/v1/auth/passkey/register/start (Bearer token)
    API->>DB: SELECT credential_id FROM webauthn_credentials WHERE user_id = ?
    DB-->>API: List of registered creds (exclude_credentials)
    API->>API: webauthn.start_passkey_registration(user_handle, ...)
    API->>Cache: Store (challenge_id -> PasskeyRegistration) [TTL 60s]
    API-->>User: 200 OK { challenge_id, creation_challenge }
    User->>User: navigator.credentials.create(creation_challenge)
    User->>API: POST /api/v1/auth/passkey/register/finish { challenge_id, credential, encrypted_metadata }
    API->>Cache: Remove challenge_id (Single-use atomic eviction)
    API->>API: webauthn.finish_passkey_registration(...)
    API->>DB: INSERT INTO webauthn_credentials (credential_id, user_id, passkey_data, counter, encrypted_metadata)
    API-->>User: 201 Created

    Note over User,DB: Phase 2: 1-Touch Passkey Login (Unauthenticated, Discoverable)
    User->>API: POST /api/auth/passkey/login/start (Rate-limited to 2 req/s)
    API->>API: webauthn.start_discoverable_authentication()
    API->>Cache: Store (challenge_id -> DiscoverableAuthentication) [TTL 60s]
    API-->>User: 200 OK { challenge_id, request_challenge } [Zero Disk I/O]
    User->>User: navigator.credentials.get(request_challenge)
    User->>API: POST /api/auth/passkey/login/finish { challenge_id, credential }
    API->>Cache: Remove challenge_id (Single-use atomic eviction)
    API->>API: identify_discoverable_authentication(credential) -> (user_handle, cred_id)
    API->>DB: SELECT * FROM webauthn_credentials WHERE credential_id = ?
    DB-->>API: passkey_data, counter, user_id
    API->>API: finish_discoverable_authentication(...) & Clone detection check
    API->>DB: UPDATE webauthn_credentials SET counter = ?, last_used = ?
    API->>DB: SELECT wrapped_vault_key FROM users WHERE id = user_id (User::find_by_id)
    DB-->>API: wrapped_vault_key
    API->>DB: INSERT INTO sessions ... (Session::create)
    API-->>User: 200 OK { token, wrapped_vault_key }
```

---

## Proposed Changes

### 1. Dependencies & Configuration

#### [MODIFY] `crates/server/Cargo.toml`
- Add dependencies:
  ```toml
  webauthn-rs = { version = "0.5.5", features = ["conditional-ui", "workaround-google-passkey-specific-issues"] }
  url = "2.5"
  ```

#### [MODIFY] `crates/core/src/config/mod.rs`
- Add Relying Party configuration fields to `Config`:
  ```rust
  /// WebAuthn Relying Party identifier (domain or hostname, e.g. "localhost").
  #[knuffel(child, unwrap(argument), default = "localhost".to_string())]
  pub rp_id: String,

  /// WebAuthn Relying Party Origin URL (e.g. "http://localhost:6969").
  #[knuffel(child, unwrap(argument), default = "http://localhost:6969".to_string())]
  pub rp_origin: String,

  /// WebAuthn Relying Party human-readable display name.
  #[knuffel(child, unwrap(argument), default = "Kosh Vault".to_string())]
  pub rp_name: String,
  ```
- Update default template in `Config::load_or_init()`.
- Add parsing tests in `crates/core/src/config/test.rs`.

---

### 2. Database Model Layer

#### [MODIFY] `crates/server/src/model/user.rs`
- Implement `User::find_by_id(pool: &SqlitePool, id: i64) -> Result<Option<Verified>>` to look up users and their `wrapped_vault_key` directly by `user_id`.

#### [MODIFY] `crates/server/src/model/test.rs`
- Add unit tests for `User::find_by_id`.
- Add comprehensive CRUD unit test suite for `crates/server/src/model/passkey.rs`:
  - Record creation and roundtrip lookup.
  - User passkey listing with newest-first ordering.
  - Signature counter update and timestamp advancement.
  - Per-user isolated deletion.
  - Foreign key and check constraint violations.

---

### 3. Application State & Moka Challenge Caches

#### [MODIFY] `crates/server/src/app/state.rs`
- Add fields to `State`:
  ```rust
  pub webauthn: Arc<webauthn_rs::Webauthn>,
  pub passkey_registration_cache: moka::future::Cache<Uuid, (i64, webauthn_rs::prelude::PasskeyRegistration)>,
  pub passkey_auth_cache: moka::future::Cache<Uuid, webauthn_rs::prelude::DiscoverableAuthentication>,
  ```

#### [MODIFY] `crates/server/src/app/builder.rs`
- Add `.webauthn(...)` builder method.
- In `build()`, instantiate 60-second TTL Moka caches with 1,000 maximum entry bounds.
- If `webauthn` is not provided, fall back to `"localhost"` / `"http://localhost:6969"` default instance so all 14 existing test suites compile without modifications.

#### [MODIFY] `crates/server/src/main.rs`
- Build `Webauthn` instance from `config.rp_id`, `config.rp_origin`, and `config.rp_name` during server bootstrap.

---

### 4. API Layer & Ingress Routing

#### [MODIFY] `crates/server/src/api/error.rs`
- Add `Webauthn(#[from] webauthn_rs::prelude::WebauthnError)` to `api::Error`.
- Map `Webauthn` in `IntoResponse` to `(StatusCode::BAD_REQUEST, "Passkey ceremony failed")`.
- Map to `Level::Warning` under `Module::Api` in `Loggable`.

#### [NEW] `crates/server/src/api/auth/passkey/mod.rs`
- Module entrypoint exposing `register`, `login`, and `manage`.

#### [NEW] `crates/server/src/api/auth/passkey/register.rs`
- `register_start`:
  - Authenticated via `Extension(user_id)`.
  - Queries existing passkeys to build `exclude_credentials`.
  - Converts `user_id` to `Uuid` handle via `user_id_to_handle`.
  - Calls `webauthn.start_passkey_registration`.
  - Stores challenge in `passkey_registration_cache`.
  - Returns `200 OK { challenge_id, challenge }`.
- `register_finish`:
  - Authenticated via `Extension(user_id)`.
  - Pops `(cached_user_id, challenge)` from `passkey_registration_cache`.
  - Verifies registration via `webauthn.finish_passkey_registration`.
  - Serializes `Passkey` and inserts `PasskeyRecord` into SQLite.
  - Returns `201 Created`.

#### [NEW] `crates/server/src/api/auth/passkey/login.rs`
- `login_start`:
  - Unauthenticated, rate limited to 2 req/s by `with_auth_ip_limit`.
  - Calls `webauthn.start_discoverable_authentication()`.
  - Stores challenge in `passkey_auth_cache`.
  - Returns `200 OK { challenge_id, challenge }` (Zero disk I/O).
- `login_finish`:
  - Unauthenticated, rate limited to 2 req/s.
  - Pops challenge from `passkey_auth_cache`.
  - Identifies credential ID via `webauthn.identify_discoverable_authentication`.
  - Fetches passkey record from SQLite using `credential_id`.
  - Verifies signature, advances signature counter, and checks clone detection.
  - Updates counter and last-used timestamp in SQLite.
  - Fetches `wrapped_vault_key` via `User::find_by_id`.
  - Issues bearer token via `Session::create`.
  - Returns `200 OK { token, wrapped_vault_key }`.

#### [NEW] `crates/server/src/api/auth/passkey/manage.rs`
- `list`: Authenticated `GET /api/v1/auth/passkey` returning `Vec<Summary>`.
- `delete`: Authenticated `DELETE /api/v1/auth/passkey/{credential_id}`.

#### [MODIFY] `crates/server/src/api/route.rs`
- Mount `/passkey/login/*` in `auth_route` with `with_auth_ip_limit`.
- Mount `/auth/passkey/*` in `protected_routes` with `auth_guard`, `with_device_limit`, and `mac_guard`.

---

## Verification Plan

### Automated Tests
1. **Model Tests (`crates/server/src/model/test.rs`):**
   - Full CRUD unit tests for `model::passkey::Record`.
   - `User::find_by_id` verification.
2. **WebAuthn Ceremony Tests (`crates/server/src/api/auth/passkey/test.rs`):**
   - Registration start and finish roundtrip with mock authenticator.
   - 1-touch discoverable login asserting both bearer token generation and `wrapped_vault_key` return.
   - Replay defense test (asserting challenge eviction after single use).
   - Expired challenge rejection after 60-second TTL.
   - Passkey listing and revocation tests.
3. **Workspace Gate:**
   ```bash
   cargo test --workspace
   cargo clippy --workspace --all-targets -- -D warnings
   cargo fmt --check
   ```

### Manual Verification
- Curl simulation of challenge start endpoints confirming instant (<1ms) RAM-only response without database access.
