# Technical Implementation Plan: WebAuthn Passkey Authentication & Lifecycle

## Goal Description
Implement the complete WebAuthn Passkey subsystem for the Kosh server (Milestone 3 of the passkey roadmap). 

In Milestone 1, we established the database schema (`webauthn_credentials`), the domain model ([`crates/server/src/model/passkey.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/model/passkey.rs)), and the 60-byte wrapped vault key envelope. 

This plan details how to wire up `webauthn-rs` to deliver:
1. **Protected Hardware Registration:** Enrolling biometrics/hardware keys (FaceID, TouchID, YubiKey, Windows Hello) with client-side encrypted metadata labels.
2. **1-Touch Biometric Login (Discoverable / Resident Credentials):** Authenticating users without needing an email or username, returning both an active Bearer session token and the 60-byte encrypted root vault key envelope.
3. **Passkey Management:** Listing registered passkeys and revoking individual credentials.

---

## User Review Required

> [!IMPORTANT]
> **Relying Party Origin & Local Development Flexibility:**
> WebAuthn requires an exact `rp_id` (e.g. `localhost` or `kosh.local`) and `rp_origin` (e.g. `http://localhost:6969`). Browsers and authenticators strictly reject any signature where the requesting origin does not match the Relying Party. 
> We will add `rp_id`, `rp_origin`, and `rp_name` to the KDL configuration file (`kosh.kdl`) with defaults `localhost`, `http://localhost:6969`, and `Kosh Vault`.

> [!IMPORTANT]
> **Challenge State Cache in Moka:**
> WebAuthn ceremonies are two-phase protocols (`start` $\to$ browser ceremony $\to$ `finish`). The server generates a random challenge and must remember it until `finish`.
> We will store ephemeral challenge states in `AppState` using Moka caches with a 60-second TTL:
> - `passkey_registration_cache: Cache<Uuid, (i64, PasskeyRegistration)>`
> - `passkey_auth_cache: Cache<Uuid, PasskeyAuthentication>`
> This ensures zero disk I/O, auto-eviction on expiration, and single-use removal upon ceremony completion.

> [!NOTE]
> **Discoverable (Resident) Credentials:**
> For 1-touch passkey login, the browser asks the authenticator for available credentials without specifying a `user_id`. The authenticator returns its `credential_id` and `user_handle`. 
> The server looks up the credential in `webauthn_credentials`, identifies the owner `user_id`, updates the signature counter, and unlocks the user session.

---

## Open Questions

> [!NOTE]
> **Passkey Nickname / Metadata Encryption:**
> During registration, the client passes an `encrypted_metadata` string (up to 1024 bytes) containing their encrypted label for the passkey (e.g. "MacBook Pro TouchID" or "NFC YubiKey"). The server stores this verbatim in SQLite and returns it when the client calls `GET /api/v1/auth/passkey`.

---

## Architecture & Ceremony Sequence

```mermaid
sequenceDiagram
    autonumber
    actor User as User / Browser
    participant API as Kosh Server
    participant Cache as Moka (RAM)
    participant DB as SQLite (Disk)

    Note over User,DB: Phase 1: Passkey Registration (Authenticated)
    User->>API: POST /api/v1/auth/passkey/register/start (Bearer token)
    API->>API: webauthn.start_passkey_registration(user_id)
    API->>Cache: Store (challenge_id -> PasskeyRegistration) [TTL 60s]
    API-->>User: 200 OK { challenge_id, creation_challenge }
    User->>User: navigator.credentials.create(creation_challenge)
    User->>API: POST /api/v1/auth/passkey/register/finish { challenge_id, credential, encrypted_metadata }
    API->>Cache: Remove challenge_id
    API->>API: webauthn.finish_passkey_registration(...)
    API->>DB: INSERT INTO webauthn_credentials (credential_id, user_id, passkey_data, counter, encrypted_metadata)
    API-->>User: 201 Created

    Note over User,DB: Phase 2: 1-Touch Passkey Login (Unauthenticated)
    User->>API: POST /api/auth/passkey/login/start (with IP rate-limit)
    API->>API: webauthn.start_passkey_authentication(&[]) (Discoverable)
    API->>Cache: Store (challenge_id -> PasskeyAuthentication) [TTL 60s]
    API-->>User: 200 OK { challenge_id, request_challenge }
    User->>User: navigator.credentials.get(request_challenge)
    User->>API: POST /api/auth/passkey/login/finish { challenge_id, credential }
    API->>Cache: Remove challenge_id
    API->>DB: SELECT * FROM webauthn_credentials WHERE credential_id = ?
    API->>API: webauthn.finish_passkey_authentication(credential, stored_passkey)
    API->>DB: UPDATE webauthn_credentials SET counter = ?, last_used = ?
    API->>DB: SELECT wrapped_vault_key FROM users WHERE id = user_id
    API->>DB: INSERT INTO sessions ... (Session::create)
    API-->>User: 200 OK { token, wrapped_vault_key }
```

---

## Proposed Changes

### 1. Dependencies & Configuration

#### [MODIFY] [`crates/server/Cargo.toml`](file:///home/ton3s/rsProjects/webdav-server/crates/server/Cargo.toml)
- Add `webauthn-rs = { version = "0.5.2", features = ["danger-allow-state-serialisation", "workaround-google-passkey-specific-issues"] }`.
- Add `url = "2.5"`.

#### [MODIFY] [`crates/core/src/config/mod.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/core/src/config/mod.rs)
- Add KDL fields for Relying Party configuration:
  ```rust
  /// WebAuthn Relying Party identifier (domain or host, e.g. "localhost").
  #[knuffel(child, unwrap(argument), default = "localhost".to_string())]
  pub rp_id: String,

  /// WebAuthn Relying Party Origin URL (e.g. "http://localhost:6969").
  #[knuffel(child, unwrap(argument), default = "http://localhost:6969".to_string())]
  pub rp_origin: String,

  /// WebAuthn Relying Party human-readable display name.
  #[knuffel(child, unwrap(argument), default = "Kosh Vault".to_string())]
  pub rp_name: String,
  ```

---

### 2. Application State & Builders

#### [MODIFY] [`crates/server/src/app/state.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/app/state.rs)
- Add fields to `StateInner`:
  ```rust
  pub webauthn: Arc<webauthn_rs::Webauthn>,
  pub passkey_registration_cache: Cache<Uuid, (i64, webauthn_rs::prelude::PasskeyRegistration)>,
  pub passkey_auth_cache: Cache<Uuid, webauthn_rs::prelude::PasskeyAuthentication>,
  ```

#### [MODIFY] [`crates/server/src/app/builder.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/app/builder.rs)
- In `AppStateBuilder::build(&self, config: &Config)`:
  - Construct `WebauthnBuilder::new(&config.rp_id, &Url::parse(&config.rp_origin)?)?.rp_name(&config.rp_name).build()?`.
  - Initialize 60-second TTL Moka caches for registration and auth ceremonies.

---

### 3. API Error Mapping

#### [MODIFY] [`crates/server/src/api/error.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/api/error.rs)
- Add `Webauthn(webauthn_rs::error::WebauthnError)` variant to `api::Error`.
- In `IntoResponse`: Map to `(StatusCode::BAD_REQUEST, "Passkey authentication failed")`.
- In `Loggable`: Map to `Level::Warning` under `Module::Api`.

---

### 4. API Handlers

#### [NEW] `crates/server/src/api/auth/passkey/mod.rs`
- Module coordinator exporting sub-handlers:
  - `pub mod register;`
  - `pub mod login;`
  - `pub mod manage;`

#### [NEW] `crates/server/src/api/auth/passkey/register.rs`
- `POST /api/v1/auth/passkey/register/start`:
  - Requires authenticated session (`Extension(user_id): Extension<i64>`).
  - Calls `state.webauthn.start_passkey_registration(user_handle, username, display_name, excluded_credentials)`.
  - Saves challenge to `state.passkey_registration_cache`.
  - Returns `Json(RegisterStartResponse { challenge_id, challenge })`.
- `POST /api/v1/auth/passkey/register/finish`:
  - Requires authenticated session (`Extension(user_id): Extension<i64>`).
  - Validates `challenge_id` from cache (single-use invalidate).
  - Calls `state.webauthn.finish_passkey_registration(&credential, &challenge)`.
  - Serializes `Passkey` to bincode or JSON bytes.
  - Inserts `PasskeyRecord` via `PasskeyRecord::create(&state.db, &record)`.
  - Returns `StatusCode::CREATED`.

#### [NEW] `crates/server/src/api/auth/passkey/login.rs`
- `POST /api/auth/passkey/login/start`:
  - Unauthenticated (guarded by `with_auth_ip_limit`).
  - Calls `state.webauthn.start_passkey_authentication(&[])` for resident/discoverable keys.
  - Saves challenge to `state.passkey_auth_cache`.
  - Returns `Json(LoginStartResponse { challenge_id, challenge })`.
- `POST /api/auth/passkey/login/finish`:
  - Unauthenticated (guarded by `with_auth_ip_limit`).
  - Pops challenge from `state.passkey_auth_cache`.
  - Extracts `credential_id` from incoming credential and fetches `PasskeyRecord::find(&state.db, &credential_id)`.
  - Verifies signature via `state.webauthn.finish_passkey_authentication(...)`.
  - Updates counter and timestamp via `PasskeyRecord::update_counter`.
  - Fetches user record to retrieve `wrapped_vault_key`.
  - Issues bearer token via `Session::create(&state.db, record.user_id, &state.secret)`.
  - Returns `Json(Response { token, wrapped_vault_key: hex::encode(...) })`.

#### [NEW] `crates/server/src/api/auth/passkey/manage.rs`
- `GET /api/v1/auth/passkey`:
  - Authenticated (`Extension(user_id)`).
  - Returns `Json(PasskeyRecord::list_for_user(&state.db, user_id).await?)`.
- `DELETE /api/v1/auth/passkey/{credential_id}`:
  - Authenticated (`Extension(user_id)`).
  - Decodes hex `credential_id`.
  - Calls `PasskeyRecord::delete(&state.db, &cred_id, user_id).await?`.
  - Returns `StatusCode::NO_CONTENT` or `StatusCode::NOT_FOUND`.

---

### 5. Routing

#### [MODIFY] [`crates/server/src/api/route.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/api/route.rs)
- Register unauthenticated passkey login routes in `auth_routes`:
  ```rust
  .route("/auth/passkey/login/start", post(auth::passkey::login::start))
  .route("/auth/passkey/login/finish", post(auth::passkey::login::finish))
  ```
- Register protected passkey registration and management routes in `protected_routes`:
  ```rust
  .route("/auth/passkey/register/start", post(auth::passkey::register::start))
  .route("/auth/passkey/register/finish", post(auth::passkey::register::finish))
  .route("/auth/passkey", get(auth::passkey::manage::list))
  .route("/auth/passkey/{credential_id}", delete(auth::passkey::manage::delete))
  ```

---

## Verification Plan

### Automated Tests
1. **Unit & Ceremony Tests (`crates/server/src/api/auth/passkey/test.rs`):**
   - Mock authenticator registration: verify challenge creation, cache storage, and SQLite record insertion.
   - Mock authenticator assertion: verify resident key authentication, signature counter advancement, and session token generation.
   - Passkey listing and revocation tests.
   - Expired or forged challenge rejection (verifying 60-second TTL eviction).
2. **Workspace Verification:**
   ```bash
   cargo check --workspace
   cargo test --workspace
   cargo clippy --workspace --lib -- -D warnings
   cargo clippy --workspace --tests -- -D warnings
   ```

### Manual Verification
1. Integration test with `reqwest` or curl running full registration and login flow against local running server.
2. Confirm returned `wrapped_vault_key` on passkey login exactly matches the vault key stored during user registration.
