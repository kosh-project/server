```markdown
# Kosh Framework: Complete Architecture, Cryptography & Authentication Specification

## 1. System Vision & Core Invariants

Kosh is an end-to-end encrypted (E2EE), zero-knowledge, local-first storage and synchronization engine across Android clients (File Manager and Gallery apps) and a self-hosted Linux server. The server functions strictly as an untrusted, blind "Dumb Bucket" with zero visibility into plaintext content, directory layouts, metadata, or file types.

### Hardware & Performance Constraints
- **Server Target Profile:** Intel Core i5/i7 (Sandy Bridge microarchitecture), 10 GB RAM, mechanical spinning hard disk drive (HDD), ext4/XFS on headless Arch Linux.
- **System Invariant:** Disk seeks kill throughput. Malicious, malformed, or unauthenticated ingress traffic must be filtered entirely in RAM within nanoseconds to microseconds, preventing cache eviction, Tokio worker thread starvation, and random disk I/O thrashing.

---

## 2. Ingress Funnel & Rate-Limiting Architecture

Traffic entering the Axum server is bifurcated into two mutually exclusive pipelines: Unauthenticated Routes (PoW-shielded) and Authenticated Routes (stateless MAC + rate-limit shielded).

### Pipeline A: Unauthenticated Boundaries (`/api/auth/*`)
Protects CPU-heavy cryptographic operations (Argon2id, SQLite user creation) from denial-of-service and credential-stuffing attacks.


```

Incoming Request
│
▼
[ Layer 1: Proxy-Aware Global IP Governor (tower_governor + SmartIpExtractor) ]
• Key: Client IP (respects X-Forwarded-For / X-Real-IP)
• Quota: 25 req/s, Burst: 10
│
▼
[ Layer 2: Auth IP Governor ]
• Quota: 2 req/s, Burst: 2
│
▼
[ Layer 3: Stateless Hashcash Guard (pow_guard middleware) ]
• Header: X-Hashcash (Strict length 165 or 168 bytes)
• Single-pass SHA-256 over entire header (requires 16 leading zero bits)
• Validates TTL: (now - 15s) <= timestamp <= (now + 5s)
• Validates BLAKE3 MAC using ephemeral RAM-only key (K_ephemeral)
│
▼
[ Layer 4: Route Handlers (login, register) ]
• Deserializes JSON body only AFTER PoW and MAC succeed

```

### Pipeline B: Authenticated Routes (`/api/v1/*`)
Protects Content-Addressable Storage (CAS) operations and ledger synchronization.


```

Incoming Request
│
▼
[ Layer 1: Global IP Governor (Proxy-Aware SmartIpExtractor) ]
• Quota: 25 req/s, Burst: 10
│
▼
[ Layer 2: Stateless Token Pre-Filter (mac_guard) ]
• Header: Authorization: Bearer 
• Verifies 96-char token structure and BLAKE3 MAC using persistent K_server in < 1µs
• Injects TokenHash = BLAKE3(token) into Request Extensions
│
▼
[ Layer 3: Device Token Governor (tower_governor) ]
• KeyExtractor: TokenExtractor reading TokenHash from extensions
• Quota: 15 req/s, Burst: 5
│
▼
[ Layer 4: Session Resolution (auth_guard) ]
• Fast Path: In-memory Moka cache (TokenHash -> user_id)
• Slow Path: SQLite WAL lookup (cache miss)
│
▼
[ Layer 5: Route Handlers (CAS Blobs, Ledger Pull/Push, Mailbox) ]

```

---

## 3. Cryptographic Primitives & Key Management (Model 1)

Kosh uses **Model 1 (Passwordless)**: Human passwords do not exist. Authentication and vault unlocking are unified under a permanent 24-word BIP-39 Recovery Phrase and Passkeys (WebAuthn).

### Key Classes & Storage Hierarchy
1. **`K_vault` (32 bytes):**
   - The **True Master Key**. Generated via `SecureRandom` on Day 1.
   - Stored strictly inside the **Android Keystore / StrongBox** (unlocked via biometrics).
   - Used as the KEK to derive file DEKs, deduplicate CAS blobs, and encrypt local SQLite (Room) databases.
   - **Never leaves the client device in plaintext.**
2. **The 24-Word BIP-39 Mnemonic / Seed:**
   - Permanent cryptographic root of identity. Written on paper by the user.
   - Derives deterministic credentials via BLAKE3 key derivation and Argon2id:
     - `identity_hash`: Hex-encoded BLAKE3 derivation used in Hashcash headers.
     - `auth_verifier`: Argon2id hash of the derived auth secret, sent to server during login/register.
     - `K_recovery`: 32-byte AES-GCM decryption key used *only* during setup or catastrophic recovery to unwrap `K_vault`.
3. **The Vault Key Envelope (`wrapped_vault_key`):**
   - A 60-byte binary blob stored on the server: `AES-GCM-Encrypt(K_recovery, K_vault)`.
   - Allows users to rotate their 24-word recovery phrase in milliseconds without re-encrypting gigabytes of files on disk.

---

## 4. Hybrid Storage Topology (Filesystem + SQLite)

Storage responsibility is strictly bifurcated to optimize for mechanical spinning hard drives (HDD) and prevent SQLite fragmentation death spirals.


```

┌────────────────────────────────────────────────────────┐
│                   Axum Route Handlers                  │
└───────────────┬────────────────────────┬───────────────┘
│                        │
(Relational Metadata)       (Binary Payloads)
▼                        ▼
┌─────────────────────────────┐  ┌──────────────────────────────────────────────┐
│         SQLite WAL          │  │       Filesystem Append-Only Log             │
├─────────────────────────────┤  ├──────────────────────────────────────────────┤
│ • users (w/ wrapped_vault)  │  │ /vaults/{user_id}/ledger/{namespace}/        │
│ • device_sync_watermarks    │  │   ├── current.log (active append stream)     │
│ • ledger_snapshots          │  │   └── 0000000000000000.log (sealed segment)  │
│ • webauthn_credentials      │  └──────────────────────────────────────────────┘
└─────────────────────────────┘

```

1. **SQLite (WAL Mode):** Stores users, high-water marks, device liveness, snapshots, and WebAuthn credentials.
2. **Filesystem (Segmented Append-Only Log):** Stores encrypted delta payloads inside namespaced directories (`/vaults/{user_id}/ledger/{namespace}/`). Pruned via $O(1)$ segment file deletion (`std::fs::remove_file`) based on High-Water Marks and Snapshot sequences.

---

## 5. Complete Authentication & Lifecycle Flows

### Flow A: Initial Account Registration (Day 1)
1. **Client Generation:** Client generates `K_vault` (saved to Android Keystore) and a 24-word BIP-39 mnemonic (displayed to user).
2. **Credential Derivation:** From the 24 words, client derives `identity_hash`, `auth_verifier`, and `K_recovery`.
3. **Envelope Wrapping:** Client encrypts `K_vault` with `K_recovery` to produce `wrapped_vault_key` (60 bytes).
4. **Server Registration:** Client solves Hashcash challenge (`identity_hash`) and calls `POST /api/auth/register` with `auth_verifier` and `wrapped_vault_key`.
5. **Passkey Binding:** Post-registration, the app registers a hardware Passkey via `webauthn-rs` into the `webauthn_credentials` table.

### Flow B: Everyday App Unlock
1. Client retrieves persistent 96-character Bearer `token` from `EncryptedSharedPreferences`.
2. Biometric prompt unlocks `K_vault` in memory via Android Keystore.
3. Sync Daemon talks directly to `/api/v1/*` routes using `Authorization: Bearer <token>`.

### Flow C: Adding a Second Device (Passkey + ECDH Blind Mailbox)
When a user logs in on a new device using a Passkey, they have an Axum session token but no `K_vault`. They must hydrate their keys:
1. **Open Mailbox:** New device generates an ephemeral X25519 keypair (`Pub_temp`, `Priv_temp`) and calls authenticated `POST /api/v1/devices/mailbox`. Server returns `mailbox_id`.
2. **QR Code:** New device displays a QR code containing `mailbox_id` and `Pub_temp`.
3. **Scan & Fulfill:** User scans QR code with their authenticated old device (which holds `K_vault`). Old device encrypts `K_vault` with `Pub_temp` and calls `POST /api/v1/devices/mailbox/{id}/fulfill`.
4. **Pickup:** New device polls `GET /api/v1/devices/mailbox/{id}`, decrypts the payload with `Priv_temp`, saves `K_vault` to its local Keystore, and syncs via snapshots.

### Flow D: Catastrophic Recovery (All Devices Lost)
1. User types 24-word recovery phrase into a new phone.
2. Phone deterministically re-derives `identity_hash`, `auth_verifier`, and `K_recovery`.
3. Phone solves Hashcash and calls `POST /api/auth/login`. Server returns new Session `token` and the 60-byte `wrapped_vault_key`.
4. Phone uses `K_recovery` to unwrap `wrapped_vault_key` $\rightarrow$ recovers `K_vault`, saves to Keystore, and downloads latest snapshot.

### Flow E: Recovery Phrase Rotation (Key Hygiene)
1. User taps **"Rotate Recovery Phrase"** on an active device.
2. Client generates **brand-new** 24 words, deriving a *new* `identity_hash`, `auth_verifier`, and `K_recovery`.
3. Client reads **existing `K_vault`** from Keystore and re-encrypts it with `new_K_recovery` to produce a new `wrapped_vault_key`.
4. Client calls authenticated `PUT /api/v1/auth/recovery` to atomically update `users` table and optionally invalidate old sessions. Zero files are re-encrypted.

---

## 6. Implementation Action Plan for Agent

- [ ] **Database Migrations:** Create migration adding `wrapped_vault_key BLOB NOT NULL` to `users`, plus tables for `device_sync_watermarks`, `ledger_snapshots`, and `webauthn_credentials`.
- [ ] **Proxy-Aware Rate Limiters:** Ensure `SmartIpExtractor` is active on Global and Auth IP governors in `rate_limit.rs`.
- [ ] **Auth & Recovery Endpoints:** Implement `register`, `login`, passwordless Passkey start/finish endpoints via `webauthn-rs`, and the `PUT /api/v1/auth/recovery` rotation handler.
- [ ] **Blind Mailbox Relay:** Implement ephemeral Moka-cached memory endpoints (`POST /api/v1/devices/mailbox` and `/fulfill`) for cross-device QR code key sharing.
- [ ] **Hybrid Storage Ledger:** Maintain namespaced segmented file logging (`current.log`, `.log` segments) while managing metadata exclusively through SQLite WAL mode.

```
