Here is the specialized, deep-dive context file focused entirely on the Authentication, Passkey, and Recovery architecture. It heavily emphasizes the open-source developer flexibility and outlines the exact flows and database schemas your agent needs to build this.

You can save this as `auth_and_recovery_context.md` alongside "The Rust and Android Zero-Knowledge Storage Framework" to give your agent the complete picture.

```markdown
# Context Specification: Kosh Authentication, Passkey & Recovery Protocol

## 1. Architectural Philosophy: The "Blind Server" & Developer Flexibility

Kosh is an End-to-End Encrypted (E2EE), zero-knowledge storage engine. The official Android client utilizes **Model 1 (Passwordless)**, relying entirely on WebAuthn Passkeys for daily authentication and a 24-word BIP-39 recovery phrase for cryptographic root identity. Human passwords are intentionally eliminated.

### The Open-Source Extensibility Mandate
While the official Android client uses Passkeys and BIP-39, **the Rust server must remain entirely agnostic to how the client generates its credentials.** 
The server only understands three cryptographic primitives during authentication:
1. `identity_hash` (A 32-byte BLAKE3 hash used for Proof-of-Work / Hashcash routing).
2. `auth_verifier` (An Argon2id hash used to prove ownership of the identity).
3. `wrapped_vault_key` (An opaque 60-byte binary envelope holding the true encryption key).

**Developer Freedom:** Because the server is blind, a third-party developer forking the client for Linux or Windows can easily implement **Model 2 (Classic Username/Password)**. They can simply compute `identity_hash = SHA256(username)` and `auth_verifier = Argon2id(password)`, using the 24-word phrase strictly to unwrap `wrapped_vault_key`. The Rust server requires **zero modifications** to support custom third-party authentication models, so long as they provide these three primitives.

---

## 2. Database Schema & State Requirements

The server requires specific metadata tables to support Passkeys, Envelope Encryption, and cross-device syncing. 

### SQLite Schema Updates (WAL Mode)
```sql
-- 1. Users Table Modification
-- We must add `wrapped_vault_key` to hold the encrypted envelope of the true master key.
ALTER TABLE users ADD COLUMN wrapped_vault_key BLOB NOT NULL DEFAULT '';
-- (Expected structure of users: id, identity_hash, auth_verifier, wrapped_vault_key)

-- 2. WebAuthn Passkeys Table
-- Supports multiple passkeys (Phone face unlock, Tablet fingerprint, YubiKey) per user.
CREATE TABLE IF NOT EXISTS webauthn_credentials (
    cred_id BLOB PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    public_key BLOB NOT NULL,
    sign_count INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);

```

### In-Memory State (Moka Cache)

* **Session Cache:** Maps 96-char Bearer tokens to `user_id`.
* **ECDH Mailbox Cache:** A temporary, 5-minute TTL cache used to relay encrypted payloads between a user's devices. Maps `mailbox_id` (String) -> `encrypted_payload` (Bytes). **Never touches the disk.**

---

## 3. The Cryptographic Key Hierarchy

The client Android application strictly manages the keys. The server never sees `K_vault` or `K_recovery`.

* **`K_vault` (32 bytes):** The **True Master Key**. Generated via `SecureRandom` on account creation. Stored in Android Hardware Keystore. Encrypts local databases and derives file-specific Data Encryption Keys (DEKs). Never changes.
* **24-Word BIP-39 Mnemonic:** The permanent root of identity. Written on paper.
* **Derivation Tree (From BIP-39 Seed):**
* `identity_hash` = `BLAKE3::derive_key("kosh-identity", seed)`
* `auth_verifier` = `Argon2id(BLAKE3::derive_key("kosh-auth", seed))`
* `K_recovery` = `BLAKE3::derive_key("kosh-recovery", seed)` (Used to lock/unlock `K_vault`).



---

## 4. Lifecycle Flows to Implement

The agent must build the server-side route handlers to support the following client flows:

### Flow 1: Initial Registration & Passkey Setup

1. **Client:** Generates `K_vault` and the 24-word phrase. Derives `identity_hash`, `auth_verifier`, and `K_recovery`.
2. **Client:** Wraps the vault: `wrapped_vault_key = AES-GCM(key: K_recovery, plaintext: K_vault)`.
3. **Server:** Client completes Hashcash PoW, calls `POST /api/auth/register` providing `auth_verifier` and `wrapped_vault_key`. Server saves to `users` table and issues a session token.
4. **Server:** Client immediately calls `POST /api/auth/passkey/register/{start,finish}` to register their device's biometric hardware as a Passkey into `webauthn_credentials`.

### Flow 2: Everyday App Unlock (No Auth Required)

1. **Client:** Android Keystore unlocks `K_vault` via FaceID/Fingerprint.
2. **Server:** Client makes standard requests to `/api/v1/*` using its persistent Bearer Session token. Server validates token via `mac_guard` and Moka cache.

### Flow 3: Adding a New Device (Old Device Available) -> "ECDH Mailbox"

When Alice buys a tablet, she uses her Passkey to get a server session, but she lacks `K_vault` to decrypt files.

1. **Server Login:** Tablet calls `POST /api/auth/passkey/login/{start,finish}`. Server validates signature and issues a Bearer session token. Tablet is now authenticated but "blind".
2. **Mailbox Open:** Tablet generates an ephemeral X25519 public key (`Pub_temp`) and calls `POST /api/v1/devices/mailbox`. Server returns `mailbox_id = "123456"`.
3. **QR Code Transfer:** Tablet displays QR code with `mailbox_id` and `Pub_temp`. Alice's Old Phone scans it.
4. **Mailbox Fulfill:** Old Phone encrypts `K_vault` with `Pub_temp`. Calls `POST /api/v1/devices/mailbox/123456/fulfill` with the ciphertext payload.
5. **Mailbox Pickup:** Tablet polls `GET /api/v1/devices/mailbox/123456`, decrypts the payload with `Priv_temp`, saves `K_vault` to its hardware Keystore, and begins syncing.

*Note for 3rd-Party Devs: If a desktop client lacks a camera, this protocol supports manual code entry (pairing codes) or bidirectional QR scanning, as the server just routes opaque ECDH payloads.*

### Flow 4: Catastrophic Recovery (Old Devices Lost / Destroyed)

Alice lost her phone and passkey hardware. She only has her paper backup.

1. **Client:** Alice types 24 words into new phone. Phone re-derives `identity_hash`, `auth_verifier`, and `K_recovery`.
2. **Server:** Phone passes Hashcash guard, calls `POST /api/auth/login` with `auth_verifier`.
3. **Server:** Verifies `auth_verifier`, and responds with a new Bearer Session token AND the `wrapped_vault_key`.
4. **Client:** Uses `K_recovery` to decrypt `wrapped_vault_key`, extracting `K_vault`.
5. **Client:** Saves `K_vault` to Android Keystore and registers a new Passkey.

### Flow 5: Millisecond Key Rotation (Compromised Paper Backup)

Alice suspects her paper backup was seen. She wants to change her 24 words without re-encrypting gigabytes of HDD storage.

1. **Client:** App generates **brand-new** 24 words. Derives *new* `identity_hash`, `auth_verifier`, and `K_recovery`.
2. **Client:** Pulls existing `K_vault` from Keystore (which does NOT change). Encrypts it with the *new* `K_recovery` to create `new_wrapped_vault_key`.
3. **Server:** Client calls `PUT /api/v1/auth/recovery` (Authenticated route).
4. **Server Action:** Executes `UPDATE users SET identity_hash = ?1, auth_verifier = ?2, wrapped_vault_key = ?3 WHERE id = ?4`.
5. **Result:** The old 24-word phrase is mathematically destroyed and permanently invalid. Zero files on the mechanical disk were re-encrypted.

---

## 5. Implementation Directives for the Agent

* Implement `webauthn-rs` to handle Passkey start/finish challenge flows.
* Build the `POST/GET /api/v1/devices/mailbox` ephemeral routes using the existing Moka cache architecture.
* Modify `login.rs` and `register.rs` to ingest and return `wrapped_vault_key`.
* Implement `PUT /api/v1/auth/recovery` to execute the atomic SQLite `UPDATE` for millisecond key rotation.
* Ensure all logic conforms to the overarching guidelines outlined in "The Rust and Android Zero-Knowledge Storage Framework".

```

```
