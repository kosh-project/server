# Tech Stack I've in mind
- Rust axum for the webdav server, that'll be deployed on a machine
- For clients it's mixed
-- For android, I'll use android jetpack and whatever comes in a generic stack along with android jetpack
-- Maybe, if i extend it.. I'll go for working on a desktop client
    Network Level Guarantees: There is no need to manually verify the order of incoming chunks. The HTTP/TCP stack and the Arch Linux kernel handle sequence numbers and guarantee that Axum only receives a perfectly sequential byte stream.  

3. The Threat Model & Zero-Knowledge E2EE

All encryption and key management happen purely on the client side (Android).  

    Key Derivation: The Android app generates 256 bits of entropy, converted to a 24-word BIP-39 recovery phrase. This is passed through Argon2id to derive a 256-bit Master Key securely stored in the Android Hardware-Backed Keystore.  

    Client-Side Encryption: Photos/Videos are encrypted on the phone via hardware-accelerated AES-GCM (using Google's Tink cryptography library) before being transmitted to the server.  

    Metadata Obfuscation: Filenames are converted into randomized UUID strings (e.g., a7f9-2b81.encrypted) to hide chronological or contextual data. True structural metadata is stored in a separate encrypted index file (e.g., Protocol Buffers) synced alongside the blobs.  

    MitM Immunity (OOB Pairing): On first boot, the Rust server auto-generates a self-signed X.509 certificate and displays its SHA-256 fingerprint as an ANSI block QR code directly in the SSH terminal. The Android client scans this QR code and uses a custom X509TrustManager to pin the certificate, immediately destroying connections if the network cert doesn't match the scanned hash.  

4. Mobile Client Optimization (Android)

    Encrypted Thumbnail Sidecars: To eliminate UI lag in high-density layout views (RecyclerView grids) without decrypting massive video files, the app generates and separately encrypts tiny (~50KB) WebP/JPEG thumbnails during ingestion.  

    Background Syncing: Network uploads are offloaded to Android's WorkManager API to execute only when the client device matches system constraints (e.g., unmetered Wi-Fi, battery charging).  

5. Testing Architecture & Cargo Gotchas

The server is rigorously tested using Rust's built-in testing framework and automated HTTP clients.

    Integration Tests: End-to-end integration tests are written using reqwest to simulate the Android client sending real HTTP multipart payloads.  

    Network Isolation: The test server binds to 127.0.0.1:0 to let the OS assign a random, unused port, preventing network collisions. Test parallelism collisions (like "Connection refused" errors) are fixed by restricting threads (cargo test --test-threads=1), using the serial_test crate, or ignoring specific tests.  

    Async Deadlocks: Awaiting tokio::spawn on an infinite server loop (axum::serve) hangs tests. The fix is to "fire-and-forget" the server task into the background without .await?.  

    Dynamic State Injection: To prevent tests from polluting the actual workspace, the router was refactored to use Axum State (AppState). This allows injecting a temporary directory (TmpDir) during tests and the real ./vault directory during production.  

6. Next Objectives for the AI

When interacting with me, strictly maintain the Rust/Axum architecture. Keep the code lean, heavily emphasize bare-metal efficiency, explain low-level system interactions (like Linux file descriptors, threading, and TCP buffers), and be mindful of my Android Kotlin architecture.

Immediate next steps involve:

    Establishing the exact database schema (e.g., SQLite or protocol buffers binary structure) for the local metadata manifest.  

    Drafting the Rust server network lifecycle for handling encrypted file streaming chunks back to the client.  

    Refining the Kotlin networking implementation for custom trust parameters and dynamic SSL/TLS certificate pinning loops.  




# Context A 
Here is your customized, comprehensive "Master Context" document, fully stripped of the Spring Boot detour and laser-focused strictly on your native Rust, Axum, and bare-metal Arch Linux architecture.

You can copy and paste everything below the horizontal rule directly into a `.md` file (e.g., `nas_architecture_context.md`) and feed it to any Gemini-CLI or new chat window.

---

# SYSTEM ARCHITECTURE & PROJECT CONTEXT: Zero-Knowledge Arch Linux NAS

## 1. Project Overview & Philosophy

I am building an open-source, easily deployable zero-knowledge storage framework/NAS intended for home-lab and self-hosting enthusiasts. The core philosophy is absolute privacy, high performance on older hardware, and deep systems-level robustness.

* 
**The Server acts as a "Dumb Bucket of Bits":** The server has zero visibility into filenames, folder structures, or image contents. It only receives, stores, and serves raw AES-GCM encrypted byte streams.


* 
**Target Hardware:** The server is a legacy x86_64 desktop (Intel Core i5 2nd-Generation Sandy Bridge, ~3.1GHz, 10GB RAM).


* 
**Operating System:** Pure, minimalist Arch Linux (linux-lts kernel) configured as a completely headless server.


* 
**Developer Restrictions:** Strict prohibition on JavaScript/TypeScript web-ecosystem utilities or frameworks.



## 2. Core Server Architecture (Rust & Axum)

The server runtime is written in high-performance Rust, compiled locally using `RUSTFLAGS="-C target-cpu=native"` to leverage native vector extensions (like AVX).

* 
**High-Performance File Streaming:** To stay within the 10GB RAM limit of the Sandy Bridge hardware, the server uses Axum's Multipart to stream massive encrypted files directly to disk rather than buffering them in memory.


* 
**Async Disk I/O:** It intercepts raw network socket chunks and uses an inner loop to append byte arrays via `tokio::fs::File::write_all`. Tokio automatically ships blocking disk write operations to a background thread pool (`spawn_blocking`), ensuring the main async worker thread is never stalled.


* 
**Network Level Guarantees:** There is no need to manually verify the order of incoming chunks. The HTTP/TCP stack and the Arch Linux kernel handle sequence numbers and guarantee that Axum only receives a perfectly sequential byte stream.



## 3. The Threat Model & Zero-Knowledge E2EE

All encryption and key management happen purely on the client side (Android).

* 
**Key Derivation:** The Android app generates 256 bits of entropy, converted to a 24-word BIP-39 recovery phrase. This is passed through Argon2id to derive a 256-bit Master Key securely stored in the Android Hardware-Backed Keystore.


* 
**Client-Side Encryption:** Photos/Videos are encrypted on the phone via hardware-accelerated AES-GCM (using Google's Tink cryptography library) before being transmitted to the server.


* 
**Metadata Obfuscation:** Filenames are converted into randomized UUID strings (e.g., `a7f9-2b81.encrypted`) to hide chronological or contextual data. True structural metadata is stored in a separate encrypted index file (e.g., Protocol Buffers) synced alongside the blobs.


* 
**MitM Immunity (OOB Pairing):** On first boot, the Rust server auto-generates a self-signed X.509 certificate and displays its SHA-256 fingerprint as an ANSI block QR code directly in the SSH terminal. The Android client scans this QR code and uses a custom `X509TrustManager` to pin the certificate, immediately destroying connections if the network cert doesn't match the scanned hash.



## 4. Mobile Client Optimization (Android)

* 
**Encrypted Thumbnail Sidecars:** To eliminate UI lag in high-density layout views (RecyclerView grids) without decrypting massive video files, the app generates and separately encrypts tiny (~50KB) WebP/JPEG thumbnails during ingestion.


* 
**Background Syncing:** Network uploads are offloaded to Android's WorkManager API to execute only when the client device matches system constraints (e.g., unmetered Wi-Fi, battery charging).



## 5. Testing Architecture & Cargo Gotchas

The server is rigorously tested using Rust's built-in testing framework and automated HTTP clients.

* 
**Integration Tests:** End-to-end integration tests are written using `reqwest` to simulate the Android client sending real HTTP multipart payloads.


* 
**Network Isolation:** The test server binds to `127.0.0.1:0` to let the OS assign a random, unused port, preventing network collisions. Test parallelism collisions (like "Connection refused" errors) are fixed by restricting threads (`cargo test --test-threads=1`), using the `serial_test` crate, or ignoring specific tests.


* 
**Async Deadlocks:** Awaiting `tokio::spawn` on an infinite server loop (`axum::serve`) hangs tests. The fix is to "fire-and-forget" the server task into the background without `.await?`.


* 
**Dynamic State Injection:** To prevent tests from polluting the actual workspace, the router was refactored to use Axum `State` (`AppState`). This allows injecting a temporary directory (`TmpDir`) during tests and the real `./vault` directory during production.



## 6. Next Objectives for the AI

When interacting with me, strictly maintain the Rust/Axum architecture. Keep the code lean, heavily emphasize bare-metal efficiency, explain low-level system interactions (like Linux file descriptors, threading, and TCP buffers), and be mindful of my Android Kotlin architecture.

**Immediate next steps involve:**

1. Establishing the exact database schema (e.g., SQLite or protocol buffers binary structure) for the local metadata manifest.


2. Drafting the Rust server network lifecycle for handling encrypted file streaming chunks back to the client.


3. Refining the Kotlin networking implementation for custom trust parameters and dynamic SSL/TLS certificate pinning loops.




# Context B
# NAS-rs — Complete Project Context

## Project Overview

NAS-rs is a long-term systems programming project focused on building a modern self-hosted personal storage platform in Rust.

The project originally began as an attempt to build a NAS (Network Attached Storage) server similar to Synology, QNAP, or a self-hosted Google Drive alternative. However, during planning and experimentation, the scope evolved significantly.

The current goal is no longer to build "just another NAS server" or "just another file hosting application."

Instead, NAS-rs is evolving into:

> A self-hosted personal storage and digital memory platform that emphasizes ownership, migration, organization, synchronization, privacy, and long-term accessibility of personal data.

The project is intended as both:

* A serious systems programming learning project
* A potentially useful open-source self-hosted product

The project is being developed primarily by a Computer Science engineering student who is already comfortable with Rust, Linux, networking fundamentals, async programming, and low-level systems concepts.

The project prioritizes understanding and architecture over rapid feature development.

---

# Core Philosophy

The guiding philosophy is:

> Own the storage logic. Reuse mature interoperability protocols.

NAS-rs should not attempt to reimplement extremely mature and complex protocols such as SMB.

Instead:

* Samba handles SMB interoperability.
* Rust handles storage logic.
* Rust handles metadata.
* Rust handles indexing.
* Rust handles synchronization.
* Rust handles user management.
* Rust handles orchestration.

The project explicitly avoids becoming:

* A thin wrapper around Samba
* A pure SMB implementation
* A toy CRUD application
* A cloud-first SaaS product
* A distributed filesystem (initially)

---

# Original Project Vision

Originally the system was intended to:

* Host files on a home server
* Expose them via SMB
* Allow Windows, Linux, Android, and ChromeOS clients to access storage
* Provide user-isolated directories
* Offer an Android companion application

The original architecture looked like:

Android Client
↓
HTTP API
↓
Rust Backend
↓
Filesystem
↓
SMB (Samba)

Over time the project evolved toward a more user-centric approach.

---

# Current Product Direction

The project is no longer focused primarily on file sharing.

The project is now focused on:

* Personal storage
* Media organization
* Smart uploads
* Gallery experiences
* Migration from cloud ecosystems
* Family usability
* Mobile-first workflows

The project should feel closer to:

* Google Photos
* Google Drive
* Synology Photos
* Synology Drive
* Immich

than a traditional SMB share.

---

# Key Insight That Changed The Project

The major realization during planning was:

Users do not care about protocols.

Users care about:

* Uploading files
* Finding files
* Viewing memories
* Sharing media
* Synchronizing devices
* Organizing data

The protocol layer is merely an implementation detail.

This realization shifted focus away from:

* SMB
* NFS
* WebDAV

and toward:

* Metadata
* Storage architecture
* Gallery experiences
* Mobile integration
* Migration tools

---

# Target Audience

Primary audience:

* Home users
* Families
* Self-hosting enthusiasts
* Privacy-conscious users
* Users leaving cloud ecosystems

Secondary audience:

* Linux enthusiasts
* Home-lab operators
* Rust developers

The project should remain usable even for non-technical family members.

A major design goal is:

> A user's parents should be able to use the system without assistance.

---

# Major Differentiator

The most unique aspect of NAS-rs is not storage.

Storage is already solved.

The most interesting long-term differentiator is:

## Migration-Aware Storage

NAS-rs should help users reclaim data from closed ecosystems.

Example:

Google Photos Takeout exports.

Google provides:

* Files
* Metadata
* JSON sidecars

but the resulting export is often disorganized and difficult to use.

NAS-rs should eventually provide:

* Takeout import
* Metadata reconstruction
* Album reconstruction
* Timeline reconstruction
* Automatic media organization

This is considered one of the strongest future features.

---

# Storage Philosophy

Storage should be separated into:

## Raw Storage Layer

Responsible for:

* Files
* Directories
* Persistence

This layer stores bytes.

---

## Metadata Layer

Responsible for:

* MIME types
* Upload timestamps
* Media metadata
* Search indexes
* Albums
* User ownership

This layer stores meaning.

---

## Presentation Layer

Responsible for:

* Gallery views
* File manager views
* Timeline views
* Album views

The same stored data may be represented differently depending on context.

---

# Current Architecture Direction

Current architecture:

Android App
↓
HTTP API
↓
Rust Backend
↓
Storage Services
↓
Filesystem

The Rust backend owns:

* Storage orchestration
* Metadata indexing
* Authentication
* User management
* Upload processing

Protocol layers are independent.

---

# Planned User Experience

The Android application is expected to become the primary user-facing interface.

Planned sections:

## Photos

* Timeline
* Albums
* Camera uploads
* Media browsing

## Files

* Folder navigation
* Uploads
* Downloads

## Sync

* Camera backups
* Folder synchronization
* Background tasks

## Settings

* Account management
* Storage settings

Initially all functionality should live inside a single Android application.

Separate applications can be considered later if justified.

---

# Upload Pipeline Vision

Current implementation:

Upload
↓
File Saved

Target architecture:

Upload
↓
Temporary File
↓
SHA256 Calculation
↓
Durability Sync
↓
Atomic Rename
↓
Metadata Extraction
↓
Database Index

The upload pipeline should prioritize:

* Safety
* Correctness
* Crash recovery
* Atomicity

before optimization.

---

# Metadata Strategy

The filesystem is not the database.

The filesystem stores:

* File bytes

SQLite stores:

* Metadata
* Search indexes
* User ownership
* Media information

Future metadata may include:

* MIME type
* EXIF metadata
* GPS coordinates
* Camera information
* Upload timestamps
* File hashes

---

# Media-Oriented Design

A major realization during planning:

Users do not think in directories.

Users think in:

* Memories
* Dates
* Events
* Albums

Therefore the system should eventually support:

* Timeline browsing
* Album grouping
* Chronological organization

A gallery should not rely on directory structures.

It should rely on metadata indexes.

---

# Image Optimization Vision

The Android client may eventually support:

## Original Upload

Preserve original file.

## Optimized Upload

Resize large images to approximately 16 MP.

Compress using efficient formats.

## Space Saver

More aggressive compression.

The server should remain capable of storing original files whenever the user desires.

Data ownership is prioritized over storage efficiency.

---

# Security Direction

Long-term architecture includes:

* Client-side encryption
* Recovery phrases
* Certificate pinning
* Zero-knowledge storage

The server should eventually become incapable of understanding:

* File names
* Folder structures
* Media contents

Only clients should possess decryption keys.

This is a future objective and not part of the initial milestones.

---

# Current Development Status

The project is still in the foundational stage.

Implemented concepts:

* Axum server
* Multipart uploads
* Streaming uploads
* SHA256 hashing
* File persistence
* Basic application state
* Initial architecture factoring

Current focus:

* Clean architecture
* Service extraction
* Storage abstractions
* Metadata indexing preparation

Not yet implemented:

* SQLite metadata
* Authentication
* Gallery APIs
* Android client
* Synchronization engine
* Google Takeout importer

---

# Architectural Principles

Always prefer:

* Simplicity
* Correctness
* Clear ownership
* Layered architecture
* Protocol independence
* Incremental complexity

Avoid:

* Premature optimization
* Distributed systems complexity
* Protocol reimplementation
* Over-engineering
* Cargo-cult architecture

The project should evolve gradually through working milestones rather than speculative abstractions.

---

# Current Short-Term Roadmap

Phase 1:

* Clean upload architecture
* Storage service abstraction
* Atomic uploads
* Error handling

Phase 2:

* SQLite metadata index
* MIME detection
* File listing APIs

Phase 3:

* Gallery APIs
* Thumbnail generation
* Media timelines

Phase 4:

* Authentication
* Multi-user storage

Phase 5:

* Android application
* Upload integration
* Share intent support

Phase 6:

* Camera backups
* Background synchronization

Phase 7:

* Google Photos Takeout import
* Metadata reconstruction
* Timeline recovery

---

# Final Project Mission

NAS-rs is not trying to become another SMB server.

NAS-rs is not trying to become another file host.

NAS-rs aims to become:

"A self-hosted personal storage and digital memory platform focused on ownership, organization, migration, privacy, and long-term accessibility."



