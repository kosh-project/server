# Agent Context — August 2, 2026

## What Is This Project?
A zero-knowledge, privacy-first personal storage server (codenamed "Kosh") built in Rust.
Think: self-hosted Google Photos/Drive replacement running on cheap legacy hardware
(Intel Sandy Bridge i5, 10GB RAM, Arch Linux headless).

The server is intentionally a **"Dumb Bucket of Bits"** — it receives, stores, and serves
raw AES-GCM ciphertext without ever inspecting contents. All intelligence (encryption,
metadata, folder structure, thumbnails) lives on the Android client.

## Core Architecture

### Layers
```
Android Client (Kotlin)
  ├── Argon2id master key derivation (BIP-39 24-word phrase)
  ├── Google Tink AES-GCM encryption
  ├── Room DB metadata + Protobuf serialization
  └── HTTP REST API calls
        │
        ▼
Rust/Axum Server ("Dumb Bucket")
  ├── api/        — HTTP handlers + auth middleware
  ├── model/      — SQLite entities (User, Asset, Session)
  ├── storage/    — CAS filesystem (BLAKE3 hash-named blobs)
  ├── error/      — Domain errors + wrap_internal_err! macro
  └── app/        — AppState (SqlitePool, Moka cache, Storage service)
```

### Content-Addressed Storage (CAS)
- Upload streams into `<uuid>.tmp`, BLAKE3 hashed incrementally
- Atomic `rename(2)` to `<blake3_hash>` on success
- `fs4::fallocate` pre-allocates disk blocks (HDD fragmentation defense)
- EOF mismatch = immediate temp file deletion

### Reference-Counted Deletion
- Multiple users can "own" the same hash (deduplication)
- `Asset::delete()` removes ownership row in a SQLite transaction
- Physical file deleted ONLY when `SELECT COUNT(*) WHERE hash = ?` returns 0
- Transaction lock prevents race conditions

### Authentication
- Opaque UUID v4 session tokens, BLAKE3-hashed and stored in `sessions` table
- Moka in-memory cache (TTI 10min, capacity 10k) shields SQLite from repeated lookups
- `auth_guard` middleware extracts Bearer token → hash → cache/DB lookup → injects user_id
- Future: WebAuthn/Passkey fast-lane via `webauthn-rs` + DashMap challenge cache

## Database Schema (SQLite)
- `users`: id, identity_hash (BLOB UNIQUE), auth_verifier (TEXT)
- `assets`: id (UUID BLOB PK), user_id (FK), hash (BLOB), size_bytes, last_modified, tag
  - Index: `idx_assets_hash ON assets(hash)`
- `sessions`: token_hash (BLOB PK), user_id (FK), created_at, expires_at

## API Routes
| Method | Path | Auth | Handler |
|--------|------|------|---------|
| GET | /health | No | health check |
| POST | /api/auth/register | No | User::create |
| POST | /api/auth/login | No | User::verify → Session::create |
| POST | /api/v1/upload/{tag} | Yes | stream → CAS → Asset::create |
| GET | /api/v1/assets/{hash} | Yes | ownership check → stream blob |
| DELETE | /api/v1/assets/{hash} | Yes | Asset::delete → maybe delete_blob |
| GET | /api/v1/storage | Yes | (storage info) |

## Test Coverage (12+ tests)
- **model/asset.rs**: delete sole owner, delete shared ownership, delete unowned
- **storage/service.rs**: invalid filename, existing file rejection, concurrent writes, valid filename
- **storage/transaction.rs**: commit+hash, zero-byte, abort cleanup, missing vault, hardcoded hash, EOF mismatch
- **api/middleware.rs**: cache hit bypass
- **integration**: multipart upload integrity, health/storage smoke test
- Patterns: in-memory SQLite, tmpdir, async fixtures, serial_test for port binding

## Clippy Configuration
Extremely strict: `pedantic` + `nursery` = deny. Bans `unwrap`, `expect`, `panic`,
`as_conversions`, unchecked indexing, string slicing. Forces safe error handling everywhere.

## Error Architecture
- `crate::error::internal::Error` — catches low-level std errors (TryFromIntError, SystemTimeError, Infallible)
- `wrap_internal_err!` macro — generates From<StdErr> → DomainError via internal::Error (bypasses double-From limitation)
- Domain errors: `storage::Error`, `api::Error`, `model::Error` all have an `Internal(#[from] internal::Error)` variant

## What's Done
- Streaming CAS upload pipeline with BLAKE3
- Atomic tmp file transactions with fallocate + EOF validation
- User registration/login + opaque session auth
- Moka RAM session cache + auth_guard middleware
- Asset upload, download, delete handlers
- Reference-counted blob deletion with transaction lock
- Custom error macro for clean `?` operator usage
- 12+ passing unit/integration tests

## What's Pending
- Media listing endpoint: `GET /api/v1/assets` (paginated metadata queries)
- Action logging: `POST/GET /api/v1/sync/log` (encrypted event ledger)
- Progress reporting endpoint
- WebAuthn/Passkey auth (webauthn-rs + DashMap)
- SQLite WAL mode tuning
- API integration tests (upload→download, unauthorized download, delete→download)
- Storage service tests (delete_blob, get_blob)
- Android client app
- Google Takeout importer
