# Milestone 1: Root Envelope Encryption & Multi-Passkey Credential Management

## Scope
1. SQLite migration (`crates/server/migrations/20261024000000_passkey_and_envelope.sql`):
   - Add `wrapped_vault_key BLOB NOT NULL DEFAULT x''` to `users`.
   - Create `webauthn_credentials` table:
     - `credential_id BLOB PRIMARY KEY`
     - `user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE`
     - `passkey_data BLOB NOT NULL` (serialized WebAuthn Passkey struct)
     - `counter INTEGER NOT NULL DEFAULT 0` (replay protection)
     - `encrypted_metadata BLOB NOT NULL DEFAULT x''` (Zero-Knowledge: Client encrypts friendly info: name, device type, os, icons with `K_vault`)
     - `created_at INTEGER NOT NULL`
     - `last_used INTEGER NOT NULL DEFAULT 0`
2. Domain Model `crates/server/src/model/passkey.rs`:
   - Implement `PasskeyRecord` CRUD with `encrypted_metadata: Vec<u8>`.
3. Model Updates `crates/server/src/model/user.rs`:
   - Update `User::create` (accepts 60-byte `wrapped_vault_key`).
   - Update `User::verify` (returns `Verified { id, wrapped_vault_key }`).
   - Add `User::rotate_recovery`.
4. Session Updates `crates/server/src/model/session.rs`:
   - Add `find_other_token_hashes` and `revoke_other_sessions` for cache invalidation.
5. Ingest & Return `wrapped_vault_key`:
   - `register.rs`: Ingests 60-byte envelope, generates session token on 201 Created.
   - `login.rs`: Returns `wrapped_vault_key` (hex-encoded).
6. Implement `PUT /api/v1/auth/recovery` in `crates/server/src/api/auth/recovery.rs`:
   - Atomically updates credentials.
   - Evicts other sessions from Moka `session_cache` and SQLite.
7. Mount route and add automated tests.
