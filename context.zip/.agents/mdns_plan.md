This is exactly what your AntiGravity agent needs. Here is the highly structured, copy-pastable implementation plan.

Because we want this to be flawless and respect the exact invariants of your `Zero-Knowledge Storage Framework`, the instructions explicitly outline the threading model, error handling, and the Docker networking requirement.

---

### Architectural & Implementation Plan: Zero-Config mDNS Broadcast

## Goal Description

Implement a native, zero-dependency mDNS (Multicast DNS) responder in the Kosh Rust server.
Currently, the server binds to a raw IP address (e.g., `192.168.1.5`). Because the WebAuthn standard strictly rejects passkey registrations against raw IP addresses (Relying Party ID validation failure), users cannot use passwordless authentication on a local LAN. By broadcasting a `.local` domain natively (e.g., `kosh.local`), the Android client can resolve the server via DNS-SD, satisfy the WebAuthn origin checks, and allow 1-touch passkey logins on Day 1.

### Core Architectural Guarantees

* **Pure Rust / Zero Dependencies:** Use the `mdns-sd` crate (v0.21+). We explicitly avoid `zeroconf` or `mdns-sd-discovery` because they rely on host OS daemons (`avahi-daemon` via D-Bus). Kosh must run inside a minimal Docker container (e.g., Alpine) where no host daemon exists.
* **Port Contention Immunity:** The `mdns-sd` crate utilizes `SO_REUSEADDR` and `SO_REUSEPORT`. It binds to UDP Port `5353` and will peacefully coexist with a host machine's existing Avahi daemon without crashing.
* **No Tokio Blocking:** `mdns-sd` spawns its own native OS thread. The `ServiceDaemon` handle must be kept alive for the duration of the Axum server process.
* **RFC 6762 Compliance (Tiebreaking):** If the configured hostname (e.g., `kosh.local`) is already taken on the network, the engine will automatically append an incremental numeric suffix (e.g., `kosh-2.local`) to prevent network collisions.

---

## Implementation Directives

### Phase 1: Dependencies & Configuration

1. Add `mdns-sd = "0.21"` to `crates/server/Cargo.toml`.
2. Update the `Config` struct in `crates/server/src/config/mod.rs` to include:
```rust
pub mdns_hostname: Option<String>,

```


*(The default value should fall back to `"kosh"` if the admin does not specify it in `config.toml`)*.

### Phase 2: The mDNS Module (`crates/server/src/mdns.rs`)

Create a new module encapsulating the broadcast logic.

```rust
use mdns_sd::{ServiceDaemon, ServiceInfo};
use std::collections::HashMap;
use std::net::IpAddr;

/// Spawns a background OS thread that broadcasts the server's presence
/// on UDP Port 5353 to the local network. 
pub fn broadcast_kosh_service(
    hostname: &str, 
    port: u16,      
    ips: Vec<IpAddr>
) -> Result<ServiceDaemon, Box<dyn std::error::Error>> {
let daemon = ServiceDaemon::new()?;

// Defines the service as a secure web endpoint
let service_type = "_https._tcp.local.";
let instance_name = "Kosh Vault";

// Enforce the .local TLD
let host_fqdn = format!("{}.local.", hostname.trim_end_matches(".local"));

let mut properties = HashMap::new();
properties.insert("version".to_string(), env!("CARGO_PKG_VERSION").to_string());

let service_info = ServiceInfo::new(
    service_type,
    instance_name,
    &host_fqdn,
    &ips.iter().map(|ip| ip.to_string()).collect::<Vec<_>>()[..],
    port,
    properties
)?;

daemon.register(service_info)?;
tracing::info!("mDNS Broadcasting: {} -> {:?}", host_fqdn, ips);

Ok(daemon)
}

```

### Phase 3: Integration into Server Boot (`crates/server/src/main.rs`)

Integrate the module right before the Axum listener binds.

* Ensure you capture the returned `ServiceDaemon` handle and keep it in scope! If the handle drops, the background thread terminates and the broadcast stops.
* Use the existing `local_ip_address::list_afinet_netifas()` call (which you already use for the self-signed TLS certificate generation) to supply the `ips` argument.

```rust
// In main.rs or builder.rs setup:
let hostname = config.mdns_hostname.clone().unwrap_or_else(|| "kosh".to_string());

// KEEP this handle alive for the lifetime of the application
let _mdns_handle = mdns::broadcast_kosh_service(&hostname, config.port, local_ips)
.expect("Failed to bind mDNS port 5353. Check permissions.");

```

### Phase 4: Update the Terminal QR Pairing Code (`crates/server/src/tls/qr.rs`)

When rendering the ASCII QR code for the Android client's Trust-On-First-Use (TOFU) pairing, you must swap the raw IP address for the mDNS hostname.

* **Old Format:** `kosh://192.168.1.5:8443?pin=<SHA256>`
* **New Format:** `kosh://kosh.local:8443?pin=<SHA256>`
*(Note: Use the actual configured `hostname` string in the format macro).*

---

## ⚠ Docker Containerization Invariant

When we proceed to the Docker implementation, it is **absolutely critical** that the `docker-compose.yml` file includes the following networking directive:

```yaml
    network_mode: "host"

```

**Reasoning:** Docker isolates containers on a virtual bridged network (`172.17.x.x`). Linux bridge networks do not forward link-local multicast packets (`224.0.0.251`) to the physical ethernet/Wi-Fi adapter. Without `network_mode: "host"`, the mDNS UDP packets will be trapped inside the Docker bridge, and the Android client will never resolve `kosh.local`. By using host mode, the Rust binary binds directly to the physical network interface.


This is a great question about developer experience (DX).

When building a self-hosted tool, you want to expose enough configuration so that power users can integrate your tool into complex network topologies, but you don't want to expose so much that a beginner accidentally breaks the protocol.

Here is a breakdown of what you should expose in `config.toml`, what you should definitely hardcode, and why.

### 1. What you MUST allow the admin to configure:

* **The Hostname (`mdns_hostname`):**
This is the most important one. If Alice runs two Kosh servers (one for her family, one for her business), they cannot both be `kosh.local`. She needs to be able to set one to `family-vault` and the other to `kosh-biz`.
* **The Network Interfaces (Optional but highly appreciated by Sysadmins):**
By default, the server will bind to all available IP addresses (Wi-Fi, Ethernet, VPN tunnels). However, a sysadmin might only want Kosh to broadcast on their secure VLAN interface and remain invisible on the guest Wi-Fi.
You can add a config option like `mdns_interfaces: Option<Vec<String>>` (e.g., `["eth1", "wg0"]`). If provided, you filter the IPs passed to `mdns::broadcast_kosh_service()`.

### 2. What you can OPTIONALLY expose as "Properties" (TXT Records):

mDNS allows you to broadcast a key-value dictionary alongside the IP address. This is called a `TXT record`.
Currently, the plan has you hardcoding the server version:

```rust
properties.insert("version".to_string(), env!("CARGO_PKG_VERSION").to_string());

```

Other properties a developer or admin might appreciate seeing when they run a network discovery tool:

* **`admin_contact`:** (e.g., `"admin@tony.dev"`)
* **`environment`:** (e.g., `"production"`, `"staging"`)
* **`tls_enabled`:** (e.g., `"true"`, `"false"`)

You could add a `[mdns.properties]` table in your `config.toml` that loops through and inserts any custom keys the admin wants to broadcast.

### 3. What you MUST HARDCODE (Do not let the user configure this):

You should absolutely **hardcode** the `service_type` and the `instance_name`. Do not put these in `config.toml`.

* **The Service Type (`_https._tcp.local.`):**
This is a strictly standardized IANA identifier. If a user changes this to `_kosh._tcp.local.`, their web browser (or Android Credential Manager) won't recognize the server as a secure web endpoint. The Passkey WebAuthn spec requires a valid HTTPS origin, and changing this breaks the fundamental WebAuthn trust model you are building.
* **The Instance Name (`Kosh Vault`):**
This is the human-readable string that shows up in Bonjour browsers. Keeping this hardcoded to `"Kosh Vault"` ensures that if someone is diagnosing network traffic, they instantly know what software is running on port 8443, rather than seeing a generic or user-modified string that obscures the software identity.

### The Recommended `config.toml` structure

Based on this, here is how you should design the mDNS section in your configuration file:

```toml
[server]
port = 8443
tls_enabled = true

# The mDNS configuration block
[mdns]
# The .local domain name. (e.g., setting "tony-nas" broadcasts "tony-nas.local")
# If left empty, defaults to "kosh".
hostname = "tony-nas" 

# (Optional) Restrict mDNS broadcast to specific network interfaces.
# If empty or commented out, it broadcasts on all active LAN interfaces.
# interfaces = ["eth0", "wlan0"]

# (Optional) Custom TXT properties visible to network discovery tools.
[mdns.properties]
environment = "production"
owner = "tony"

```

This strikes the perfect balance. It gives the sysadmin total control over routing and naming, but locks down the cryptographic and protocol-level identifiers so they cannot accidentally break the zero-knowledge WebAuthn flows!