# Server Crate Digest
> Last updated: 2026-08-21

## What This Crate Is

`crates/server` is the main library+binary for the Kosh self-hosted storage server.
Structured as a **library crate** (with a thin `main.rs` binary entry point) for testability.

The server is a **zero-knowledge encrypted blob store** built on:
- **Axum** (HTTP framework)
- **SQLite via sqlx** (metadata database)
- **BLAKE3** (content-addressable storage hashing)
- **Moka** (in-memory session cache)
- **tokio** (async runtime)

---

## Layer Architecture

```
HTTP Request
    ↓
log_middleware          (post-response: collects error telemetry from Response::extensions)
    ↓
auth_guard              (Moka RAM cache → SQLite fallback, injects user_id into extensions)
    ↓
Route Handler           (api layer: parses input, delegates to model+storage)
    ↓
Model Layer             (sqlx queries: users, sessions, assets)
Storage Layer           (CAS vault on disk: streaming writes, BLAKE3 hashing, atomic rename)
    ↓
crate::Error::into_response()  (single sanitization point + telemetry packing)
    ↓
HTTP Response
```

---

## Module Map

### `api/`
- **`route.rs`** — Top-level Axum router.
  - Public routes: `GET /health`, `POST /api/auth/register`, `POST /api/auth/login`
  - Protected routes (behind `auth_guard`): `POST /api/v1/upload/{tag}`, `GET /api/v1/assets/{hash}`, `DELETE /api/v1/assets/{hash}`, `GET /api/v1/storage`
- **`assets.rs`** — Upload, download, delete handlers. All three fully implemented.
- **`auth/register.rs`** — Registers new user (201), catches unique violation → 409 Conflict.
- **`auth/login.rs`** — Verifies credentials, creates session, returns opaque token.
- **`middleware/auth_guard.rs`** — Validates Bearer token: Moka cache first, SQLite fallback.
- **`middleware/log.rs`** — Post-response middleware: extracts Entry from extensions, fires to GLOBAL_LOGGER.
- **`error.rs`** — `api::Error` enum covering BadRequest, Unauthorized, NotFound, etc.

### `app/`
- **`state.rs`** — `State` struct: `storage: storage::Service`, `db: SqlitePool`, `session_cache: Cache<TokenHash, UserId>`. All fields Arc-backed, cheap to clone.
- **`builder.rs`** — `AppStateBuilder` fluent builder. Default Moka cache: 10min TTI, 10k capacity.

### `model/`
- **`user.rs`** — `User::create()`, `User::verify()`. No raw passwords. Stores identity_hash (BLOB) + auth_verifier (TEXT).
- **`session.rs`** — `Session::create()` generates UUID v4, stores BLAKE3 hash. `Session::verify()` checks hash + 30-day TTL. `TokenHash` is [u8; 32] newtype for Moka.
- **`asset.rs`** — `Asset::create()`, `Asset::delete()` (ref-counted, returns bool), `Asset::owned_by()`. Transactional delete.
- **`error.rs`** — `model::Error` covering Database(sqlx::Error), AssetNotFound, Internal.

### `storage/`
- **`service.rs`** — `Service` wraps `vault_path: PathBuf`. Provides `try_save()`, `get_blob()`, `delete_blob()`. Path traversal protection.
- **`transaction.rs`** — Streams body → temp file → BLAKE3 hash → atomic rename to `vault/{hash}`. Cleans up temp file on failure.
- **`file.rs`** — `Payload<S, E>` newtype bundling `expected_size: u64` + stream.
- **`error.rs`** — `storage::Error` with 9 variants. Sanitized IntoResponse.

### `logger/`
- **`service.rs`** — Background MPSC task. Writes bincode to daily `.bin` files + broadcasts to `/tmp/kosh-cli.sock`.
- **`macro.rs`** — `info!()`, `warn!()`, `error!()`, `fatal!()`, `shutdown!()` macros.
- **`loggable.rs`** — `Loggable` trait: `log_level()` + `log_module()`. Implemented on all error types.

### `error/`
- **`mod.rs`** — Top-level `crate::Error` hub. Packs telemetry into `Response::extensions` BEFORE consuming self, then delegates.
- **`internal.rs`** — `internal::Error` + `wrap_internal_err!` macro for double-From chains.

---

## Database Schema

```sql
-- users
id INTEGER PRIMARY KEY AUTOINCREMENT
identity_hash BLOB NOT NULL UNIQUE
auth_verifier TEXT NOT NULL

-- sessions
token_hash BLOB PRIMARY KEY
user_id INTEGER NOT NULL → users(id) ON DELETE CASCADE
created_at INTEGER NOT NULL
expires_at INTEGER NOT NULL

-- assets
id BLOB PRIMARY KEY  -- UUID v4 bytes
user_id INTEGER → users(id) ON DELETE CASCADE
hash BLOB NOT NULL   -- BLAKE3 hash (CAS key)
size_bytes INTEGER NOT NULL
last_modified INTEGER NOT NULL
tag TEXT NOT NULL    -- 0=GalleryMeta 1=GalleryItem 2=DriveMeta 3=DriveItem
INDEX idx_assets_hash ON assets(hash)
```

---

## Existing Tests (19 passing)

### Unit tests
- `auth_guard_bypasses_db_on_cache_hit` — Moka checked before SQLite
- `delete_asset_with_single_owner` — ref count 0 → wipe needed
- `delete_asset_with_more_than_one_owners` — ref count > 0 → no wipe
- `attempt_to_delete_unowned_asset` — cross-user delete blocked
- `broadcasting_works_via_unix_socket` — UDS broadcast works
- `file_rotation_on_every_new_day` — two dates → two .bin files
- `logger_commits_multiple_entries_to_disk` — bincode framing correct
- `aborted_test_cleans_up_garbage` — mid-stream failure → temp file deleted
- `transaction_fails_if_vault_missing` — correct error type returned
- `hardcoded_hash_correctness` — BLAKE3("hello world") verified
- `zero_byte_stream_creates_empty_file` — 0-byte upload succeeds
- `successful_commit_and_hash` — full commit cycle
- `mismatch_content_fails_plus_cleans_up` — EOF before expected_size → cleanup
- `concurrent_write_collisions_dont_panic` — CAS dedup safe
- `validation_success` — valid filename passes
- `reject_invalid_filename` — / and \ rejected
- `validation_rejects_existing_file` — duplicate blocked

### Integration tests
- `test_multipart_upload_integrity` — full register+login+upload+verify pipeline
- `quick_dev` — smoke test: /health and /storage respond

---

## What Is NOT Tested Yet (Prioritized)

### HIGH — Security-Critical
1. `register` → 409 Conflict on duplicate user (HTTP level)
2. `register` → 400 Bad Request on invalid hex identity_hash
3. `login` → 401 on wrong auth_verifier
4. `login` → 401 on non-existent identity_hash
5. `auth_guard` → 401 on missing Authorization header
6. `auth_guard` → 401 on invalid/expired token (DB fallback path)

### MEDIUM — Business Logic
7. `DELETE /api/v1/assets/{hash}` — full HTTP round-trip
8. `GET /api/v1/assets/{hash}` — ownership check + streaming
9. `GET /api/v1/assets/{hash}` — 404 on cross-user access
10. `upload` → 400 on missing X-File-Name header
11. `upload` → 400 on payload exceeding 10GB limit
12. `AssetTag::try_from` — invalid tag → 400

### LOWER — Infrastructure
13. `Session::verify` — expired session returns None
14. `User::verify` — returns None (not error) on wrong verifier
15. `storage::Service::delete_blob` — blob actually deleted from vault

---

## Key Architecture Rules
- Server never sees plaintext content. All blobs arrive AES-GCM encrypted.
- CAS: BLAKE3 hash is the key. Two users uploading same content share one physical file.
- Opaque sessions: UUID v4 on wire, BLAKE3 hash stored. Raw token never persists.
- Moka cache: 10-min TTI. Natural expiry aligns with DB revocation.
- All errors sanitized: internal details never reach HTTP client.
- AppStateBuilder: the ONLY correct way to build AppState in both main.rs and tests.
