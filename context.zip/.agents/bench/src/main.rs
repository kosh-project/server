use std::{
    fs,
    net::IpAddr,
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};
use blake3::Hasher;
use governor::{Quota, RateLimiter};
use reqwest::Client;
use serde_json::Value;
use sha2::{Digest, Sha256};
use uuid::Uuid;

const VAULT_SECRET_PATH: &str = "/home/ton3s/.config/kosh/vault/server.secret";
const TARGET_HOST: &str = "https://127.0.0.1:23342";

struct TokenHelper {
    secret_bytes: [u8; 32],
}

impl TokenHelper {
    fn new(secret_bytes: [u8; 32]) -> Self {
        Self { secret_bytes }
    }

    fn generate_valid_token(&self, session_id: &Uuid, ttl_secs: u64) -> String {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        let expires_at = now + ttl_secs;
        let payload = format!("{session_id}.{expires_at:016x}");
        let mac = blake3::keyed_hash(&self.secret_bytes, payload.as_bytes());
        format!("{payload}.{mac}")
    }

    fn generate_forged_token(&self, session_id: &Uuid) -> String {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        let expires_at = now + 3600;
        let payload = format!("{session_id}.{expires_at:016x}");
        let bad_secret = [0x55u8; 32];
        let mac = blake3::keyed_hash(&bad_secret, payload.as_bytes());
        format!("{payload}.{mac}")
    }
}

fn solve_pow(identity_hash: &str, challenge: &str) -> (String, u64, Duration) {
    let start = Instant::now();
    let mut nonce_num: u64 = 0;
    loop {
        let nonce = format!("{nonce_num:016x}");
        let header = format!("{identity_hash}{nonce}{challenge}");
        let hash = Sha256::digest(header.as_bytes());
        if hash[0] == 0 && hash[1] == 0 {
            let elapsed = start.elapsed();
            return (header, nonce_num + 1, elapsed);
        }
        nonce_num += 1;
    }
}

fn verify_pow_mock(header: &str, ip: IpAddr, secret_key: &[u8; 32]) -> bool {
    if header.len() != 165 && header.len() != 168 {
        return false;
    }
    let hash = Sha256::digest(header.as_bytes());
    if hash[0] != 0 || hash[1] != 0 {
        return false;
    }
    let timestamp_hex = &header[80..96];
    let mac_hex = &header[96..160];
    let action = &header[160..];

    if action != "login" && action != "register" {
        return false;
    }
    let mut hasher = Hasher::new_keyed(secret_key);
    hasher.update(timestamp_hex.as_bytes());
    match ip {
        IpAddr::V4(v4) => hasher.update(&v4.octets()),
        IpAddr::V6(v6) => hasher.update(&v6.octets()),
    };
    hasher.update(action.as_bytes());
    let expected_mac = hasher.finalize();
    expected_mac.to_hex().as_str() == mac_hex
}

fn get_rss_kb() -> usize {
    if let Ok(statm) = fs::read_to_string("/proc/self/statm") {
        let parts: Vec<&str> = statm.split_whitespace().collect();
        if parts.len() >= 2 {
            if let Ok(pages) = parts[1].parse::<usize>() {
                return pages * 4; // 4KB page size
            }
        }
    }
    0
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== KOSH STORAGE SERVER INGRESS DEFENSE BENCHMARK HARNESS ===");

    // Read real server secret
    let secret_raw = fs::read(VAULT_SECRET_PATH)?;
    let mut secret_bytes = [0u8; 32];
    secret_bytes.copy_from_slice(&secret_raw[..32]);
    let token_helper = TokenHelper::new(secret_bytes);

    let client = Client::builder()
        .danger_accept_invalid_certs(true)
        .pool_idle_timeout(Duration::from_secs(30))
        .pool_max_idle_per_host(50)
        .build()?;

    // -------------------------------------------------------------
    // PART 1: Microbenchmarks (Server vs Client CPU Cost)
    // -------------------------------------------------------------
    println!("\n--- Part 1: Cryptographic Microbenchmarks ---");
    let test_identity = "86d1a4c7afa29b83064448d29b5e4a4d0ee8c1bbcf818a13870302413d9f1a48";
    let mock_ip: IpAddr = "127.0.0.1".parse()?;
    let mock_secret = [0x42u8; 32];

    // Measure Client Solve Time across 10 trials
    let mut total_solve_time = Duration::ZERO;
    let mut total_trials = 0u64;
    for i in 0..10 {
        let now_hex = format!("{:016x}", 1700000000 + i);
        let mut h = Hasher::new_keyed(&mock_secret);
        h.update(now_hex.as_bytes());
        h.update(&[127, 0, 0, 1]);
        h.update(b"login");
        let mac = h.finalize();
        let chal = format!("{}{}{}", now_hex, mac.to_hex(), "login");
        let (_header, trials, dur) = solve_pow(test_identity, &chal);
        total_solve_time += dur;
        total_trials += trials;
    }
    let avg_solve_time = total_solve_time / 10;
    let avg_trials = total_trials / 10;
    println!("Client PoW Solve (Average over 10 runs):");
    println!("  Iterations: {avg_trials} SHA-256 cycles");
    println!("  Elapsed: {:.2?} (at ~{:.2} Mhash/s)", avg_solve_time, (avg_trials as f64) / (avg_solve_time.as_secs_f64() * 1_000_000.0));

    // Measure Server Verification Time over 100,000 iterations
    let sample_chal = format!("{:016x}{}login", 1700000000, blake3::hash(b"test").to_hex());
    let (sample_header, _, _) = solve_pow(test_identity, &sample_chal);
    let verify_start = Instant::now();
    let iters = 100_000;
    for _ in 0..iters {
        std::hint::black_box(verify_pow_mock(&sample_header, mock_ip, &mock_secret));
    }
    let verify_total = verify_start.elapsed();
    let verify_per_op = verify_total / iters;
    println!("Server PoW Verification (Average over 100,000 runs):");
    println!("  Elapsed: {:.2?} per verification ({:.1} ns)", verify_per_op, verify_per_op.as_nanos() as f64);

    let asymmetry_ratio = avg_solve_time.as_nanos() as f64 / verify_per_op.as_nanos() as f64;
    println!("PoW Work Asymmetry Factor: {:.0}:1", asymmetry_ratio);

    // Microbenchmark BLAKE3 MAC check for mac_guard
    let valid_token = token_helper.generate_valid_token(&Uuid::new_v4(), 3600);
    let mac_start = Instant::now();
    for _ in 0..iters {
        let payload = &valid_token[..53];
        let mac_hex = &valid_token[54..];
        let exp = blake3::keyed_hash(&secret_bytes, payload.as_bytes());
        std::hint::black_box(exp.to_hex().as_str() == mac_hex);
    }
    let mac_total = mac_start.elapsed();
    let mac_per_op = mac_total / iters;
    println!("Server mac_guard BLAKE3 check (Average over 100,000 runs):");
    println!("  Elapsed: {:.2?} per check ({:.1} ns)", mac_per_op, mac_per_op.as_nanos() as f64);

    // -------------------------------------------------------------
    // PART 2: Real HTTP/TLS Ingress Funnel Measurements
    // -------------------------------------------------------------
    println!("\n--- Part 2: End-to-End Ingress Funnel Evaluation ---");

    // Case 1: Fresh challenge from server and real solve
    let chal_resp: Value = client
        .get(format!("{TARGET_HOST}/api/auth/challenge?action=login"))
        .send()
        .await?
        .json()
        .await?;
    let challenge_str = chal_resp["challenge"].as_str().unwrap();
    println!("Obtained live PoW challenge from server: {}", &challenge_str[..30]);
    let (header, solve_trials, solve_dur) = solve_pow(test_identity, challenge_str);
    println!("Solved live PoW in {:.2?} (trials: {solve_trials})", solve_dur);

    // Case 2: Submit invalid PoW to POST /api/auth/login
    let bad_header = format!("{}0000000000000000{}", test_identity, challenge_str);
    let t0 = Instant::now();
    let res = client
        .post(format!("{TARGET_HOST}/api/auth/login"))
        .header("Content-Type", "application/json")
        .header("X-Hashcash", &bad_header)
        .body(r#"{"identity_hash":"86d1a4c7afa29b83064448d29b5e4a4d0ee8c1bbcf818a13870302413d9f1a48","auth_verifier":"test"}"#)
        .send()
        .await?;
    let lat_bad_pow = t0.elapsed();
    println!("Invalid PoW submission -> Status: {}, Latency: {:.2?}", res.status(), lat_bad_pow);

    // Case 3: Submit VALID PoW to POST /api/auth/login
    tokio::time::sleep(Duration::from_millis(500)).await;
    let t0 = Instant::now();
    let res = client
        .post(format!("{TARGET_HOST}/api/auth/login"))
        .header("Content-Type", "application/json")
        .header("X-Hashcash", &header)
        .body(r#"{"identity_hash":"86d1a4c7afa29b83064448d29b5e4a4d0ee8c1bbcf818a13870302413d9f1a48","auth_verifier":"incorrect_password_hash"}"#)
        .send()
        .await?;
    let lat_valid_pow = t0.elapsed();
    let body_text = res.text().await?;
    println!("Valid PoW submission (Passed PoW -> Handler checks verifier) -> Latency: {:.2?}, Body: {}", lat_valid_pow, body_text.trim());

    // -------------------------------------------------------------
    // PART 3: Layer 3 (mac_guard) vs Layer 4 (Device Governor) vs DB Miss
    // -------------------------------------------------------------
    println!("\n--- Part 3: Layer 3 & Layer 4 Evaluation ---");
    tokio::time::sleep(Duration::from_millis(1000)).await;

    // Test forged token on /api/v1/storage (Layer 3 stateless rejection in RAM)
    let forged_token = token_helper.generate_forged_token(&Uuid::new_v4());
    let mut forged_latencies = Vec::new();
    for _ in 0..20 {
        tokio::time::sleep(Duration::from_millis(50)).await; // avoid hitting global IP limit
        let t0 = Instant::now();
        let res = client
            .get(format!("{TARGET_HOST}/api/v1/storage"))
            .header("Authorization", format!("Bearer {forged_token}"))
            .send()
            .await?;
        assert_eq!(res.status(), 401);
        forged_latencies.push(t0.elapsed());
    }
    forged_latencies.sort();
    let p50_forged = forged_latencies[forged_latencies.len() / 2];
    let p90_forged = forged_latencies[forged_latencies.len() * 9 / 10];
    println!("Layer 3 Forged Token Rejection (mac_guard in RAM):");
    println!("  p50 Latency: {:.2?}, p90 Latency: {:.2?}", p50_forged, p90_forged);

    // Test validly signed token with non-existent session in DB (Passes mac_guard, misses cache, queries SQLite)
    let valid_unknown_token = token_helper.generate_valid_token(&Uuid::new_v4(), 3600);
    let mut db_miss_latencies = Vec::new();
    for _ in 0..20 {
        tokio::time::sleep(Duration::from_millis(70)).await;
        let t0 = Instant::now();
        let res = client
            .get(format!("{TARGET_HOST}/api/v1/storage"))
            .header("Authorization", format!("Bearer {valid_unknown_token}"))
            .send()
            .await?;
        assert_eq!(res.status(), 401);
        db_miss_latencies.push(t0.elapsed());
    }
    db_miss_latencies.sort();
    let p50_db_miss = db_miss_latencies[db_miss_latencies.len() / 2];
    let p90_db_miss = db_miss_latencies[db_miss_latencies.len() * 9 / 10];
    println!("Validly Signed Token SQLite Miss (auth_guard database lookup):");
    println!("  p50 Latency: {:.2?}, p90 Latency: {:.2?}", p50_db_miss, p90_db_miss);
    println!("  Database Query Overhead: +{:.2?}", p50_db_miss.saturating_sub(p50_forged));

    // Test Layer 4 Device Governor Throttling
    tokio::time::sleep(Duration::from_millis(500)).await;
    let device_token = token_helper.generate_valid_token(&Uuid::new_v4(), 3600);
    println!("\nTesting Layer 4 Authenticated Device Governor (burst 5, period 66ms):");
    for i in 1..=8 {
        let t0 = Instant::now();
        let res = client
            .get(format!("{TARGET_HOST}/api/v1/storage"))
            .header("Authorization", format!("Bearer {device_token}"))
            .send()
            .await?;
        let code = res.status();
        let lat = t0.elapsed();
        let retry_header = res.headers().get("retry-after").and_then(|v| v.to_str().ok()).unwrap_or("none");
        println!("  Request {i}: Status {code} (lat: {lat:.2?}, retry-after: {retry_header})");
    }

    // -------------------------------------------------------------
    // PART 4: Keyed Governor State Memory Footprint (Answering Gap 2)
    // -------------------------------------------------------------
    println!("\n--- Part 4: Keyed Governor State Memory Footprint Simulation (Gap 2) ---");
    let rss_before = get_rss_kb();
    let quota = Quota::per_second(std::num::NonZeroU32::new(15).unwrap())
        .allow_burst(std::num::NonZeroU32::new(5).unwrap());
    let limiter: RateLimiter<[u8; 32], governor::state::keyed::DefaultKeyedStateStore<[u8; 32]>, governor::clock::DefaultClock> =
        RateLimiter::keyed(quota);

    println!("Initial Process RSS: {rss_before} KB");
    let t_populate_start = Instant::now();
    for i in 0..100_000u64 {
        let mut key = [0u8; 32];
        key[0..8].copy_from_slice(&i.to_le_bytes());
        let _ = limiter.check_key(&key);
    }
    let populate_time = t_populate_start.elapsed();
    let rss_100k = get_rss_kb();
    let mem_diff_100k = rss_100k.saturating_sub(rss_before);
    println!("100,000 distinct [u8; 32] TokenHash keys inserted:");
    println!("  Time taken: {:.2?}", populate_time);
    println!("  Process RSS at 100k keys: {rss_100k} KB (delta: +{mem_diff_100k} KB, ~{:.1} bytes/key)", (mem_diff_100k as f64 * 1024.0) / 100_000.0);

    for i in 100_000..500_000u64 {
        let mut key = [0u8; 32];
        key[0..8].copy_from_slice(&i.to_le_bytes());
        let _ = limiter.check_key(&key);
    }
    let rss_500k = get_rss_kb();
    let mem_diff_500k = rss_500k.saturating_sub(rss_before);
    println!("500,000 distinct [u8; 32] TokenHash keys inserted:");
    println!("  Process RSS at 500k keys: {rss_500k} KB (delta: +{mem_diff_500k} KB, ~{:.1} bytes/key)", (mem_diff_500k as f64 * 1024.0) / 500_000.0);

    // Measure lookup latency on warm map with 500,000 keys
    let t_lookup_start = Instant::now();
    let iters_lookup = 100_000;
    for i in 0..iters_lookup {
        let mut key = [0u8; 32];
        key[0..8].copy_from_slice(&(i as u64).to_le_bytes());
        let _ = limiter.check_key(&key);
    }
    let lookup_time = t_lookup_start.elapsed();
    let per_lookup_ns = lookup_time.as_nanos() as f64 / iters_lookup as f64;
    println!("Lookup latency in 500,000-key governor map: {:.1} ns per check", per_lookup_ns);

    println!("\n--- All Benchmarks Completed Successfully ---");
    Ok(())
}
