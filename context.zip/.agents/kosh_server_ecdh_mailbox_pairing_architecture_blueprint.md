# 🚀 Kosh Server (koshd): ECDH Mailbox & Device Pairing Blueprint

## 1. Architectural Context for the Agent

**Agent Directive:**
Because Kosh utilizes an internal `AndroidKeyStore` passkey bypass, native WebAuthn cross-device login (CTAP2/caBLE) cannot be used. We must facilitate device pairing (passing the encrypted `K_vault` and granting server access) using an "ECDH Mailbox" architecture.

To prevent Denial of Service (DoS) attacks from unauthenticated clients filling up the SQLite database, **all mailbox states MUST be stored in memory using a RAM-only cache (e.g., the `moka` crate)**. 

SQLite is strictly forbidden for the ephemeral mailbox lifecycle.

---

## 2. Mailbox Storage & Security Primitives

### 2.1 The Moka Cache Implementation
The Axum shared state must instantiate a `moka::sync::Cache` (or `moka::future::Cache`) with the following strict parameters:
*   `time_to_live`: 5 minutes (300 seconds).
*   `max_capacity`: 1,000 entries.

This guarantees that even under a heavy spam attack, the server's memory footprint will not exceed a few megabytes, and old spam entries will be automatically evicted.

### 2.2 Proof of Work (Hashcash)
All unauthenticated routes that create or mutate a mailbox in the Moka cache MUST require a valid Hashcash Proof-of-Work (PoW) header to impose a CPU tax on the client.

### 2.3 The Registration Ticket (`registration_ticket`)
Because the new device has no passkey, it cannot log in. The authenticated device must mint a short-lived `registration_ticket`. 
When the new device attempts to register its newly generated passkey at `/api/auth/passkey/register`, it will place this `registration_ticket` in the `Authorization: Bearer` header. The server must validate this ticket as a one-time-use pass to bypass the standard authentication requirement for registration.

---

## 3. Bidirectional Pairing State Machine & API Routes

The server must act as a "Dumb Routing Bucket" supporting two distinct UX flows.

### Flow A: Mobile Flow (Authenticated Device Scans New Device)

**1. Create Orphaned Mailbox**
*   **Route:** `POST /api/auth/mailbox/open` (Unauthenticated)
*   **Headers:** Requires PoW token.
*   **Payload:** `{ "pub_temp": "Base64(X25519_Public_Key)" }`
*   **Action:** Server generates a random UUID (`mailbox_id`) and a cryptographically secure random `polling_token`. Stores in Moka cache with state `ReadyForFulfillment`.
*   **Response:** `{ "mailbox_id": "...", "polling_token": "..." }`

**2. Mint Registration Ticket**
*   **Route:** `POST /api/v1/devices/link-ticket` (Authenticated via Bearer Token)
*   **Action:** Validates the active session and generates a 5-minute `registration_ticket`.
*   **Response:** `{ "registration_ticket": "..." }`

**3. Fulfill Mailbox**
*   **Route:** `POST /api/v1/devices/mailbox/{mailbox_id}/fulfill` (Authenticated via Bearer Token)
*   **Payload:** `{ "ciphertext": "Base64(Encrypted K_vault + Ticket)" }`
*   **Action:** Server updates the Moka cache entry for `{mailbox_id}` to state `Fulfilled`, attaching the ciphertext.

**4. Pickup Ciphertext**
*   **Route:** `GET /api/auth/mailbox/{mailbox_id}/pickup` (Unauthenticated)
*   **Headers:** `Authorization: Bearer <polling_token>`
*   **Action:** If state is `Fulfilled`, returns the ciphertext and instantly invalidates/removes the mailbox from the Moka cache.

---

### Flow B: Desktop/TV Flow (New Device Scans Authenticated Device)

**1. Create Offered Mailbox**
*   **Route:** `POST /api/v1/devices/mailbox/offer` (Authenticated via Bearer Token)
*   **Action:** Server generates `mailbox_id`. Stores in Moka cache with state `WaitingForJoin`.
*   **Response:** `{ "mailbox_id": "..." }`

**2. Join Mailbox**
*   **Route:** `POST /api/auth/mailbox/{mailbox_id}/join` (Unauthenticated)
*   **Headers:** Requires PoW token.
*   **Payload:** `{ "pub_temp": "Base64(X25519_Public_Key)" }`
*   **Action:** Server verifies state is `WaitingForJoin`. Updates state to `ReadyForFulfillment` and attaches `pub_temp`. Generates and returns a `polling_token` to the new device.
*   **Response:** `{ "polling_token": "..." }`

**3. Authenticated Polling**
*   **Route:** `GET /api/v1/devices/mailbox/{mailbox_id}/status` (Authenticated)
*   **Action:** Old device polls this to get the new device's `pub_temp` once the state shifts to `ReadyForFulfillment`.

**4. Fulfill & Pickup**
*   *(Proceeds exactly as Steps 3 and 4 in Flow A).*

---

## 4. Final Passkey Registration

Once the new device decrypts the payload, it MUST register its new hardware-backed passkey.

*   **Route:** `POST /api/auth/passkey/register` (Unauthenticated standard endpoint)
*   **Headers:** `Authorization: Bearer <registration_ticket>` (Instead of a standard session token).
*   **Action:** 
    1. Server verifies the `registration_ticket` is valid, unexpired, and associated with the user account of the device that minted it.
    2. Server executes standard `webauthn-rs` registration logic.
    3. Server saves the new passkey credential to the SQLite database.
    4. Server invalidates the `registration_ticket`.
    5. Server issues and returns a standard long-lived Session Token.

**Agent Directive:** Ensure the passkey registration handler is modular enough to accept EITHER a standard session token (for adding a passkey from a currently logged-in device) OR a `registration_ticket` (for this specific device pairing flow).