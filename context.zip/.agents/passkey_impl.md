


Go with **Model 1 (Passkeys + 24-Word Recovery Key)**.

Beyond being cleaner to build, there is a massive architectural twist here: **because of how you already designed your Rust server, you actually get both models on the backend for free.**

---

### 1. The Architectural Plot Twist: Your Server Doesn't Care

Look at what your server actually receives in `register.rs`, `login.rs`, and `hashcash.rs`:

1. `identity_hash`: 64 hex characters (32 bytes) in the `X-Hashcash` header.


2. `auth_verifier`: An opaque Argon2id string in the JSON body.


3. `wrapped_vault_key`: 60 encrypted bytes containing `K_vault`.

Because your server is zero-knowledge, **it has no idea how the client generated those three values:**

* **In Model 1 (Your Official Android App):** The client derives `identity_hash`, `auth_verifier`, and `K_recovery` all from the **24-word phrase**. The user never invents a username or password.
* **In Model 2 (A 3rd-Party Custom Client):** If another developer builds a custom desktop client and prefers classic logins, their client can compute `identity_hash = SHA256(username)`, `auth_verifier = Argon2id(password)`, and use the 24 words strictly for `wrapped_vault_key`.

**Your Rust server code and SQLite tables remain 100% identical in both cases.** By building the server around `identity_hash`, `auth_verifier`, `wrapped_vault_key`, and `webauthn_credentials`, your backend supports both models out of the box.

---

### 2. Why Your Android Client Should Strictly Use Model 1

For your official Android apps (File Manager and Gallery), Model 1 is the clear winner for three reasons:

#### A. It Eliminates the "Two-Secret" UX Trap

In Model 2, imagine Alice loses her phone, buys a new one, and types in her Username and Password. The server logs her in. Then, the app immediately stops her and says: *"Now type your 24-word recovery phrase to decrypt your files."*
Users hate this. They think, *"I just logged in with my password, why can't I see my photos?!"* Worse, users will constantly confuse their password with their recovery key, or pick a weak password thinking it protects their files. Model 1 deletes this confusion: **Passkey for daily login, 24 words for disaster recovery.**

#### B. Username-less Passkey Login (How Google & GitHub Do It)

Your observation about Google and GitHub is spot on. They use a WebAuthn feature called **Discoverable Credentials (Resident Keys)**.

* When Alice registers a Passkey on Android, your server tells the phone's credential manager to store her internal `user_id` *inside* the Passkey itself.
* When Alice gets a new device and taps **"Sign in with Passkey"**, she doesn't type a username or email.
* Her phone pops up the biometric prompt: *"Sign in to Kosh as Alice?"*
* She touches the fingerprint sensor, and the Passkey sends both her `user_id` and the cryptographic signature to your Axum server in one shot.

#### C. Zero Wasted Code in Your Repo

If you go with Model 1, every single line of code you already wrote in `register.rs`, `login.rs`, `pow_guard.rs`, and `hashcash.rs` stays exactly where it is.

* When Alice creates an account (or recovers it from paper), the app uses your existing Hashcash + `/api/auth/register` and `/api/auth/login` routes using the keys derived from her 24 words.


* Even better, your CLI tool (`crates/cli`) or headless scripts—which don't have Android Passkey popups—can always authenticate directly through `/api/auth/login` using the 24-word derivation.



---

### The Final Blueprint for Your Auth Module

Lock in **Model 1** for the Kosh Android client. To finish the server's authentication engine, you only need to add three small pieces to your existing codebase:

1. **Add `wrapped_vault_key BLOB NOT NULL` to your `users` table:**
* Returned on `POST /api/auth/login` so a recovering device gets its locked `K_vault`.


* Updated via `PUT /api/v1/auth/recovery` when a user rotates their 24-word phrase.


2. **Add Discoverable Passkeys (`webauthn-rs`):**
* `POST /api/auth/passkey/register/{start,finish}` (Authenticated—adds a passkey to an existing account).
* `POST /api/auth/passkey/login/{start,finish}` (Unauthenticated, guarded by `pow_guard`—issues a Session `token`).




3. **Add the ECDH Blind Mailbox (In-Memory Moka Cache):**
* `POST /api/v1/devices/mailbox` & `GET /api/v1/devices/mailbox/{id}` so an existing device can beam `K_vault` to a newly passkey-authenticated device via QR code.





Would you like the context specification for the `webauthn-rs` and ECDH mailbox endpoints so you can hand it to your agent next?




**Do not build a registration fork—it will double your Android client workload and create unnecessary friction for users on the very first screen.**

Here is why giving users a "permanent choice" at signup is a trap, and how you can structure this to ship your Android client much faster:

* **The Solo-Dev Multiplier:** You are already maintaining two separate Android apps (File Manager and Gallery). If you offer two different login architectures at signup, you have to build, test, and maintain twice as many Jetpack Compose screens, ViewModels, validation states, and error handlers before a user even uploads a single file.
* **The "Permanent Warning" UX Trap:** Throwing a warning at a new user that says *"Choose wisely, you can never change this login method for the lifetime of your account"* creates immediate anxiety. Good security architecture is opinionated—you make the best decision so the user doesn't have to think about cryptography.
* **It Isn't Actually Permanent Anyway:** Because your server maps sessions and files to the internal `user_id` rather than `identity_hash`, a user's login method is **never** mathematically locked for life. Only `K_vault` is permanent. How a user proves their identity to the server (`identity_hash` + `auth_verifier` or Passkeys) is just a lock on the outside of the door—you can swap or upgrade that lock at any time with a single SQL `UPDATE` without touching a single encrypted file.



---

### The Pragmatic Path to Ship Your MVP

Look at your codebase right now: you **already** have `/api/auth/challenge`, `/api/auth/register`, and `/api/auth/login` written, tested, and protected by `pow_guard` and `hashcash`.

Instead of stalling your momentum by building WebAuthn and dual-mode onboarding before your client even exists, sequence your build in two steps:

1. **Phase 1 (Get the Client Syncing Now):** Build a single, opinionated onboarding flow on Android using the routes you already wrote. Whether you derive `identity_hash` and `auth_verifier` from a 24-word recovery phrase (Model 1) or from a classic Username + Password (Model 2), remember that **the user only types it once per device**. The moment `/api/auth/login` returns the Bearer `token`, the Android app saves `token` and `K_vault` into the hardware Keystore behind fingerprint/face unlock. Day-to-day UX is instant biometric unlock either way.


2. **Phase 2 (Passkeys as a Settings Upgrade):** Once your File Manager and Gallery are actually syncing files and pruning ledgers, add WebAuthn Passkeys and QR-code device pairing as a secondary "Link Device / Add Passkey" feature inside the Settings menu.

Between deriving login credentials strictly from the **24-word phrase** versus **Username + Password + 24-word phrase**, which single path feels cleanest for you to code into the Android client right now?







# anything we can do about the recovery key derivation?? like user always gets same recovery key... if it gets leaked or anything... idk the same key throughout account's lifetime kinda seems unsafe... if there's anything we can do like other services, when we genrate spearate backup codes everytime

You have just stumbled upon one of the most fundamental UX vs. Security friction points in E2EE system design.

When you use "other services" (like Google or GitHub) and they give you 10 backup codes, generating new ones instantly invalidates the old ones. But those services hold your data in plaintext. In Kosh, if the 24 words *are* the actual key that encrypts 50 GB of data, changing the words means you have to re-encrypt 50 GB of data.

However, **you can absolutely achieve the "regenerate backup codes" feature in Kosh without re-encrypting your files.** To do it, we just need to add one layer of abstraction: **Envelope Encryption at the Root.**

Here is how we adjust the architecture so users can safely rotate their recovery key in milliseconds.

### The Architectural Pivot: The Vault Key Envelope

Instead of the 24-word phrase *being* the master key, the client generates a hidden, truly random key that the user never sees. The 24 words just act as a padlock on a box containing that hidden key.

**1. The True Master ($K_{\text{vault}}$):**
When the user creates an account, the Android client generates a perfectly random 32-byte key using `SecureRandom`. This is $K_{\text{vault}}$.
*This* is the key that derives your file DEKs, deduplicates your blobs, and encrypts your Room databases.

**2. The Recovery Phrase ($K_{\text{recovery}}$):**
The client then generates the 24-word BIP-39 phrase. It runs the phrase through Argon2id to derive a Key Encryption Key ($K_{\text{recovery}}$).

**3. The "Locked Box" on the Server:**
The client encrypts $K_{\text{vault}}$ using $K_{\text{recovery}}$:
`Wrapped_Vault = AES-GCM(K_recovery, K_vault)`
The client uploads this tiny 44-byte `Wrapped_Vault` payload to a new SQLite table on the Axum server (e.g., `user_recovery_keys`).

### How Millisecond Key Rotation Works
