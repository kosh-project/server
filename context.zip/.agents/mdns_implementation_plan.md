# Implementation Plan: Native Zero-Config mDNS Broadcast & Advanced Discovery

## Approved Plan Summary
- Branch: `feat/mdns-discovery` (branched from `main` at `9d1adf3`)
- Goal: Implement native Multicast DNS (mDNS / DNS-SD) broadcasting in Kosh server using pure Rust `mdns-sd` (v0.21.6).
- Benefits:
  - Enables local LAN WebAuthn passkey registration using `kosh.local` without relying on raw IPs or external DNS.
  - Automatic client discovery with rich TXT records (version, TLS status, cert fingerprint for TOFU, RP ID, vault ID, API prefix, and custom tags).
  - Array-like network interface filtering (`interfaces "eth0" "wlan0"`).
  - Nested `txt` child block in KDL (`txt { property "key" "value" }`).
  - Full `miette::Diagnostic` error reporting for mDNS configuration and TXT bounds validation.
  - Safe MTU guard: total TXT records bounded to <= 400 bytes to prevent Wi-Fi UDP packet fragmentation.

## Phase Breakdown

### Phase 1: Configuration & Diagnostics (`kosh-core`)
1. In `crates/core/src/config/error.rs`:
   - Add rich `miette::Diagnostic` error variants:
     - `InvalidMdnsProperty { key: String, reason: &'static str }`
     - `MdnsTxtTooLarge { size: usize }`
2. In `crates/core/src/config/mdns.rs`:
   - `Property` struct with `#[knuffel(argument)] key` and `#[knuffel(argument)] value`.
   - `Txt` struct with `#[knuffel(children(name = "property"))] pub properties: Vec<Property>`.
   - `Mdns` struct with:
     - `#[knuffel(child, unwrap(argument), default = true)] pub enable: bool`
     - `#[knuffel(child, unwrap(argument), default = "kosh".into())] pub hostname: String`
     - `#[knuffel(child, unwrap(arguments), default)] pub interfaces: Vec<String>` (array syntax)
     - `#[knuffel(child, default)] pub txt: Txt` (nested txt block)
   - `Mdns::validate(&self) -> Result<()>` returning typed `miette::Diagnostic` errors.
3. In `crates/core/src/config/mod.rs`:
   - Call `config.mdns.validate()?;` in `Config::load_or_init()`.
   - Update `default_kdl` template with annotated `mdns` node.
4. In `crates/core/src/config/test.rs`:
   - Tests for `interfaces "eth0" "wlan0"` and `txt { property ... }` KDL syntax.
   - Tests for `miette` diagnostic errors on oversized keys, values, and total payload.

### Phase 2: TLS Subject Alternative Name (SAN) Integration (`kosh-core`)
1. In `crates/core/src/tls/cert.rs`:
   - Update `Identity::forge(extra_sans: &[String])` and `Identity::load_or_create(...)` to accept additional SANs.
   - Inject `<hostname>.local` and detected LAN IPs into certificate SAN list.

### Phase 3: mDNS Broadcaster Service (`webdav-server`)
1. In `crates/server/Cargo.toml`:
   - Add `mdns-sd = "0.21.6"`.
   - Add `local-ip-address = "0.6.13"`.
2. In `crates/server/src/mdns.rs`:
   - `Broadcaster` struct owning `ServiceDaemon` and `fullname`.
   - `Broadcaster::start(config: &Config, cert_fingerprint: Option<&str>, server_secret: Option<&Secret>) -> Result<Self, boot::Error>`.
   - Compile system TXT records (`version`, `tls`, `api_prefix`, `rp_id`, `fingerprint`, `vault_id`) + custom user properties from `config.mdns.txt.properties`.
   - Filter IPs using `local_ip_address::list_afinet_netifas()` against `config.mdns.interfaces`.
   - Register service with `_https._tcp.local.` (or `_http._tcp.local.` if plain HTTP).
   - `Broadcaster::shutdown(self)` unregisters and shuts down daemon.
3. In `crates/server/src/main.rs`:
   - In `boot()`, if `config.mdns.enable`, start `Broadcaster`.
   - Keep broadcaster in scope throughout `launcher.run()`.
   - Call `broadcaster.shutdown()` on shutdown.

### Phase 4: CLI Pairing Display (`cli`)
1. In `crates/cli/src/core/pairing.rs`:
   - Render `mDNS : <hostname>.local:<port>` in `resolve_display_addresses`.

### Phase 5: Verification & Quality Checks
- `cargo check --workspace`
- `cargo clippy --workspace --all-targets -- -D warnings`
- `cargo test --workspace`
