#### 🔴 Defect 6: Token Handling & Missing Expiration Checks (`SessionManager.kt`)
- **Code Reality:** `SessionManager` does *not* truncate tokens (it uses dynamic AES-256-GCM and Base64 encoding into `SharedPreferences`).
- **Server Reality:** Server issues a **118-byte structured token**:
  `session_id(36).expires_at_hex(16).blake3_mac(64)`
- **Architectural Gaps:**
  1. `SessionManager` lacks `clearToken()` or any session revocation logic. When the server returns `401 Unauthorized` (due to 30-day token expiration or server reboot with rotated secret), the client has no way to wipe the stale token, causing endless 401 loops on subsequent authenticated calls.
  2. Lacks proactive local expiration checks. The client could parse `expires_at_hex` (offsets 37..53) to preemptively route to login without making a doomed network request.

#### 🔴 Defect 7: Hardcoded Insecure LAN URLs & Missing TLS Pinning
- **Current Client Code:** `baseUrl = "http://192.168.240.1:6969/api"`.
- **Server Reality:** Server terminates TLS directly with self-signed X.509 certs generated via `rcgen` and displays a pairing QR code + 12 BIP-39 SAS words in the Ratatui CLI.
- **Clarification:** The 12 BIP-39 words from the server CLI are strictly **Short Authentication String (SAS) words** derived from the first 16 bytes of the **server's TLS certificate SHA-256 fingerprint** for out-of-band TOFU verification. They are *not* user password salts or account recovery phrases.
- **Required Fix:** Implement a connection data store, pairing flow, and custom `KoshPinnedTrustManager` for certificate pinning.

#### 🔴 Defect 8: Interceptor Misconfiguration & Double Injection (`NetworkModule.kt`)
- **Current Client Code:** Lines 39 and 53 in `NetworkModule.kt`:
  - `provideOkHttpClient` (`@PublicOkHttpClient`) adds `authInterceptor` to the public client!
  - `provideAuthOkHttpClient` (`@AuthOkHttpClient`) takes `publicClient` (which already has `authInterceptor`) and adds `authInterceptor` a second time via `.newBuilder().addInterceptor(authInterceptor)`.
- **Consequence:** Public unauthenticated routes (like `/api/auth/register` and `/api/auth/login`) may inadvertently transmit stale or invalid `Authorization` headers, while authenticated routes execute the interceptor logic twice.
- **Required Fix:** Remove `authInterceptor` from `provideOkHttpClient`. Only attach `authInterceptor` in `provideAuthOkHttpClient`.

#### 🔴 Defect 9: Fatal OOM via `HttpLoggingInterceptor.Level.BODY` (`NetworkModule.kt`)
- **Current Client Code:** Line 34 in `NetworkModule.kt`:
  ```kotlin
  val loggingInterceptor = HttpLoggingInterceptor().apply {
      level = HttpLoggingInterceptor.Level.BODY
  }
  ```
- **Consequence:** OkHttp's `HttpLoggingInterceptor.Level.BODY` buffers the *entire* request and response body into Java heap memory to log it as a string. For multi-megabyte or gigabyte CAS uploads and downloads, this immediately throws `java.lang.OutOfMemoryError` on Android and completely breaks zero-copy streaming.
- **Required Fix:** Set `level = HttpLoggingInterceptor.Level.HEADERS` or `BASIC` in development, or disable body logging for binary octet-streams.

#### 🔴 Defect 10: Missing Exact Content-Length & Size Discrepancy (`StreamingUriRequestBody.kt`)
- **Current Client Code:** `contentLength()` returns `-1L` if the `ContentResolver` cursor fails to query `OpenableColumns.SIZE`. Additionally, it queries the *plaintext* file size.
- **Server Reality:** The server's upload endpoint strictly requires the `Content-Length` header (`BadRequest("Missing content length in header")`). If `contentLength()` returns `-1L`, OkHttp switches to chunked transfer encoding (`Transfer-Encoding: chunked`) and omits `Content-Length`, which is instantly rejected with HTTP 400 by the server. Furthermore, when encrypting with Tink `StreamingAead`, the ciphertext size is strictly larger than plaintext due to header bytes and segment MAC tags.
- **Required Fix:** Pass the exact ciphertext length to `StreamingUriRequestBody` and forbid chunked streaming fallbacks.

#### 🔴 Defect 11: Fatal UI-Thread ANR via Argon2id (`AuthViewModel.kt`)
- **Current Client Code:** In `AuthViewModel.login()`, `viewModelScope.launch` defaults to `Dispatchers.Main.immediate`. It directly invokes `identityManager.deriveCredentials(username, passphrase)`.
- **Systems Consequence:** Running Argon2id (`64MB RAM`, `3 iterations`) consumes 300ms–800ms of intensive CPU and memory allocation directly on Android's Main (Looper) thread. This freezes UI touch events, drops frames, and triggers Android ANR (Application Not Responding) dialogs.
- **Required Fix:** Offload `deriveCredentials` strictly onto `Dispatchers.Default`.

#### 🔴 Defect 12: OkHttp Default 10s Write Timeout Breaking Large Uploads (`NetworkModule.kt`)
- **Current Client Code:** `NetworkModule.kt` configures `connectTimeout(10s)` and `readTimeout(30s)`, leaving `writeTimeout` at the OkHttp default of **10 seconds**.
- **Systems Consequence:** Streaming large CAS media files (photos/videos up to 10GB per server rules) over Wi-Fi will terminate with `java.net.SocketTimeoutException: timeout` whenever an upload block takes longer than 10 seconds to flush to the socket.
- **Required Fix:** Explicitly set `.writeTimeout(10, TimeUnit.MINUTES)` (or `0` to disable socket write timeouts) on the CAS streaming OkHttpClient.

#### 🔴 Defect 13: Synchronous Blocking Network APIs in Network Layer (`AuthClient.kt` & `AssetClient.kt`)
- **Current Client Code:** All calls use `.execute()` synchronously, forcing callers to manually wrap in `withContext(Dispatchers.IO)`. None of the network methods are Kotlin `suspend` functions.
- **Consequence:** Leaks threading responsibility to the caller, risks accidental `NetworkOnMainThreadException`, and prevents coroutine cancellation from properly tearing down OkHttp network calls.
- **Required Fix:** Refactor client methods to `suspend fun` using OkHttp's asynchronous `enqueue` or properly structured coroutine call wrappers.

#### 🔴 Defect 14: Hardcoded `.jpg` in CAS Blob Download (`AssetClient.kt`)
- **Current Client Code:** Line 63 hardcodes:
  ```kotlin
  val downloadFile = File(cacheDir, "restored_$hash.jpg")
  ```
- **Consequence:** The CAS vault stores arbitrary binary blobs across 4 categories (e.g., `GalleryMeta` JSON snapshot databases, `DriveItem` PDFs/docs, videos). Hardcoding `.jpg` corrupts file extensions for all non-image files.
- **Required Fix:** Store downloads using the raw hash or an envelope metadata lookup.

#### 🔴 Defect 15: `AssetTag` Serialization Incompatibility (`AssetTag.kt`)
- **Current Client Code:** Plain unannotated enum `enum class AssetTag(val id: Byte)`.
- **Server Reality:** Server defines `#[repr(i32)]` with `Serialize_repr` / `Deserialize_repr`, emitting integers `0..3`.
- **Consequence:** Kotlinx Serialization on default enums expects string names (`"GALLERY_ITEM"`). Deserializing server JSON fails with `SerializationException`.
- **Required Fix:** Implement a custom integer `KSerializer<AssetTag>`:
  ```kotlin
  @Serializable(with = AssetTagSerializer::class)
  enum class AssetTag(val id: Int) { ... }
  ```

#### 🔴 Defect 16: Zero-Knowledge Privacy Violation in Gallery Upload (`GalleryViewModel.kt`)
- **Current Client Code:** Queries `OpenableColumns.DISPLAY_NAME` and sends plaintext file names across the wire in `X-File-Name`, while streaming unencrypted plaintext bytes.
- **Server Consequence:** If `DISPLAY_NAME` contains `/` or `\`, the server rejects it with `400 Bad Request` (`InvalidFileName`). Furthermore, sending plaintext names and unencrypted bytes violates the "Dumb Bucket" zero-knowledge contract. Uploads must use synthetic UUIDs (`uuid.enc`) and Tink ciphertext.

---

## 3. Implemented Modules Overview

### 3.1 `core:crypto` (`IdentityManager.kt`)
Computes `identity_hash` via SHA-256 of username and `auth_verifier` via `Argon2Kt` (`mCost=65536`, `tCost=3`, `parallelism=1`).
*Note: Uses a temporary fixed salt `"kosh_salty"`. The long-term architecture will derive the salt deterministically from the user's public identity (e.g. `SHA-256("kosh:salt:" + username)`).*

### 3.2 `core:auth` (`SessionManager.kt` & `AuthRepository.kt`)
- `SessionManager`: Uses AndroidKeyStore with an AES-256-GCM master key to encrypt the session token into `SharedPreferences`.
- `AuthRepository`: Coordinates coroutine execution on `Dispatchers.IO` for authentication.

### 3.3 `core:network` (`NetworkModule.kt`, `AuthInterceptor.kt`)
- Provides `@PublicOkHttpClient` (unauthenticated, for `/api/auth/*`) and `@AuthOkHttpClient` (attaches Bearer token via `AuthInterceptor`).
- `StreamingUriRequestBody`: Streams `android.net.Uri` content from `ContentResolver` to avoid buffering large files in RAM.

### 3.4 `feature:auth` & `feature:gallery`
- `AuthScreen` / `AuthViewModel`: Basic login and registration Compose UI state machines.
- `GalleryScreen` / `GalleryViewModel`: Compose gallery shell for listing and viewing assets.

---

## 4. Priority Roadmap for the Next Session

1. **Step 1 — Auth Overhaul:**
   - Create `HashcashSolver.kt` in `core:crypto` (16 leading zero bits, `Dispatchers.Default`).
   - Create wire DTOs in `core:model`: `AuthRequest`, `ChallengeResponse`, `UploadResponse`, and `AssetTagSerializer`.
   - Update `AuthClient.kt` to fetch challenge, solve PoW, and attach `X-Hashcash`.
   - Offload Argon2 derivation in `AuthViewModel.kt` to `Dispatchers.Default` to eliminate UI thread ANRs.
   - Add `clearToken()` to `SessionManager.kt`.
2. **Step 2 — Network & CAS Pipeline Hardening:**
   - Remove `authInterceptor` duplicate from `@PublicOkHttpClient`.
   - Fix logging level to `Level.HEADERS` and set `writeTimeout(10, TimeUnit.MINUTES)`.
   - Fix `/asset/` $\to$ `/assets/` plural path in `AssetClient.kt` and eliminate stream double-reading.
   - Parse `UploadResponse` JSON to detect server-side storage errors on `200 OK`.
   - Implement `GET /api/v1/assets?tag={0..3}` in `AssetClient.kt`.
3. **Step 3 — TLS & TOFU Pairing:**
   - Implement `KoshPinnedTrustManager` to validate the server leaf certificate's SHA-256 fingerprint from the Ratatui CLI QR code.