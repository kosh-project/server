# Kosh Server — Architectural Milestones & Latest Changes Digest
# Snapshot Date: October 2026 (Branch: `feat/asset-pagination` & `main` checkpoint)
# Primary Audience: AI Agents & Systems Contributors

Welcome aboard. If you're an AI agent dropping into a session mid-flight or a contributor looking to understand how the Kosh backend evolved from a prototype into a hardened, zero-allocation, low-resource storage engine, this document is your ground truth.

Cross-reference with:
- [`.agents/AGENTS.md`](file:///home/ton3s/rsProjects/webdav-server/.agents/AGENTS.md) — Fundamental rules of engagement (Agents write to `.agents/*.md` only; zero logic rewrites without explicit user instruction).
- [`.agents/contributor_guide.md`](file:///home/ton3s/rsProjects/webdav-server/.agents/contributor_guide.md) — Comprehensive architectural and contribution handbook.
- [`.agents/current_state.md`](file:///home/ton3s/rsProjects/webdav-server/.agents/current_state.md) — Current runtime contracts and route inventory.
- [`.agents/progress.md`](file:///home/ton3s/rsProjects/webdav-server/.agents/progress.md) — Chronological dev logs.

---

## 1. Keyset Cursor Pagination (`feat/asset-pagination`)

### The Problem: Mechanical Disk I/O & Unbounded $O(N)$ Scans
Our reference hardware target is an old **2nd-gen Intel Core i5 (Sandy Bridge)** box running on a **spinning mechanical HDD**. 
In earlier iterations, `GET /api/v1/assets` loaded records without strict bounds or relied on traditional SQL `LIMIT ... OFFSET ...` patterns. 

On SQLite running over mechanical disk platters, traditional `OFFSET 10000` is catastrophic. The database engine must physically traverse and read 10,000 index leaves or table rows from spinning media just to discard them, causing head thrashing and spiking latency into hundreds of milliseconds.

### The Solution: True Keyset Cursor Seeking
The asset pagination milestone overhauled the storage query model completely:

1. **Composite B-Tree Index (`idx_assets_user_tag_cursor`):**
   Defined in migration [`20261004220000_add_assets_cursor_index.sql`](file:///home/ton3s/rsProjects/webdav-server/crates/server/migrations/20261004220000_add_assets_cursor_index.sql):
   ```sql
   CREATE INDEX IF NOT EXISTS idx_assets_user_tag_cursor
   ON assets(user_id, tag, last_modified DESC, id DESC);
   ```
   Notice the column ordering:
   - `user_id` (equality)
   - `tag` (equality)
   - `last_modified DESC` (seek predicate)
   - `id DESC` (tie-breaker seek predicate)

2. **Keyset Seek Query:**
   Instead of `OFFSET`, the query seeks in $O(\log N)$ time directly to the edge of the previous page:
   ```sql
   SELECT
       id as "id!",
       hash,
       size_bytes,
       last_modified,
       tag as "tag: Tag"
   FROM assets
   WHERE user_id = ?1
       AND tag = ?2
       AND (
           ?3 IS NULL
           OR last_modified < ?3
           OR (last_modified = ?3 AND id < ?4)
       )
   ORDER BY last_modified DESC, id DESC
   LIMIT ?5
   ```
   Because assets can share identical timestamps (e.g., bulk client imports), `id` (the 16-byte UUID BLOB) acts as a strictly monotonically descending tie-breaker. Zero duplicate items across page boundaries, zero skipped records.

3. **Limit + 1 Sentinel Fetch (Zero `COUNT(*)`):**
   Traditional pagination queries issue a secondary `SELECT COUNT(*)` to tell the client if a next page exists. On a million-row table, `COUNT(*)` forces a full index scan.
   Instead, the server queries for `limit + 1` rows. If `rows.len() > limit`, a next page is guaranteed to exist. The extra sentinel row is truncated, and its `last_modified` and hex-encoded `id` are packaged into the `next_cursor`. If no sentinel row exists, `next_cursor` is `None`.

4. **Strict Protocol Contract:**
   - **`tag` is strictly mandatory:** `?tag=<0..3>`. Omitting `tag` returns `400 Bad Request`.
     - `0` = `GalleryMeta`
     - `1` = `GalleryItem`
     - `2` = `DriveMeta`
     - `3` = `DriveItem`
   - **`limit` clamped to `1..=100`:** Defaults to 50 if omitted.
   - **Cursor parameters:** `before_time=<i64>` and `before_id=<hex32>`. Both must be provided together or omitted entirely. Providing only one returns `400 Bad Request`.
   - **Response shape:**
     ```json
     {
       "assets": [
         {
           "hash": "a6c8e3f...",
           "size_bytes": 2048576,
           "last_modified": 1727600000,
           "tag": 1
         }
       ],
       "next_cursor": {
         "before_time": 1727600000,
         "before_id": "018f3a8b2c4d..."
       }
     }
     ```

5. **Model Modularization:**
   `crates/server/src/model/asset/` was refactored from a monolithic file into clean modules:
   - [`mod.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/model/asset/mod.rs) — Core `Asset` struct and async database queries (`exists`, `create`, `delete`, `owned_by`, `list`).
   - [`tag.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/model/asset/tag.rs) — `Tag` enum with `#[repr(i32)]`, `sqlx::Type`, and `serde_repr`.
   - [`page.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/model/asset/page.rs) — `AssetCursor`, `MetadataRow`, and `Page` DTOs.
   - [`test.rs`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/model/asset/test.rs) — Unit tests asserting pagination, ordering, and tie-breaking.

---

## 2. Multi-Layer Ingress Funnel & Rate Limiting (`feat/rate_limiter`)

To protect low-resource hardware from CPU starvation (Argon2id hashing) and disk thrashing (cache-miss lookups against SQLite WAL), the HTTP ingress was structured into a four-stage defense pipeline:

```text
[ Incoming TCP Connection ]
             │
             ▼
┌────────────────────────────────────────────────────────┐
│ Stage 1: Global IP Shield (tower_governor)             │
│ • Key: Peer Client IP                                  │
│ • Quota: 25 requests/sec (burst allowance: 10)         │
│ • Drops volumetric floods in ~50ns in RAM              │
└────────────────────────────┬───────────────────────────┘
                             │
                             ├─────────────────────────────────────────┐
                             │                                         │
               (Auth Routes: /api/auth/*)                (Protected Routes: /api/v1/*)
                             │                                         │
                             ▼                                         ▼
┌────────────────────────────────────────┐ ┌────────────────────────────────────────┐
│ Auth IP Governor (tower_governor)      │ │ Stage 2: Stateless BLAKE3 MAC Filter   │
│ • Key: Client IP                       │ │ • Checks Bearer token format & HMAC    │
│ • Quota: 2 requests/sec (burst: 2)     │ │ • Validates expires_at in RAM (<1µs)   │
│ • Prevents Argon2id CPU exhaustion     │ │ • Rejects forged tokens instantly      │
└────────────────────────────┬───────────┘ │ • Zero DB queries, zero cache hits     │
                             │             └───────────────────┬────────────────────┘
                             ▼                                 │
┌────────────────────────────────────────┐                     ▼
│ Stateless Hashcash PoW Guard           │ ┌────────────────────────────────────────┐
│ • Validates X-Hashcash header          │ │ Stage 3: Authenticated Device Governor │
│ • Checks 16-bit zero difficulty & TTL  │ │ • Key: TokenHash (BLAKE3 of Bearer)    │
│ • Validates BLAKE3 challenge MAC (<2µs)│ │ • Quota: 15 req/sec (burst: 5)         │
└────────────────────────────┬───────────┘ │ • Prevents client sync loop thrashing  │
                             │             └───────────────────┬────────────────────┘
                             ▼                                 │
┌────────────────────────────────────────┐                     ▼
│ Auth Route Handlers                    │ ┌────────────────────────────────────────┐
│ • POST /api/auth/register              │ │ Stage 4: Session Resolution            │
│ • POST /api/auth/login                 │ │ • Fast Path: Moka Cache (10-min TTI)   │
└────────────────────────────────────────┘ │ • Slow Path: SQLite query (10-30µs)    │
                                           │ • Injects resolved user_id             │
                                           └───────────────────┬────────────────────┘
                                                               │
                                                               ▼
                                           ┌────────────────────────────────────────┐
                                           │ Protected Handlers (/api/v1/*)         │
                                           │ (CAS Blob Vault, WAL Ledger, Assets)   │
                                           └────────────────────────────────────────┘
```

### Architectural Key Takeaway:
Notice that `mac_guard` runs **before** `with_device_limit`. Why? Because `tower_governor` requires a `TokenHash` key to track device quotas. By running the stateless BLAKE3 MAC validation first, we guarantee that only valid, server-issued tokens can ever allocate a state slot in the rate limiter's memory table. An attacker cannot exhaust governor RAM by spraying random bearer tokens.

---

## 3. Challenge Auth & Stateless Hashcash Proof-of-Work

To defeat credential stuffing and brute-force attacks against `/api/auth/register` and `/api/auth/login` without introducing stateful Redis databases, CAPTCHAs, or third-party dependencies, Kosh implemented a stateless Hashcash Proof-of-Work engine:

### Mechanics:
1. **Challenge Issuance (`GET /api/auth/challenge?action=<login|register>`):**
   - The server inspects the client's socket IP and the requested action.
   - Computes a keyed BLAKE3 MAC using `K_ephemeral` (a 32-byte secret generated randomly in RAM on server startup).
   - Generates an opaque challenge string with fixed layout:
     ```text
     [ timestamp_hex (16 chars) ][ mac_hex (64 chars) ][ action (5 or 8 chars) ]
     ```
   - Total length: 85 bytes for `"login"`, 88 bytes for `"register"`.
   - Expires in 15 seconds.

2. **Client Solving:**
   - The client derives its `identity_hash` via Argon2id.
   - It iterates a 64-bit nonce until:
     $$\text{SHA-256}(\text{identity\_hash} \parallel \text{nonce} \parallel \text{challenge})$$
     has at least 16 leading zero bits (`hash[0] == 0 && hash[1] == 0`).
   - On a mobile device, this takes approximately 100–300ms of CPU time — unnoticeable to a human, but economically devastating to a botnet.

3. **Stateless Verification (`pow_guard` & `HashCash::verify_stateless`):**
   - The client sends the combined string in the `X-Hashcash` header:
     ```text
     [ identity_hash (64) ][ nonce (16) ][ timestamp_hex (16) ][ mac_hex (64) ][ action (5|8) ]
     ```
   - Total length: exactly 165 or 168 ASCII bytes.
   - Parsing is strictly $O(1)$ byte-slice indexing without regex or string splitting.
   - Verification order:
     1. Exact length check.
     2. SHA-256 PoW difficulty check (rejects invalid work immediately).
     3. Action matching.
     4. Timestamp freshness (within 15s window, rejects expired challenges).
     5. BLAKE3 MAC re-computation using `K_ephemeral` and client IP.
   - If valid, the verified `HashCash` struct containing the validated `identity_hash` is injected into Axum request extensions.

4. **Cryptographic Separation: $K_{\text{server}}$ vs. $K_{\text{ephemeral}}$:**
   - **`K_server` (`vault/server.secret`):** Loaded from disk. Survives server reboots so active 30-day client session tokens remain valid across power cycles.
   - **`K_ephemeral` (RAM only):** Created fresh via `rand::random()` on boot. Never touches disk. When the server restarts, all pending 15-second auth challenges are instantly invalidated.

---

## 4. Zero Heap Allocation Errors (`perf/static-error-adapt`)

In high-throughput Rust network services, error handling can inadvertently become a major source of memory fragmentation and allocator lock contention if error paths frequently invoke `format!("...", dynamic_args)`.

In the `perf/static-error-adapt` milestone:
1. **Eradication of `format!()` in Errors:**
   All dynamic string allocations were excised from error types in favor of compile-time `&'static str` literals.
2. **Static Domain Enums:**
   `api::Error`, `model::Error`, and `storage::Error` now hold `&'static str` descriptors:
   ```rust
   pub enum Error {
       BadRequest(&'static str),
       Unauthorized(&'static str),
       NotFound(&'static str),
       Internal(#[from] internal::Error),
       // ...
   }
   ```
3. **Macro-Hygiene Bridge (`wrap_internal_err!`):**
   Standard library conversion errors (like `TryFromIntError` and `SystemTimeError`) are wrapped via the [`wrap_internal_err!`](file:///home/ton3s/rsProjects/webdav-server/crates/server/src/error/internal.rs) macro into `internal::Error`, allowing `?` operator chaining without allocating memory.
4. **Zero-Cost Sanitization in `IntoResponse`:**
   When an error occurs:
   - If the background telemetry logger is running, a telemetry `Entry` is formatted once into response extensions.
   - If logging is disabled or for internal errors, the client receives static, sanitized HTTP status codes (`500 Internal Server Error`, `400 Bad Request`) with zero heap churn.

---

## 5. WAL Ledger Engine & CAS Storage Vault

### Content-Addressable Storage (CAS) Vault
- Files are stored under `vault/<blake3_hex_hash>`, making path traversal attacks structurally impossible.
- **Upload Transaction:**
  1. Stream incoming bytes to a temporary staging file: `vault/<uuid>.tmp`.
  2. Best-effort pre-allocation via `posix_fallocate` using the client's mandatory `Content-Length`.
  3. Incrementally hash chunks with BLAKE3 as they arrive over the wire.
  4. Verify exact byte count matches `Content-Length` at EOF.
  5. Atomically commit to the vault via `tokio::fs::rename`.
  6. Any network cancellation or I/O failure immediately unlinks the `.tmp` staging file.

### Append-Only Write-Ahead Log (WAL) Ledger (`crates/server/src/storage/ledger/`)
Designed for offline-first delta synchronization with mobile clients:
- **Single-Writer Actor Pattern:** All writes (appends and prunes) are routed through a bounded `mpsc(100)` channel to a single background `Committer` task. This enforces single-writer disk access without requiring a `Mutex`.
- **Stateless Zero-Copy Reads:** Read operations (`Handle::read_segment`) do not touch the actor channel. They open segment files directly with independent file descriptors and seek past the header. Thousands of concurrent clients can stream sync logs simultaneously without queuing behind the committer.
- **500-Byte KOSH Segment Header:** Every segment begins with magic bytes `b"KOSH"`, version `u16`, and previous segment ID `u32`. The remaining bytes are reserved. Offsets below 500 are automatically clamped on reads.
- **5MB Rotation Physics:** Segments rotate automatically at ~5MB (`delta_0000001`, `delta_0000002`). The active segment pointer is recorded in `CURRENT` using an atomic `.tmp` rename.
- **Self-Healing Ghost File Cleanup:** If the server crashes mid-rotation, `Segment::create` proactively unlinks partial files before opening with `create_new(true)`.

---

## 6. Workspace Crate Decoupling

The codebase is split into three clean workspace members:

| Crate | Path | Responsibility |
|---|---|---|
| `kosh-core` | `crates/core` | Shared zero-dependency types: KDL `Config`, telemetry primitives (`Entry`, `Telemetry`, `Level`, `Module`), and `tls::Identity`. |
| `webdav-server` | `crates/server` | Axum HTTP/HTTPS service, SQLite models, CAS storage, and WAL ledger. |
| `cli` | `crates/cli` | Ratatui admin TUI log viewer connecting over Unix Domain Socket (`/tmp/kosh.sock`). Features pre-computed BIP-39 mnemonic word formatting and QR rendering. |

---

## 7. Contributor Quick Reference: Invariants to Maintain

When writing new features or fixing bugs in the server, always uphold these rules:
1. **Zero `unwrap()` / `expect()`:** Workspace Clippy lints will reject any unwrap or panic in committed code. Use `?` and typed domain errors.
2. **Zero `format!()` in Error Paths:** Use `&'static str` for error reasons.
3. **Mandatory `Content-Length`:** Never permit unbounded or chunked streaming without a declared size.
4. **Stateless First:** Verify tokens and proof-of-work in RAM before issuing queries to SQLite.
5. **Always Run Checks:**
   ```bash
   cargo test --workspace
   cargo clippy --lib -p webdav-server
   RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps
   ```
