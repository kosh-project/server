* [x] **Milestone 4: Ratatui TUI Pairing Modal (`crates/cli`)** (we have it, so chill)
* Construct centered popup layout with half-block Unicode QR code, server endpoint stats (including `10.0.2.2` AVD helper), 6 BIP-39 SAS words, and full SHA-256 fingerprint.

---

## PART 4: FINAL AGREED PRODUCTION ARCHITECTURE (Locked — Do Not Regress)

> This section supersedes any prior agent confusion. It is the canonical, fully-reasoned design.
> Last updated: 2026-09-23.

### Why the HMAC Pre-Filter Is Non-Negotiable on Authenticated Routes

A distributed token spray (botnet, 1000 IPs × 20 req/sec = 20,000 req/sec) with syntactically valid but forged UUID bearer tokens will:
1. Pass the IP rate limiter (each IP is under the per-IP quota).
2. Miss the Moka in-memory cache (tokens are random, never issued by the server).
3. Force a SQLite B-Tree indexed lookup for every single miss.

On a Sandy Bridge machine with a mechanical HDD, this causes disk-head thrashing. The HMAC pre-filter terminates forged tokens in RAM in under 1µs, before the database is ever touched. It is not optional on this hardware class.

### Token Structure (MUST change from current UUID design)

```
Bearer hex(session_id).hex(HMAC-SHA256(K_server, session_id))
```

- `K_server` is a 32-byte random secret generated at boot via `rand::random::<[u8; 32]>()`.
- `K_server` lives only in RAM (a `OnceLock<[u8; 32]>` in `crates/server`). It is NEVER written to disk.
- `K_server` is ONLY used for: (a) signing challenges for the PoW system, and (b) signing issued session tokens for the HMAC pre-filter.
- Consequence: Server restart invalidates all previously issued tokens (users must re-login). This is an accepted tradeoff for the zero-knowledge, zero-persistence design.

### Final Pipeline per Route Class

**Unauthenticated — Password Auth (`POST /auth/login`, `POST /auth/register`):**
```
IP Governor (tower_governor, ~2 req/sec per IP on /auth/* specifically)
→ First-Owner Lockdown Check (if user_count > 0 and !allow_open_registration → 403)
→ PoW Validator (stateless HMAC-SHA256 challenge check, <2µs)
→ Handler (Argon2id credential check)
```

**Unauthenticated — Challenge Fetch (`GET /auth/challenge`):**
```
IP Governor
→ Handler (generates stateless HMAC-signed challenge, no state written)
```

**Unauthenticated — Passkey Auth (`POST /auth/passkey/verify`) [future]:**
```
IP Governor
→ WebAuthn Handler (SQLite credential lookup → ECDSA P-256 verify, ~50µs total)
```
NOTE: Passkey does NOT get PoW. ECDSA is already cheap. PoW degrades Android Credential Manager UX for zero gain.

**Authenticated (`/api/v1/*`):**
```
IP Governor (tower_governor, ~20-30 req/sec per IP globally)
→ HMAC Pre-Filter (splits token at '.', recomputes HMAC-SHA256(K_server, session_id), drops forged tokens in <1µs)
→ Moka Cache / SQLite Lookup (near 100% cache hit rate because spray is eliminated upstream)
→ Per-Device Governor (tower_governor keyed by user_id, ~15-20 req/sec per device — prevents runaway client loops from thrashing the CAS/CRDT mpsc channels)
→ Handler (CAS blob store, CRDT ledger actor, etc.)
```

### Key Implementation Notes

1. **`K_server` scope:** Only `crates/server` knows about `K_server`. It is never exported to `kosh-core` or `crates/cli`.
2. **PoW timestamp window:** Keep at 5-10 seconds, NOT 60 seconds. Reduces replay window without noticeable client UX impact (puzzle solves in ~25ms).
3. **Challenge IP binding:** The challenge HMAC payload includes `client_ip`. A solved challenge from IP `A` cannot be replayed from IP `B`. The HMAC check itself enforces this with zero state.
4. **First-Owner Claim:** The very first `POST /auth/register` creates the root owner. After that, the endpoint returns `403 Forbidden` permanently unless an invite token flow is implemented. This check runs BEFORE the PoW validator (no point solving a puzzle for a locked door).
5. **Session token persistence:** Token hashes remain in SQLite with expiry timestamps (current design, unchanged). The Moka cache is a warm-up layer on top. The only change is the token FORMAT (add HMAC suffix) and the new pre-filter middleware.
