# KOSH Server Architecture: Self-Signed TLS & TOFU Pairing Engine

## 1. System Role & Security Invariants
You are tasked with implementing the automated, zero-configuration TLS engine for the Kosh Rust/Axum backend. 

### Core Cryptographic Invariants
1. **Zero-Plaintext Bootstrap:** Do not open an unencrypted HTTP port to serve raw certificates. All transport must terminate directly on TLS (HTTPS). In a standard TLS handshake, the server sends the X.509 certificate to the client automatically in the `Certificate` handshake message.
2. **Trust-On-First-Use (TOFU) Verification:** Android clients establish trust out-of-band by scanning an ASCII QR code printed in the server terminal during initialization. The QR code encodes the server's LAN address and the SHA-256 fingerprint of the certificate's DER payload.
3. **Defense-in-Depth:** TLS protects transport integrity and prevents local network spoofing/metadata observation. Payload confidentiality remains secured by client-side Google Tink `StreamingAead` envelope encryption.
4. **Crash-Safe Certificate Persistence:** Certificate generation must be atomic. Keypairs and certificates must be stored in `/vault/tls/` (or the configured vault path) and preserved across server restarts.

---

## 2. Dependency Manifest Updates

Add the following crates to `crates/server/Cargo.toml`:

```toml
[dependencies]
# Web Server & TLS
axum = "0.7"
axum-server = { version = "0.7", features = ["tls-rustls"] }
rustls = "0.23"

# Certificate Generation & Crypto
rcgen = "0.13"
sha2 = "0.10"
hex = "0.4"
pem = "3.0"

# LAN Discovery & Terminal QR
local-ip-address = "0.6"
qrcode = { version = "0.14", default-features = false }

## 3. Implementation Blueprint (anything noted from this point and below is just an example for you)

### Step 1: Automated X.509 Keypair & Certificate Engine

Create `crates/server/src/tls/cert.rs`:

* **Path Resolution:** Check for existing `cert.pem` and `key.pem` inside `<VAULT_DIR>/tls/`.
* **Idempotency:** If both files exist, read the certificate, parse the raw DER bytes, compute the SHA-256 hash, and return the fingerprint.
* **Generation Routine (Cold Start):**
* Generate an ECDSA (P-256) or Ed25519 keypair via `rcgen::KeyPair::generate_for(&rcgen::PKCS_ECDSA_P256_SHA256)`.
* Populate `CertificateParams`:
* `CommonName`: `"Kosh Local Server"`
* `OrganizationName`: `"Kosh Zero-Knowledge Vault"`
* Validity period: 10 years (3650 days).
* `SubjectAlternativeName` (SAN): Bind `localhost`, `127.0.0.1`, `::1`, and all detected local network IP addresses (via `local_ip_address::list_afinet_netifas()`).


* Serialize both private key and certificate into PEM format.
* Atomically write to disk via temporary files (`cert.pem.tmp` -> `cert.pem`) to avoid corrupted reads on mid-write reboot.


* **Fingerprint Derivation:**
* Decode PEM to raw DER bytes.
* Run `sha2::Sha256::digest(&der_bytes)`.
* Format output as lowercase hexadecimal string (64 characters).



### Step 2: Terminal Pairing Generator (ASCII QR Code)

Create `crates/server/src/tls/qr.rs`:

* Construct a pairing URI scheme:
```text
kosh://<LAN_IP>:<PORT>?pin=<SHA256_FINGERPRINT>&name=<HOSTNAME>

```


* Render the string to the terminal using `qrcode::QrCode` mapped to unicode blocks (`"██"`, `"  "`):
```rust
let code = QrCode::new(pairing_uri.as_bytes())?;
let string = code.render::<char>()
    .quiet_zone(true)
    .module_dimensions(2, 1)
    .build();
println!("{}", string);

```


* Log the plain URI string and hex fingerprint under `tracing::info!` for headless environments where terminal escape codes are truncated.

### Step 3: Configurable Mode Flag

Modify `crates/server/src/config/mod.rs` (or server environment parser):

* Introduce configuration options:
```rust
pub struct ServerConfig {
    pub host: IpAddr,
    pub port: u16,
    pub tls_enabled: bool,
    pub vault_path: PathBuf,
}

```


* Support environment variables:
* `KOSH_TLS_ENABLED=true|false` (default: `true`).
* `KOSH_PORT=8443` (default when TLS is enabled), `8080` (when disabled).
* `KOSH_VAULT_PATH=/vault`.



### Step 4: Axum Server Listener Abstraction

Update `crates/server/src/main.rs` (or `app/builder.rs`):

* Implement conditional binding:
```rust
if config.tls_enabled {
    let tls_identity = tls::cert::ensure_tls_certificate(&config.vault_path, &config.host)?;
    tls::qr::display_pairing_terminal(&tls_identity, config.port);

    let rustls_config = RustlsConfig::from_pem_file(&tls_identity.cert_path, &tls_identity.key_path).await?;
    let socket_addr = SocketAddr::new(config.host, config.port);

    tracing::info!("Server securely bound to https://{}", socket_addr);
    axum_server::bind_rustls(socket_addr, rustls_config)
        .serve(router.into_make_service())
        .await?;
} else {
    let socket_addr = SocketAddr::new(config.host, config.port);
    tracing::warn!("Server running in UNENCRYPTED plaintext mode on http://{}", socket_addr);
    let listener = tokio::net::TcpListener::bind(socket_addr).await?;
    axum::serve(listener, router).await?;
}

## 4. Operational Invariants for the Agent

1. **No Mixed/Dual Listeners:** Never run HTTP on port 8080 and HTTPS on port 8443 concurrently. A single port is dedicated based on `tls_enabled`.
2. **Deterministic Directory Layout:** Keep keys organized strictly under `<VAULT_DIR>/tls/`:
* `<VAULT_DIR>/tls/cert.pem` (Public certificate chain)
* `<VAULT_DIR>/tls/key.pem` (PKCS#8 private key; mode `0600`)


3. **No Dynamic Open-Relay Endpoints:** Never introduce unauthenticated endpoints that expose private key material or unverified certificate downloads.
4. **Clean Error Trapping:** If `key.pem` does not match `cert.pem`, `rustls` will panic or abort. The agent must catch this during initialization, log an explicit corruption error, and guide the user to either rotate or delete the mismatched `/vault/tls/` directory.
he 
