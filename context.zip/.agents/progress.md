# NAS-rs Progress Log (AI Managed)

## Session Summary: 2026-11-07 — Bidirectional ECDH Mailbox & Device Pairing Subsystem

This session implemented the ephemeral, in-memory ECDH key agreement and device pairing relay on branch `feat/ecdh-pairing`, complete with ticket-authorized passkey registration and an exhaustive 3-tier test suite.

### Key Achievements

#### 1. In-Memory Domain State Machine (`app::mailbox`)
- **RAM-Only Moka Cache:** Built `Mailbox` backed by `moka::future::Cache` with 300-second TTL and 1,000-entry capacity limit. Guarantees zero SQLite touches for pairing states.
- **Atomic 4-State Lifecycle:** Decoupled `Entry` state machine (`Waiting`, `Ready`, `Fulfilled`, `Consumed`) under a synchronous `std::sync::Mutex<Status>`. Prevents mutex guards from crossing `.await` boundaries and ensures all Axum handler futures implement `Send`.
- **Crockford Base32 Identifiers:** Generates 8-character identifiers from 40 bits of CSPRNG entropy, avoiding visually ambiguous characters (`i`, `l`, `o`, `u`).
- **Single-Use Burn-After-Reading:** Mailboxes transition to `Consumed` and are evicted from cache upon first retrieval by the polling token holder.
- **Strict Anti-Enumeration:** In both `Waiting` and `Ready` states, unauthorized tenant access returns HTTP 404 (`NotFound`), preventing cross-tenant existence discovery.

#### 2. Bidirectional Pairing API (`api::mailbox`)
- **Flow A (Receiver Scans / QR Code):**
  - `POST /api/auth/mailbox/open` (guarded by `pow_guard`): Unauthenticated client submits `pub_temp` (32 bytes) and receives 8-char `mailbox_id` + 32-byte secret `polling_token`.
  - `POST /api/v1/devices/link-ticket` (guarded by `mac_guard` + `auth_guard`): Authenticated device requests a 5-minute single-use `registration_ticket`.
  - `POST /api/v1/devices/mailbox/{id}/fulfill`: Authenticated device encrypts registration ticket and envelope keys into payload (`[120, 8192]` hex chars).
  - `GET /api/auth/mailbox/{id}/pickup`: Unauthenticated receiver polls with `Authorization: Bearer <polling_token>`; receives ciphertext and burns entry from memory.
- **Flow B (Sender Displays QR Code):**
  - `POST /api/v1/devices/mailbox`: Authenticated device offers pairing mailbox in `Waiting` state.
  - `GET /api/v1/devices/mailbox/{id}/status`: Authenticated device polls while awaiting join (`waiting` -> `ready` with `pub_temp`).
  - `POST /api/auth/mailbox/{id}/join` (guarded by `pow_guard`): Unauthenticated client joins with `pub_temp` and receives `token`.
  - Fulfill and pickup complete identical to Flow A.

#### 3. Dual-Mode Passkey Registration (`api::auth::passkey::register`)
- Integrated `app::ticket::Ticket` single-use cache into `resolve_user`.
- Passkey registration ceremonies (`/api/auth/passkey/register/start` and `/finish`) accept either an active session token or an ephemeral `registration_ticket`, enabling newly paired devices without existing sessions to register credentials directly.

#### 4. Multi-Tiered Verification Suite
- **Tier 1 (Domain Unit Tests):** 9 unit tests in `app::mailbox::test` validating Crockford alphabet distribution, atomic state transitions, concurrency races, and cache eviction.
- **Tier 2 (Route DTO Tests):** 13 unit tests in `api::mailbox::test` covering boundary payload limits, hex validation, and response envelopes.
- **Tier 3 (E2E Integration Tests):** 11 end-to-end HTTP integration tests in `crates/server/tests/mailbox.rs` covering both UX flows, PoW verification, ticket ceremonies, rate limiting interaction, and cross-tenant isolation.
- Full workspace tests pass: 156 server lib tests, 45 core tests, 19 CLI tests, and all integration test binaries green with 0 Clippy warnings.

---

## Session Summary: 2026-08-11 — Logging Engine Completion, Middleware Wiring & Test Suite

This session completed the entire telemetry and error-handling architecture, and finished the full logging engine test suite.

### Achievements

#### Error Handling Overhaul
- **`Loggable` Trait:** Implemented `Loggable` (provides `log_level()` and `log_module()`) on all error types: `api::Error`, `storage::Error`, `model::Error`, and the top-level `crate::Error`. Each error domain self-reports its severity and module, eliminating hardcoded `match` statements in middleware.
- **Zero-Cost `IntoResponse` Fork:** The top-level `crate::Error::IntoResponse` now inspects `GLOBAL_LOGGER.get().is_some()`:
  - **Logger alive:** Builds a telemetry `Entry` struct (with `log_level`, `log_module`, `self.to_string()`) *before* consuming `self`, and inserts it into the `Response` extensions backpack for the middleware.
  - **Logger dead:** Falls through the `match self {}` with zero extra allocations.
- **Eliminated `Arc<crate::Error>` Pattern:** Dropped the idea of passing the error as `Arc` through extensions. We format the string *before* consuming the error, bypassing `Clone`/`Copy` trait restrictions entirely.
- **`LOGGING_ENABLED` AtomicBool Removed:** Single source of truth is now `GLOBAL_LOGGER.get().is_some()`. Added a `logging_enabled()` helper function to `crate::logger` for ergonomic use in `route.rs`.

#### Logging Middleware (`api/middleware/logging.rs`)
- **Zero allocation on happy path:** Clones `Method` (enum = cheap) and `Uri` (Arc-backed = cheap) before calling `next.run()`. Only allocates strings inside the `if let Some(entry)` block when an error actually occurred.
- **Returns `Response` not `Result<()>`:** Fixed the catastrophic bug where the response was being dropped.
- **Conditionally wired:** `route_main()` in `route.rs` checks `logging_enabled()` and attaches the middleware layer only when the logger is alive.
- **`ConnectInfo<Ipv4Addr>`:** The server uses `.into_make_service_with_connect_info::<Ipv4Addr>()` to surface client IPs.
- **`socket.send_to` silenced:** The Unix Datagram `send_to` call in `logger/service.rs` now uses `let _ = ...` to ignore errors when the Admin CLI is not running.

#### Logger Service Bug Fixes
- **`format_date_time` uses entry timestamp:** Fixed production bug where the file rotation used `Utc::now()` instead of `entry.timestamp_ms`, which caused queue-lag to put late logs into the wrong file.
- **`commit` uses `entry.timestamp_ms`:** The entire rotation logic now relies purely on the log entry's timestamp. The real-world OS clock is never consulted inside `commit`.

#### Test Suite (`logger/service.rs`)
Three tests, all passing:
1. **`logger_commits_multiple_entries_to_disk`:** Proves `bincode` sequential framing works correctly. Sends 3 entries, shuts down gracefully, opens the `.bin` file, and deserializes entry 1 and entry 2 independently.
2. **`broadcasting_works_via_unix_socket`:** Binds a real `UnixDatagram` to `/tmp/kosh-cli.sock`, fires a log, and asserts the raw bytes are received and deserialize correctly.
3. **`file_rotation_on_every_new_day`:** Sends one log with `Utc::now()` timestamp and one with `Utc::now() + DAY_MILLIS * 2`, then asserts that exactly 2 distinct `.bin` files were created in the log directory.
- **`with_temp_env` helper:** Higher-order async closure that hijacks `XDG_STATE_HOME`, starts the logger, runs the test, and restores the old env var. Uses `tempfile::tempdir()` for ephemeral isolated directories. `#[serial]` ensures no concurrent env var mutation.

### Current State (All 17 tests passing)
- Full upload/download/delete asset pipeline operational.
- Auth (register/login) + Moka session cache + `auth_guard` middleware operational.
- Logging engine: MPSC channel → background service → bincode file + UDS broadcast.
- Error telemetry: `IntoResponse` → `Response::extensions` → `logging_middleware` → `GLOBAL_LOGGER` sender.

### Next Targets
1. **`GET /api/v1/assets` (Media Listing):** The biggest missing API endpoint. Paginated metadata queries for the Android gallery. Need to add `Asset::list(pool, user_id, tag, page, page_size)` to `model/asset.rs` and wire it to a new handler in `api/assets.rs`.
2. **Action Logs (`POST/GET /api/v1/sync/log`):** The encrypted event ledger for client delta sync.
3. **Admin CLI Ratatui Frontend:** `crates/cli/src/main.rs` is still `Hello, world!`. Build the `crossterm` + `ratatui` TUI that connects to `/tmp/kosh-cli.sock` and reads historical `.bin` log files.
4. **Unused Import Cleanup:** Run `cargo fix` to remove lingering deprecated imports in `logger/service.rs` test module.
5. **SQLite WAL Mode Tuning:** Add PRAGMA optimizations to `main.rs`.

---

## Session Summary: 2026-08-09 — High-Performance Logging System (Admin CLI Support)

This session focused on building a completely decoupled, zero-blocking, high-performance logging architecture designed to broadcast telemetry to the Ratatui Admin CLI via Unix Datagram Sockets.

### Achievements
- **MPSC Background Supervisor:** Built a dedicated `LoggerService` that runs entirely independent of the Axum request threads.
- **Zero-State Connectionless Broadcasts:** Integrated `UnixDatagram` sockets (`/tmp/kosh-cli.sock`). The server blindly broadcasts Bincode-serialized telemetry to the socket file.
- **Poison Pill Graceful Shutdown:** A `Level::Shutdown` event explicitly commands the logger to flush and break its loop.
- **Global Macro Architecture:** Stored the `Sender` in a global `OnceLock` to enable frictionless logging via `crate::info!()`, `warn!()`, `error!()`, `fatal!()`.
- **XDG Base Directory Compliance:** Log files stored at `dirs::state_dir()` (`~/.local/state/kosh/logs`), with daily file rotation via Epoch math.

---

## Session Summary: 2026-07-29 — Performance Optimization Cycle COMPLETE

### Achievements
- **Raw Binary Streaming:** Removed `Multipart`. Server accepts raw `application/octet-stream` via `axum::body::Body`. Metadata in HTTP headers (`X-File-Name`, `Content-Length`) and URL path (`/api/v1/upload/:tag`).
- **Bare-Metal Disk Allocation (`fs4` + `fallocate`):** Pre-allocates contiguous disk blocks via `posix_fallocate` before streaming begins.
- **`Payload<S, E>` Newtype:** Bundles `expected_size` and `stream` together.
- **Moka Session Cache:** In-memory TTI cache in `AppState`. `auth_guard` checks RAM before SQLite.
- **`TokenHash` Newtype:** Zero-copy `[u8; 32]` cache key.

---

## Session Summary: 2026-06-29 — Domain Boundaries & Storage Optimization

### Achievements
- **Coordinator Service Pattern:** Upload handler orchestrates Storage + Asset DB.
- **Fail-Fast Strict Protocol:** HTTP 400 on missing metadata.
- **Integer Enum Storage Optimization:** `AssetTag` as `#[repr(i32)]`.
- **`auth_guard` Middleware:** Validates Opaque Token, injects `user_id` via Extension.

---

## Session Summary: 2026-06-22 — Database Initialization

### Achievements
- SQLite schema: `assets`, `users`, `sessions` tables.
- Zero-Knowledge Auth Vault architecture formalized.
- Hybrid session management: Opaque Tokens + Moka in-memory cache.
- Distributed Sync: Event Sourcing via encrypted `action_logs`.

---

## Session Summary: 2026-06-21 — Content-Addressable Storage & Zero-Knowledge Hardening

### Achievements
- **BLAKE3 CAS Architecture:** Files stored by BLAKE3 hash.
- **Path Traversal Immunity:** UUID `.tmp` file before atomic rename.
- **Resilient Batch Uploads:** Catches `StreamReadError` gracefully.
- **Zero-Knowledge Pivot:** Deprecated server-side MIME Detection.

---

## Session Summary: 2026-06-19 — Atomic Upload Resiliency

### Achievements
- **Atomic Uploads:** `try_save` → `.tmp` file → `try_commit` → `tokio::fs::rename`.
- **Fault-Tolerant Cleanup:** Network/disk errors trigger immediate `.tmp` deletion.

---

## Session Summary: 2026-06-17 — Architectural Decoupling

### Achievements
- **Storage Abstraction:** `StorageService` with generic `Stream<Item = Result<Bytes, E>>`.
- **Domain Errors:** `thiserror` enums for `storage::Error`, `api::Error`, `crate::Error`.
- **`IntoResponse`:** Implemented for global `AppError`.
