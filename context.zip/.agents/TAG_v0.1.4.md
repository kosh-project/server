kosh v0.1.4 - Zero-Knowledge Synchronization, Blind Mailbox Relay, Passkeys, and Ingress Defense

This major release transforms Kosh from a foundational storage engine into a full-fledged, zero-knowledge personal synchronization server. Designed specifically to saturate low-power commodity hardware (e.g., single mechanical HDDs) while upholding zero-hardware-trust cryptographic invariants.

Highlights and included subsystems:

Zero-Knowledge Device Pairing & Blind Mailbox Relay
- Ephemeral in-memory mailbox exchange backed by Moka caches for non-authenticated X25519 ECDH key exchange.
- Out-of-band device pairing with terminal ANSI QR codes, BIP-39 verification words, and registration ticket validation.
- Constant-time and constant-status oracle defenses (blind HTTP 404 on nonexistent or invalid mailboxes to thwart identifier enumeration).

WebAuthn / FIDO2 Passkey Authentication & Key Envelopes
- Integrated WebAuthn passkey registration, challenge caching, authentication, and credential revocation.
- Vault Key Envelope encryption enabling client-side master key rotation and secure multi-device recovery without plaintext server exposure.

Stateless Ingress Defense & Anti-DoS Funnel
- Sub-microsecond RAM pre-filter via BLAKE3 MAC verification (mac_guard) validating token signatures and expirations before touching storage or relational engines.
- HMAC-SHA256 Hashcash Proof-of-Work engine (pow_guard) enforcing dynamic computational puzzles on sensitive authentication endpoints to protect Argon2id from CPU exhaustion.
- Tiered per-IP and per-identity Governor rate limiting with token buckets and burst tolerance.

Namespaced Delta-CRDT Activity Ledgers
- Multi-namespace append-only CRDT delta log segmentation partitioned per user and namespace (/vault/ledgers/{user_id}/{namespace}/).
- Complete synchronization protocol: ledger push, pull, upper-bound prune validation, and point-in-time snapshotting.
- Persistent SQLite device synchronization watermarks tracking client high-water sequence numbers.
- Crash-safe single-writer actor model with automated 5 MB segment rotation and ghost-file recovery.

Content-Addressable Storage (CAS) 2-Level Prefix Sharding
- 2-level directory prefix sharding (/vault/ab/cd/<hash>) providing 65,536 bounded leaf directories with <= 256 entries each.
- Eliminates Linux ext4 HTree indirect index bloat and directory lock (i_rwsem) contention during high-density lookups.
- Atomic commit pipeline using pre-allocated disk space (fallocate) and atomic rename(2) mechanics.

Local Network Discovery & Dynamic TLS
- Zero-configuration local network discovery via mdns-sd broadcasting _kosh._tcp.local with TXT record properties.
- Dynamic TLS certificate generation via rcgen with Subject Alternative Names (SANs) populated with detected LAN IPs and .local hostnames.

Containerization & Hardening
- Multi-stage Dockerfile and Docker Compose deployment supporting unprivileged non-root execution.
- CI workflow security hardening with restricted read-only permissions and CodeQL alert remediations (including path sanitization).

Codebase Quality & Test Coverage
- 126 commits since v0.1.3 spanning 182 files (+17,231 / -2,527 lines).
- 235 unit, integration, and doc tests passing across all crates.
- Zero-panic compilation enforcement under strict Clippy nursery and pedantic lints.
