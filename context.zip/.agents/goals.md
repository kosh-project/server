# NAS-rs Future Goals & Technical Debt

## Resumable Uploads for Large Files
- **Context:** Decided on 2026-06-19 during the implementation of atomic uploads.
- **Current State (Phase 1):** We use a simple "All-or-Nothing" atomic upload approach. If a stream fails, the partial `.tmp` file is deleted immediately to prevent leaks and maintain a pristine storage state.
- **Future Goal:** For large blob uploads (GBs in size), dropping a connection means the user loses all progress and wastes network overhead. We need to implement resumable uploads.
- **Implementation Ideas:**
  - Adopt a chunking standard like the `tus` protocol.
  - Client sends byte offsets (`Range`).
  - Server maintains a registry of partial uploads and garbage collects abandoned `.tmp` files.
- **When to implement:** Postpone until the core architecture (database, gallery APIs, authentication) is solid.

## STRICT ARCHITECTURAL RULE: The "Dumb Bucket" Zero-Knowledge Constraint
- **Context:** Decided on 2026-06-19 (Overriding old roadmap bullets about Server-Side MIME detection).
- **Rule:** The server MUST NOT attempt to inspect the contents of uploaded blobs (e.g., no "magic bytes" sniffing, no image parsing). 
- **Reasoning:** Because the Android client encrypts files via AES-GCM before transmission, the payload arriving at the server is pure ciphertext. Inspecting magic bytes would fail anyway, and attempting to do so violates the core philosophy that the server has zero visibility into user data.
- **Resolution:** Any metadata (MIME types, EXIF, original filenames) MUST be determined strictly on the client side and pushed to the server via an encrypted metadata index/database. The server is strictly a blindly-hashing, storage-orchestrating, dumb bucket of bits.

## ✅ COMPLETED: Storage Layer Hardening
- All three targets (zero-byte streams, full integration test, concurrent write collisions) are implemented and passing.

---

## Sync Architecture: Blobs vs. Actions (Decided 2026-07-29)
- **Context:** Discussed during the post-optimization planning session.
- **Core Separation:** The server manages two fundamentally different things:
  - **Blobs** = encrypted files stored by BLAKE3 hash in CAS. Immutable, content-addressable.
  - **Actions** = what users *do* with blobs (move, copy, rename, delete). Tiny encrypted metadata events.

### Three Tiers of Operations
| Tier | Operation | Server Action |
|------|-----------|---------------|
| **Heavy** | Upload | Store blob on disk + create `assets` row + append action log |
| **Heavy** | Delete | Remove `assets` row + maybe delete blob (ref count) + append action log |
| **Light** | Move / Copy / Rename | Append encrypted action log only (zero disk I/O for blobs) |
| **Read** | Download | Serve blob, no log needed |

### Reference-Counted Blob Deletion
- Multiple users can upload the same file (same BLAKE3 hash). Each upload creates an ownership entry in `assets` (`user_id`, `hash`).
- On delete: remove the user's ownership row, then check if anyone else still owns the hash.
- **Only delete the physical blob when the reference count hits zero.**
- This mirrors Unix hard link semantics exactly.

### Race Condition Fix: SQLite Transactions
- **Problem:** If two users delete the same hash simultaneously, both threads could see `COUNT(*) = 1` before the other's DELETE commits, leading to a dangling blob or double-delete.
- **Solution:** Wrap the DELETE + COUNT check in a **single SQLite transaction** (`pool.begin()`). SQLite holds the write lock for the entire transaction duration, preventing interleaving.
- **Pattern:**
  ```rust
  let mut tx = pool.begin().await?;
  sqlx::query!("DELETE FROM assets WHERE user_id=? AND hash=?", uid, hash).execute(&mut *tx).await?;
  let count = sqlx::query_scalar!("SELECT COUNT(*) FROM assets WHERE hash=?", hash).fetch_one(&mut *tx).await?;
  tx.commit().await?;
  if count == 0 { tokio::fs::remove_file(vault.join(hash)).await?; }
  ```

### Encrypted Action Log
- **Schema:** `action_logs(id, user_id, encrypted_payload BLOB, created_at)`
- **Endpoints:**
  - `POST /api/v1/sync/log` — Client pushes an encrypted action event
  - `GET /api/v1/sync/log?after={id}` — Client pulls events newer than their checkpoint
- The server never decrypts or interprets the payload. It's a dumb append-only mailbox.
- Pull-based model — the client decides when to sync.

---

## DEFERRED: Delta Sync / Chunked Deduplication
- **Context:** Discussed on 2026-07-29. User asked about partial file edits requiring full re-uploads.
- **Decision:** Deferred indefinitely. AES-GCM encryption with unique nonces makes binary diffs on ciphertext useless — even a 1-byte plaintext edit produces completely different ciphertext. Chunk-then-encrypt would work but violates "Dumb Bucket" philosophy (server would need to understand file manifests and chunk ordering).
- **Pragmatic reasoning:** On a local LAN (100Mbps–1Gbps), re-uploading a 500MB file takes ~4 seconds. Files that are frequently edited (docs, notes) are small. Files that are large (photos, videos) are rarely edited after creation.
- **Revisit when:** Real-world LAN usage proves re-uploads are a bottleneck.

---

## Upcoming Immediate Goals (API Coverage Milestone)
We are now moving into the **Endpoint Completion Milestone**. The goal is to build out all remaining REST boundaries required by the Android client.

1. **`Asset::delete()` + `DELETE /api/v1/assets/:hash`** — Ref-counted blob cleanup.
2. **`GET /api/v1/assets/:hash`** — Serve blobs back to clients (download endpoint).
3. **Media Listing Endpoint (`GET /api/v1/assets`)** — Paginated metadata queries for the Android client gallery.
4. **Progress Reporting Endpoint** — Needs clarification. (Note: Earlier architecture decisions stated upload progress would be tracked 100% client-side via Android network interceptors to save server CPU. Revisit this to define exactly what the server needs to report — e.g. batch upload summary reports, background sync status, or something else).
5. **Action Logs (`POST/GET /api/v1/sync/log`)** — The encrypted ledger for syncing operations.
6. **Unused Import Cleanup** — Run `cargo fix` to remove dead `Multipart` references.

# Future Goal (Added 2026-08-21)\n* Complete the 79 missing tests across the `server` crate as documented in `test/agents/server_tests_checklist.md`. This is required to achieve 100% test coverage for this security-critical library crate.
