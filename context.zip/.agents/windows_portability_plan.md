# Windows Native Portability Plan

## 1. Goal Overview
Enable native compilation and execution of `webdav-server`, `kosh-core`, and `cli` on `x86_64-pc-windows-msvc` and `x86_64-pc-windows-gnu`.
The primary objective is local developer/friend testing on Windows without requiring WSL or containerization.

---

## 2. Technical Blockers & Solutions

### A. POSIX Permissions & Metadata Extensions
1. **`crates/server/src/auth/secret.rs` & `crates/server/src/auth/test.rs`**:
   - Issue: `std::os::unix::fs::PermissionsExt` and `Permissions::from_mode(0o600)` fail to compile on Windows.
   - Fix: Gate the permission mutation with `#[cfg(unix)]`. Windows NTFS permissions default to user-only DACLs in local profile directories.
2. **`crates/server/src/storage/file.rs`**:
   - Issue: `std::os::unix::fs::MetadataExt::size()` is Unix-only.
   - Fix: Replace with standard, cross-platform `metadata.len()`.

### B. SQLite Connection URL on Windows
1. **`crates/server/src/main.rs`**:
   - Issue: `format!("sqlite://{}/metadata.db", config.vault_path.display())` formats Windows paths like `sqlite://C:\...\metadata.db`. SQLx URI parser rejects drive letters (`C:`) and backslashes.
   - Fix: Use `SqliteConnectOptions::new().filename(config.vault_path.join("metadata.db"))`.

### C. NTFS Sharing Violations on File Renaming
1. **`crates/server/src/storage/transaction.rs`**:
   - Issue: `tokio::fs::File` is held open during `rename(&self.temp, &target)`. On Windows, NTFS enforces mandatory file locking; renaming an open file fails with `ERROR_SHARING_VIOLATION` (os error 32).
   - Fix: Flush and drop the file handle before invoking `rename()`. Obtain file metadata from the target path post-rename.
2. **`crates/server/src/storage/ledger/segment/mod.rs`**:
   - Issue: `self.file.sync_all()` leaves `self.file` open when `fs::rename(&current_path, sealed_path)` executes during segment rotation.
   - Fix: Close/drop `self.file` before renaming `current.log`.

### D. Telemetry IPC: `UnixDatagram` on Windows
1. **`crates/server/src/logger/service.rs` & `crates/cli/src/main.rs`**:
   - Issue: `tokio::net::UnixDatagram` is strictly `#[cfg(unix)]`. Tokio does not support connectionless Unix datagram sockets on Windows.
   - Fix:
     - Recommended: Switch IPC channel to local loopback UDP (`127.0.0.1:<port>`). Loopback UDP is zero-allocation, connectionless, has no external network exposure, and is 100% portable across Windows, Linux, and macOS without platform `cfg` branching.
     - Fallback: Make socket logging optional on Windows or feature-gated.

### E. OpenSSL C-Dependency Vendoring on Windows
1. **`crates/server/Cargo.toml`**:
   - Issue: `webauthn-rs` depends on `openssl`. On Windows, `openssl-sys` fails unless OpenSSL is pre-installed via vcpkg or Win32 installer.
   - Fix: Add target dependency:
     ```toml
     [target.'cfg(windows)'.dependencies]
     openssl = { version = "0.10", features = ["vendored"] }
     ```
     Cargo feature unification ensures OpenSSL is compiled from source via `openssl-src` during `cargo build` on Windows.

---

## 3. Implementation Phases
1. **Phase 1: Zero-Risk Core & Storage Fixes**
   - Replace `metadata.size()` with `metadata.len()`.
   - Gate `PermissionsExt` under `#[cfg(unix)]`.
   - Fix SQLite connection builder to `.filename(...)`.
2. **Phase 2: NTFS Safe Renaming**
   - Ensure open file handles in `Transaction` and `Segment` are dropped prior to rename operations.
3. **Phase 3: Cross-Platform Telemetry Transport**
   - Transition logger broadcast from `UnixDatagram` to local loopback UDP.
   - Update `Config::socket_path` to accommodate UDP socket addresses or platform defaults.
4. **Phase 4: Windows Build Dependencies & Target Verification**
   - Configure `openssl/vendored` for Windows targets.
   - Verify compilation with `cargo check --target x86_64-pc-windows-msvc`.
