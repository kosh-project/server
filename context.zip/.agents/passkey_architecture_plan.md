# Production Architecture Plan: Passkey (WebAuthn), Envelope Encryption & Blind Mailbox Relay

## 1. System Vision & Cryptographic Invariants

Kosh operates under a strict **Zero-Knowledge "Dumb Bucket"** model. The server runs on commodity x86_64 Linux hardware (often Sandy Bridge era CPUs with spinning mechanical HDDs) and must never possess plaintext file content, directory trees, file metadata, or master cryptographic keys.

To support frictionless day-to-day login on Android clients while guaranteeing catastrophic disaster recovery and clean key hygiene, we adopt **Root Envelope Encryption**, **FIDO2/WebAuthn Discoverable Passkeys**, and **Blind In-Memory ECDH Device Hydration**.

### 1.1 The Root Cryptographic Hierarchy
```
                             [ 24-Word BIP-39 Recovery Phrase ]
                                           │
                                           ▼ (PBKDF2 / Argon2id / BLAKE3)
                                 [ 64-Byte BIP-39 Seed ]
                     ┌─────────────────────┼─────────────────────┐
                     │                     │                     │
                     ▼                     ▼                     ▼
             [ identity_hash ]      [ auth_secret ]       [ K_recovery ]
             (32-byte BLAKE3)       (Argon2id Hash)       (32-byte AES-GCM Key)
                     │                     │                     │
                     │                     │                     │
                     ▼                     ▼                     │
             [ Hashcash PoW ]     [ auth_verifier ]              │
             (Used on wire)       (Stored in SQLite)             │
                                                                 │
[ K_vault ] ──────────────── AES-256-GCM Encrypt ────────────────┘
(32B Random True Master)                                         │
(Hardware Keystore/StrongBox)                                    ▼
                                                       [ wrapped_vault_key ]
                                                       (60B Envelope stored in SQLite)
```

1. **`K_vault` (32 bytes):** The true master key generated via cryptographically secure RNG (`SecureRandom`) on client initial setup. It lives strictly inside hardware TEE (Android Keystore / StrongBox) and is unlocked exclusively via local biometrics. **`K_vault` never crosses the network in plaintext.**
2. **`K_recovery` (32 bytes):** Derived deterministically from the user's 24-word BIP-39 paper backup. It exists only temporarily in client RAM during initial account setup, catastrophic recovery, or rotation.
3. **`wrapped_vault_key` (60 bytes):** `AES-256-GCM(key: K_recovery, plaintext: K_vault)`. Consists of 12-byte Nonce + 32-byte Ciphertext + 16-byte Poly1305/GCM Tag. Stored in the server SQLite `users` table.
4. **Millisecond Key Rotation Guarantee:** If the physical 24-word paper backup is compromised, the user generates a new 24-word phrase on an active device. The client encrypts the *existing* `K_vault` under `new_K_recovery` and makes an authenticated `PUT /api/v1/auth/recovery` call. The server updates `identity_hash`, `auth_verifier`, and `wrapped_vault_key` in a single SQLite statement. **Zero CAS blobs or ledger logs are re-encrypted.**

---

## 2. Architectural Questions & Decisions

### Q1: Is the proposed architecture a good idea?
**Verdict: Outstanding.**
- **Envelope Encryption at Root** fixes the biggest flaw in zero-knowledge architectures: immutable master key leakage. Without envelope encryption, leaking the 24 words forces a full re-upload and re-encryption of the entire storage vault. With envelope encryption, rotation completes in 10ms with $O(1)$ database writes.
- **Passkeys (FIDO2 Resident Keys)** deliver modern WebAuthn login natively supported by Android Credential Manager and browser biometrics.
- **Blind Mailbox Relay** elegantly solves the "Second Device Problem." When logging in via Passkey on a new laptop or phone, the server issues a session token but cannot supply `K_vault`. The blind mailbox enables ephemeral end-to-end encrypted key handoff via QR code over RAM with zero server knowledge and zero disk I/O.

### Q2: Has the server already implemented half of what we need?
**Verdict: Yes (~65% already complete).**
- **Already Implemented & Battle-Tested:**
  1. Ingress funnel & rate limiters (`tower_governor`, `SmartIpExtractor`, global/auth quotas).
  2. Stateless Hashcash PoW validation (`pow_guard.rs`, single-pass SHA-256, 16 zero bits, 15s drift, BLAKE3 ephemeral MAC).
  3. Stateless Bearer Token pre-filter (`mac_guard.rs`, 118-byte structured token validation in $<1\mu\text{s}$).
  4. In-memory session resolution cache (`session_cache` via `moka`).
  5. SQLite user lookup decoupled from external identity (`users.id` foreign key throughout sessions, watermarks, snapshots, and vaults).
  6. Hybrid Storage Ledger with append-only segment files and SQLite WAL metadata.
- **What Remains to Implement:**
  1. SQLite schema migration for `wrapped_vault_key` and `webauthn_credentials`.
  2. Updates to `User::create` and `User::verify` to store and return `wrapped_vault_key`.
  3. `PUT /api/v1/auth/recovery` rotation endpoint.
  4. WebAuthn Passkey registration and login endpoints via `webauthn-rs`.
  5. In-memory Moka blind mailbox relay endpoints (`/api/v1/devices/mailbox/*`).

### Q3: Should server admins configure Model 1 vs. Model 2?
**Verdict: Absolutely NOT. The server must remain completely model-agnostic.**
- **Zero-Knowledge Decoupling:** On the wire, the server receives:
  - `identity_hash`: `[u8; 32]`
  - `auth_verifier`: `String` (Argon2id verifier)
  - `wrapped_vault_key`: `Vec<u8>` (60 bytes)
  The server has no cryptographic ability (and no reason) to know whether `identity_hash` was derived from `BLAKE3("kosh-v1-identity-hash", seed)` (Model 1) or `SHA-256("username")` (Model 2). The database schema, validation logic, and foreign key relations are 100% identical.
- **Admin Configuration Trap:** Adding a server admin toggle creates unnecessary operational friction, violates zero-knowledge isolation, and introduces client-server compatibility mismatches.
- **Client-Side Policy:** The official Android app should strictly enforce **Model 1 (Passwordless)** to eliminate the "Two-Secret UX Trap" (where users are prompted for a password and then immediately prompted for a 24-word phrase). Third-party or CLI clients can use Model 2 without changing a single line of backend Rust code.

---

## 3. Production Component Architecture

```
                    Axum HTTP / TLS Ingress (6969)
                                │
        ┌───────────────────────┴───────────────────────┐
        ▼                                               ▼
[ Unauthenticated Pipeline ]                 [ Authenticated Pipeline ]
  • /api/auth/challenge                        • /api/v1/sync/*
  • /api/auth/register                         • /api/v1/assets/*
  • /api/auth/login                            • /api/v1/auth/recovery
  • /api/auth/passkey/login/*                  • /api/v1/auth/passkey/register/*
        │                                      • /api/v1/devices/mailbox/*
        ▼                                               │
┌─────────────────────────┐                             ▼
│  Layer 1: IP Limiter    │                   ┌─────────────────────────┐
│  Layer 2: PoW Guard     │                   │  Layer 1: IP Limiter    │
│  Layer 3: Route Handler │                   │  Layer 2: MAC Guard     │
└───────────┬─────────────┘                   │  Layer 3: Device Limit  │
            │                                 │  Layer 4: Auth Guard    │
            │                                 └────────────┬────────────┘
            ▼                                              ▼
┌────────────────────────────────────────────────────────────────────────┐
│                              AppState                                  │
│  • db: SqlitePool (WAL Mode)                                           │
│  • secret: K_server (Token signing)                                    │
│  • pow_secret: K_ephemeral (Challenge signing)                         │
│  • session_cache: Cache<TokenHash, i64>                                │
│  • webauthn: Arc<Webauthn>                                             │
│  • passkey_challenges: Cache<Uuid, PasskeyChallengeState> (TTL: 60s)  │
│  • mailboxes: Cache<MailboxId, MailboxEntry> (TTL: 300s)               │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
       ┌────────────────────────────┴────────────────────────────┐
       ▼                                                         ▼
┌───────────────────────────────┐               ┌────────────────────────────────┐
│      SQLite WAL Database      │               │   RAM-Only Ephemeral Stores    │
├───────────────────────────────┤               ├────────────────────────────────┤
│ • users (+ wrapped_vault_key) │               │ • mailboxes (5-min ECDH relay) │
│ • webauthn_credentials        │               │ • passkey_challenges (60s TTL) │
│ • sessions                    │               │ • session_cache (30-day token) │
│ • device_sync_watermarks      │               └────────────────────────────────┘
│ • ledger_snapshots            │
└───────────────────────────────┘
```

---

## 4. Database Schema Migration

A new migration `20261024000000_passkey_and_envelope.sql` will apply the necessary schema enhancements:

```sql
-- 1. Add wrapped_vault_key to users table
ALTER TABLE users ADD COLUMN wrapped_vault_key BLOB NOT NULL DEFAULT (zeroblob(60));

-- 2. WebAuthn Passkey credentials table
CREATE TABLE IF NOT EXISTS webauthn_credentials (
    credential_id BLOB PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    passkey_name TEXT NOT NULL,
    passkey_data BLOB NOT NULL,
    created_at INTEGER NOT NULL,
    last_used_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_webauthn_user 
ON webauthn_credentials(user_id);
```

> [!NOTE]
> `webauthn-rs` provides a serializable `Passkey` struct containing the credential ID, public key, counter, and registration metadata. Serializing this struct directly into `passkey_data` (via JSON or Bincode) preserves compatibility across all WebAuthn authenticators and algorithm curves (ES256, Ed25519, RS256).

---

## 5. Implementation Phases & Roadmap

### Phase 1: Database Migration & Model Layer Update
1. Create `crates/server/migrations/20261024000000_passkey_and_envelope.sql`.
2. Update `crates/server/src/model/user.rs`:
   - Update `User::create` to accept `wrapped_vault_key: &[u8]`.
   - Update `User::verify` to return `VerifiedUser { id: i64, wrapped_vault_key: Vec<u8> }`.
   - Add `User::rotate_recovery(pool: &SqlitePool, user_id: i64, new_identity_hash: &[u8], new_auth_verifier: &str, new_wrapped_vault_key: &[u8]) -> Result<()>`.
3. Add `crates/server/src/model/passkey.rs`:
   - Define `PasskeyRecord` and SQLite query methods (`insert`, `find_by_cred_id`, `list_for_user`, `delete`).

### Phase 2: Register, Login, and Recovery Rotation Endpoints
1. Update `crates/server/src/api/auth/register.rs`:
   - Request DTO:
     ```rust
     #[derive(Deserialize)]
     pub struct Request {
         pub auth_verifier: String,
         pub wrapped_vault_key: String, // hex-encoded 60-byte binary blob
     }
     ```
   - Decode and validate exact 60-byte length.
2. Update `crates/server/src/api/auth/login.rs`:
   - Response DTO:
     ```rust
     #[derive(Serialize)]
     pub struct Response {
         pub token: String,
         pub wrapped_vault_key: String, // hex-encoded 60-byte binary blob
     }
     ```
3. Implement `PUT /api/v1/auth/recovery`:
   - Request DTO:
     ```rust
     #[derive(Deserialize)]
     pub struct RecoveryRequest {
         pub new_identity_hash: String,
         pub new_auth_verifier: String,
         pub new_wrapped_vault_key: String,
         pub revoke_other_sessions: bool,
     }
     ```
   - Handler verifies caller via `Extension<i64>` from `auth_guard`.
   - Performs atomic SQLite update in transaction.
   - If `revoke_other_sessions == true`, deletes all other sessions for `user_id` and evicts from `session_cache`.

### Phase 3: WebAuthn Integration (`webauthn-rs`)
1. Add `webauthn-rs = "0.5"` to `crates/server/Cargo.toml`.
2. Update `kosh-core::config::Config`:
   - Add `rp_id` (default `"localhost"`), `rp_origin` (default `"http://localhost:6969"`), and `rp_name` (default `"Kosh Vault"`).
3. Initialize `Arc<Webauthn>` in `AppState::new`.
4. Add in-memory `passkey_challenges: Cache<Uuid, PasskeyRegistration/LoginState>` with 60-second TTL.
5. Endpoints:
   - `POST /api/v1/auth/passkey/register/start` (Protected)
   - `POST /api/v1/auth/passkey/register/finish` (Protected)
   - `POST /api/auth/passkey/login/start` (PoW Guarded)
   - `POST /api/auth/passkey/login/finish` (PoW Guarded $\rightarrow$ issues 118-byte Bearer token)

### Phase 4: Blind Mailbox Relay (Cross-Device ECDH Hydration)
1. Add `mailboxes: Cache<MailboxId, MailboxEntry>` to `AppState`:
   ```rust
   pub struct MailboxEntry {
       pub user_id: i64,
       pub encrypted_payload: Option<Vec<u8>>,
       pub created_at: i64,
   }
   ```
   - Cache configuration: `time_to_live(Duration::from_secs(300))` (5 minutes).
2. Endpoints:
   - `POST /api/v1/devices/mailbox` (Generates random 6-character alphanumeric or UUID `mailbox_id`, registers empty entry bound to caller's `user_id`).
   - `POST /api/v1/devices/mailbox/{id}/fulfill` (Validates caller belongs to same `user_id`, stores ciphertext blob up to 1024 bytes).
   - `GET /api/v1/devices/mailbox/{id}` (Validates caller, returns ciphertext, and atomically invalidates entry).

### Phase 5: Hardening, Verification & Test Coverage
1. Unit tests for `User::create`, `User::verify`, and `User::rotate_recovery`.
2. Unit tests for mailbox state transitions (expired TTL, single-read eviction, unauthorized cross-user pickup).
3. Integration tests for `/api/auth/register`, `/api/auth/login`, and `/api/v1/auth/recovery`.
4. Ensure zero Clippy warnings (`cargo clippy --workspace --all-targets -- -D warnings`).
5. Ensure `cargo fmt --check` and `cargo test --workspace` pass completely.

---

## 6. Systems Rust Quality Checklist
- **Zero unwrap/expect:** All failures must map to domain error types (`crate::api::Error` or `crate::model::Error`).
- **Bounded Allocations:** Mailbox payload capped at 1 KB; Hex decoding rejects payloads not matching exact byte constraints before allocation.
- **Zero Disk Thrashing:** Mailbox relay and WebAuthn challenges live exclusively in `moka` RAM caches with tight TTLs (300s and 60s).
- **Constant-Time Comparisons:** Ephemeral tokens and secrets evaluated using constant-time MAC checks.
