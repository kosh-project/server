# Kosh Project — Agent Context Digest
# Generated: 2026-09-21 (feat/tls-impl branch)

This file is a comprehensive digest of the *current* state of the codebase for
AI agents joining a session mid-project. Always cross-reference with
`project.md`, `goals.md`, and `roadmap.md` for higher-level context.

---

## Workspace Structure

```
kosh/
├── Cargo.toml              — Workspace root, shared lints and dependencies
├── crates/
│   ├── core/               — kosh-core: shared types used by server and cli
│   ├── server/             — webdav-server: Axum HTTP server, all backend logic
│   └── cli/                — cli: Ratatui admin TUI
└── .agents/                — YOU ARE HERE (agent context files)
```

### Workspace-Level Lints (Cargo.toml)
The workspace enforces **extremely strict** Clippy lints. Critically:
- `unwrap_used = "deny"` — no `.unwrap()`
- `expect_used = "deny"` — no `.expect()`
- `indexing_slicing = "deny"` — no `arr[i]` panics
- `todo = "deny"` — no `todo!()` in committed code
- `panic = "deny"` — no `panic!()`

This matters a lot. Every `?`, `.ok_or()`, and error variant exists for a reason.

---

## `kosh-core` Crate

The shared library. Contains types consumed by both the server and the CLI.
**Never add server-specific HTTP or database logic here.**

### `config` module (`crates/core/src/config/`)
- `Config` struct — KDL-parsed via `knuffel::Decode`. Fields:
  - `vault_path: PathBuf` — root of all storage (default: `./vault`)
  - `port: u16` — server port (default: 6969)
  - `host: String` — bind address (default: `0.0.0.0`)
  - `enable_tls: bool` — toggles TLS on the Launcher
  - `socket_path: String` — UDS path for CLI telemetry (default: `/tmp/kosh.sock`)
- `Config::load_or_init(path)` — reads KDL file, or creates a default one
- `Config::log_path()` → `vault/state/logs/`
- `Config::tls_identity_path()` → `vault/tls/`
- `error::Result<T, E = Error>` — **important**: the second generic defaults to
  `Error` so `knuffel::Decode` macros can inject their own error type without
  a name collision. This was a macro hygiene fix made in this branch.

### `logger` module (`crates/core/src/logger/mod.rs`)
Canonical shared types for the telemetry pipeline:
- `Level` enum (`Info`, `Warning`, `Error`, `Fatal`, `Shutdown`) — `repr(u8)`
- `Module` enum (`Server`, `Database`, `Storage`, `Asset`, `Api`, `Ledger`, `Logger`) — `repr(u8)`
- `Entry` struct — the wire format for a single log line (bincode-encoded)
- `Telemetry` enum — **the UDS wire format**:
  - `Telemetry::Log(Entry)` — a real log event
  - `Telemetry::Heartbeat` — idle ping (prevents CLI from falsely showing "OFFLINE")

**Key invariant:** `Entry` is written raw to `.bin` disk files. `Telemetry` is
what gets sent over the Unix Domain Socket. Disk is clean; UDS carries extra control signals.

### `tls` module (`crates/core/src/tls/`)
- `Identity` struct — holds `cert_pem: String` and `key_pem: String`
- `Identity::load_or_create(vault_path)` — loads or self-generates a cert
- `Identity::load(cert_path, key_path)` — loads existing PEM files
- `Identity::fingerprint()` → `String` (hex-encoded SHA-256 of cert DER)
- `Identity::fingerprint_raw()` → `[u8; 32]` (raw bytes — used by CLI for BIP-39 words and QR code)
- `error::Error` — variants: `Io`, `CertificateGen`, `NoCertificatesFound`

---

## `webdav-server` Crate

The production Axum server. Uses Tokio, sqlx (SQLite), and many custom services.

### Boot Sequence (`crates/server/src/main.rs`)
1. `Config::load_or_init("test/kosh.kdl")` — load config
2. `Service::start(&config)` — start background logger
3. `GLOBAL_LOGGER.set(sender)` — wire global logger
4. `tls::Identity::load_or_create(&config.vault_path)` — load or generate cert
5. `sqlx::migrate!().run(&pool)` — run DB migrations
6. `AppStateBuilder::new().vault_path(...).db(pool).build()` — build app state
7. `Launcher::new(...)` + `.run(shutdown_signal())` — serve HTTP(S)
8. Graceful shutdown: close pool → shutdown ledger → send `Shutdown` → wait for logger

### Logger Service (`crates/server/src/logger/`)
- `GLOBAL_LOGGER: OnceLock<Sender<Entry>>` — global sender, set once on boot
- `logging_enabled()` — checks if logger is live (used by error middleware)
- Macros: `info!`, `warn!`, `error!`, `fatal!`, `shutdown!` — convenience wrappers
- `Service::start(&config)` — spawns background logging task, returns `(Sender<Entry>, LoggerHandler)`
- **Service::run loop (critical):** Uses `tokio::select!` with a 3-second interval tick:
  - If a log `Entry` arrives: commit to disk + broadcast `Telemetry::Log` over UDS
  - If 3 seconds elapse with no log: broadcast `Telemetry::Heartbeat` over UDS
  - If `Level::Shutdown` entry received: break loop cleanly
- `Service::commit(entry)` — writes raw `Entry` to `.bin` file, sends `Telemetry::Log` to UDS
- `Service::send_heartbeat()` — encodes and sends `Telemetry::Heartbeat` to UDS
- `LoggerHandler::shutdown_with_grace(secs)` — waits for task to join with timeout

### Storage Layer (`crates/server/src/storage/`)
- **CAS model** — Content-Addressable Storage using BLAKE3
- Files stored by their hash, never by user-provided name (path traversal impossible)
- `Transaction` — atomic upload: stream → `.tmp` file → hash → `rename(2)`
- `Payload` — wraps a stream + expected size for Content-Length validation
- `Metadata` — returned after commit: contains hash and file size

### Ledger (`crates/server/src/storage/ledger/`)
A per-user append-only delta sync log for the offline-first sync architecture.
- `Handle` — cheap-to-clone actor handle wrapping an `mpsc::Sender`
- `Handle::spawn(vault_path)` — starts the background ledger actor
- `Handle::append(user_id, bytes)` → `Receipt` — write encrypted delta to disk
- `Handle::prune(user_id, keep_n)` — delete old segments, keep last N
- `Handle::read_segment(vault_path, user_id, file_name, offset)` — read from cursor
- `Handle::shutdown(sender)` — cleanly drain and stop actor
- Segments stored at `vault/ledgers/{user_id}/delta_{seq_num}`
- `CURRENT` file tracks the active segment name
- Segments auto-rotate at 5MB; a 500-byte header is pre-allocated on creation
- **Security:** `read_segment` validates filename against path traversal attacks

### App State (`crates/server/src/app/`)
- `State` — shared across all Axum handlers: `storage`, `db`, `session_cache`, `ledger`
- `AppStateBuilder` — builder pattern, injectable in tests

### HTTP Layer (`crates/server/src/api/`)
- Protected routes under `/api/v1/` — `auth_guard` middleware applied via `.route_layer()`
- Auth uses opaque `TokenHash` (BLAKE3 of the plaintext token, stored in SQLite)
- `moka::Cache<TokenHash, UserId>` — in-memory session cache, 10-min TTI

### TLS / Launcher (`crates/server/src/server.rs`)
- `Launcher` — wraps the Axum `Router` and `tls::Identity`
- Switches between `axum_server::bind` (plain) and `axum_server::bind_rustls` (TLS)
- Graceful shutdown via `axum_server::Handle::graceful_shutdown(10s)`

---

## `cli` Crate (Admin TUI)

The Ratatui terminal dashboard, fully refactored in this branch into a clean
`core/` + `ui/` architecture.

### Directory Structure (post-refactor)
```
crates/cli/src/
├── main.rs            — TUI event loop, UDS socket, tokio::select!
├── core/
│   ├── mod.rs
│   └── pairing.rs     — pure business logic: BIP-39, QR, network IPs
└── ui/
    ├── mod.rs
    ├── app.rs         — App state + Widget impl + input routing
    ├── help.rs        — Help popup widget
    ├── pair_info.rs   — Device Pairing popup widget
    └── logs/
        ├── mod.rs     — Entry struct + span converters
        ├── filter/    — Filter bar UI + selected level logic
        └── list/      — Log list widget, scrolling, input, rendering
```

### `core/pairing.rs` — Zero-Allocation Pre-Computation
`PairingData` struct is built **once on boot** from the TLS cert fingerprint:
- `fingerprint: String` — Base64-encoded SHA-256 of the cert DER
- `words: Vec<Line<'static>>` — 12 BIP-39 mnemonic words pre-formatted into 3 rows
- `qr_lines: Vec<Line<'static>>` — QR code pre-rendered as Unicode block characters
- `server_address: Vec<Line<'static>>` — local + network IPs formatted with interface names

**Performance contract:** Nothing in the 100ms render loop does crypto, string
allocation, or network IO. All heavy work is done at startup in `PairingData::new()`.

### `ui/app.rs` — Application State Machine
```rust
pub struct App {
    pub last_seen: Instant,    // for heartbeat liveness check
    entries: logs::List,       // ring buffer of up to 3000 log entries
    show_help: bool,
    pub should_quit: bool,
    pub pair_info: PairInfo,   // contains PairingData + is_online bool
}
```
- `App::try_init(&config)` — loads today's `.bin` log file from disk on startup
- `App::append(&[u8])` — called on every UDS recv; decodes `Telemetry`, routes to list
- `App::handle_event(&Event)` — key/mouse routing
- Key bindings: `p` = toggle pairing, `h` = toggle help, `q` = quit, `/` = open filter, `Esc` = close overlays

### `main.rs` — The Event Loop
```
tokio::select! {
    event_stream.next()  →  app.handle_event()
    socket.recv()        →  app.append()   [UDS bytes]
    ticker.tick() (100ms)→  check liveness (5s timeout) + needs_render = true
}
```
The liveness check: `if app.last_seen.elapsed() >= 5s { app.pair_info.is_online = false }`

### `ui/pair_info.rs` — Pairing Dashboard
The popup widget renders:
1. Server status (ONLINE ◉ / OFFLINE ◇)
2. Server addresses (localhost + all non-loopback IPv4 with interface name)
3. QR code (Unicode half-block chars, binary payload for maximum density)
4. Verification words (3 rows × 4 words from BIP-39 mnemonic)
5. TLS fingerprint (sha256/<base64>)

Layout is **dynamically calculated** from `qr_lines.len()` — no hardcoded heights.

### `ui/logs/` — Log List
- `EntryList` — a `VecDeque<Entry>` ring buffer capped at 3000 entries
- `base_id: u64` — absolute ID counter; increments on eviction so filtered IDs remain valid
- `filtered_list: VecDeque<u64>` — absolute IDs of currently-matching entries
- Auto-scroll: follows tail unless user manually scrolls up
- Filter: level filter + keyword search (lowercase match against `raw.message`)
- Column widths for Level, Module, Time are adjustable by mouse drag

---

## Branch Summary (`feat/tls-impl`)

Changes introduced since `main`:

| Area | Change |
|------|--------|
| `kosh-core` | Extracted shared `Config`, `logger::*`, `tls::*` types into a shared lib |
| `kosh-core/config` | Fixed macro hygiene bug: `Result<T, E = Error>` allows `knuffel::Decode` to work |
| `kosh-core/logger` | Added `Telemetry` enum (`Log` / `Heartbeat`) |
| `kosh-core/tls` | Added `fingerprint_raw()` returning raw `[u8; 32]`, added `NoCertificatesFound` error |
| `server/logger` | Refactored to use `Config` for paths; added `socket_path` field; 3-second heartbeat loop |
| `server/main` | Wired `Config` into boot, TLS identity, logger, SQLite migrations |
| `server/server` | `Launcher` supports toggle between TLS and plain mode |
| `cli` | **Full architecture refactor**: `core/` + `ui/` separation |
| `cli/core/pairing` | Zero-allocation pre-computation of QR, BIP-39 words, addresses |
| `cli/ui/pair_info` | Device Pairing popup: QR code, words, fingerprint, online status |
| `cli/main` | 5-second liveness check on `last_seen` instant |

---

## Known Issues / TODOs at This Checkpoint

1. `_render_heading()` in `pair_info.rs` is dead code (prefixed `_`). The ASCII
   art header is commented out. Either remove it or wire it back.
2. `broadcasting_works_via_unix_socket` test in `logger/service.rs` receives a
   raw `Entry` (not `Telemetry`) in its assertion — this test may be stale now
   that the UDS sends `Telemetry::Log(entry)` instead of plain `Entry`.
3. The `cli` crate does not yet have workspace lints enabled (commented out:
   `# workspace = true` in `crates/cli/Cargo.toml`).
4. `cli/src/ui/app.rs` still imports `webdav_server::logger` instead of
   `kosh_core::logger` for some types. Worth unifying.
5. `_ledger_path` was removed from `Config` — ledger path is currently
   hardcoded as `vault/ledgers/` inside the ledger code itself. Should
   eventually be a `Config` field.

---

## Next Steps (Per User Discussion)

The user will tell you what's next. Likely candidates (not confirmed):
- Wire the pairing screen's QR code to the actual TLS boot (server generates
  cert → CLI reads same cert → displays QR). This is structurally done but
  needs end-to-end validation.
- Enable workspace lints for `cli` crate.
- Fix the stale UDS socket test.
- Begin `main` branch milestones: asset deletion safety, CAS/metadata
  transaction boundary, migrations on boot, HTTP integration tests.

---

## Agent Rules (from AGENTS.md)

- **READ ONLY by default** — you may NOT write to source code unless the user
  explicitly grants permission per-task.
- You CAN write to `.agents/*.md` freely.
- No commits, no pulls, no merges.
- Be Socratic. Don't spoon-feed solutions — ask questions, guide the user.
- Be strict and give constructive criticism.
- Be a GenZ peer, not a boring professor.
