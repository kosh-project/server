# Architectural Directives: Hybrid Ledger & Mechanical HDD Storage Engine

## 1. Architectural Mandate: Reject SQLite `ledger_entries`
Do NOT create an SQLite table for raw encrypted CRDT payloads (i.e., do NOT implement `ledger_entries`). 

### Why SQLite Payload Storage Fails on Target Hardware
* **Hardware:** Intel Sandy Bridge, 10 GB RAM, mechanical spinning HDD on headless Arch Linux.
* **Fragmentation & VACUUM Overhead:** Ingestion of binary payloads followed by pruning (`DELETE FROM ledger_entries WHERE sequence_id <= ?`) creates sparse page holes in SQLite. Reclaiming disk space requires `VACUUM`, which duplicates the database file on disk, triggers sustained random I/O head thrashing, and blocks Tokio worker threads.
* **Preserving Existing Code:** The codebase already implements an append-only, length-prefixed segmented log engine (`crates/server/src/storage/ledger/` via `segment.rs`, `committer.rs`, and `handle.rs`). We are retaining this system. Sequential append writes saturate mechanical disk bandwidth (~150 MB/s) with zero head seek thrashing.

---

## 2. Hybrid Storage Topology

Storage responsibility is strictly bifurcated between SQLite and the filesystem:

```text
┌────────────────────────────────────────────────────────┐
│                   Axum Route Handlers                  │
└───────────────┬────────────────────────┬───────────────┘
                │                        │
       (Relational Metadata)       (Binary Payloads)
                ▼                        ▼
┌─────────────────────────────┐  ┌──────────────────────────────────────────────┐
│         SQLite WAL          │  │       Filesystem Append-Only Log             │
├─────────────────────────────┤  ├──────────────────────────────────────────────┤
│ • device_sync_watermarks    │  │ /vaults/{user_id}/ledger/{namespace}/        │
│ • ledger_snapshots          │  │   ├── current.log (active append stream)     │
└─────────────────────────────┘  │   ├── 0000000000000000.log (sealed segment)  │
                                 │   └── 00000000000003e8.log (sealed segment)  │
                                 └──────────────────────────────────────────────┘
```

1. **SQLite (WAL Mode):** Stores exclusively relational metadata, high-water marks, device liveness, and snapshot references. Rows are small, fixed-width, and write-infrequent.
2. **Filesystem (Segmented Append-Only Log):** Stores all encrypted delta payloads inside user- and namespace-isolated directory partitions.

---

## 3. SQLite Migration Specification

Create `crates/server/migrations/20261018200000_create_sync_metadata.sql` containing **only** the metadata schemas:

```sql
-- 1. Device High-Water Mark Tracker
CREATE TABLE IF NOT EXISTS device_sync_watermarks (
    device_id BLOB NOT NULL,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    namespace TEXT NOT NULL,
    last_synced_seq INTEGER NOT NULL DEFAULT 0,
    last_seen_at INTEGER NOT NULL,
    is_revoked INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (device_id, user_id, namespace)
);

CREATE INDEX IF NOT EXISTS idx_watermarks_active
ON device_sync_watermarks(user_id, namespace, is_revoked, last_seen_at);

-- 2. Client Baseline Snapshots in CAS
CREATE TABLE IF NOT EXISTS ledger_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    namespace TEXT NOT NULL,
    snapshot_seq INTEGER NOT NULL,
    blob_hash BLOB NOT NULL, -- BLAKE3 hash pointing to CAS storage
    created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_snapshots_lookup
ON ledger_snapshots(user_id, namespace, snapshot_seq DESC);
```

---

## 4. Segmented File Ledger Refactoring

Update `crates/server/src/storage/ledger/` to support **Namespaced Paths** and **Segment-Level Pruning**.

### Directory Structure

```text
/vaults/{user_id}/ledger/{namespace}/
├── current.log               <-- Active append segment for incoming pushes
├── 0000000000000000.log      <-- Sealed segment (records seq 0 to 999)
└── 00000000000003e8.log      <-- Sealed segment (records seq 1000 to 1999)
```

### Protocol & Naming Invariants

1. **Length-Prefixed Wire Frame:** Every entry in `.log` files maintains the existing length-prefixed framing:
```text
[ payload_len: u32 (4 bytes, Big-Endian) ][ sequence_id: u64 (8 bytes) ][ encrypted_payload: [u8] ]
```

2. **Segment Rotation:**
* When `current.log` reaches threshold size (e.g., 1,000 entries or 2 MB), `committer.rs` seals it.
* It is renamed to `{first_sequence_id:016x}.log` representing the base sequence contained within that segment.
* A fresh `current.log` is opened.

3. **Sequential Read Traversal (`/pull`):**
* Given `namespace` and `since_seq`, determine which segment file contains `since_seq`.
* Open that segment, seek sequentially using length prefixes, stream entries up to `limit`, and proceed across segment boundaries if necessary. Zero full-directory scans.

---

## 5. Pruning Logic: Segment Truncation

Pruning is triggered via `POST /api/v1/ledger/prune` with `{ "namespace": "files" }`. It must **never** run row-by-row deletes. It executes as follows:

### Step 1: Compute Safe Sequence via SQLite

Run a fast relational query to determine the highest sequence all active devices have acknowledged:

```sql
WITH active_devices AS (
    SELECT MIN(last_synced_seq) AS min_device_seq
    FROM device_sync_watermarks
    WHERE user_id = :user_id
      AND namespace = :namespace
      AND is_revoked = 0
      AND last_seen_at > :stale_cutoff -- (now - 30 days)
),
latest_snapshot AS (
    SELECT MAX(snapshot_seq) AS max_snapshot_seq
    FROM ledger_snapshots
    WHERE user_id = :user_id
      AND namespace = :namespace
)
SELECT MIN(
    COALESCE(active_devices.min_device_seq, 0),
    COALESCE(latest_snapshot.max_snapshot_seq, 0)
) AS safe_prune_seq
FROM active_devices, latest_snapshot;
```

### Step 2: Filesystem Segment Deletion ($O(1)$ Space Reclamation)

1. Read the sealed segments in `/vaults/{user_id}/ledger/{namespace}/`.
2. For each sealed segment `{start_seq:016x}.log`:
* Inspect its next sibling segment or header to verify `end_seq <= safe_prune_seq`.
* If true, call `std::fs::remove_file(segment_path)`.
3. The underlying ext4/XFS filesystem drops the inode immediately. The HDD reclaims the contiguous physical blocks with zero fragmentation and without database lock contention.
