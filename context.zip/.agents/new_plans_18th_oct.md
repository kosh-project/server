# Kosh Framework: Architecture, Cryptography & Systems Specification

```markdown
# Context Specification: Kosh Local-First Zero-Knowledge Storage Engine

## 1. System Vision & Hardware Constraints

Kosh is an end-to-end encrypted (E2EE), zero-knowledge, local-first storage and synchronization engine across Android clients and a self-hosted Linux server. The server functions strictly as an untrusted, blind "Dumb Bucket" with zero visibility into plaintext content, directory layouts, metadata, or file types.

### Server Target Profile
- **CPU:** Intel Core i5/i7 (Sandy Bridge microarchitecture).
  - *Vector Extensions:* AVX supported.
  - *Cryptographic Extensions:* **No SHA-NI hardware acceleration.** Scalar SHA-256 is expensive.
- **Memory:** 10 GB RAM.
- **Storage:** Mechanical spinning hard disk drive (HDD), ext4/XFS on headless Arch Linux.
- **Core Systems Invariant:** Disk seeks kill throughput. Malicious, malformed, or unauthenticated ingress traffic must be filtered entirely in RAM within nanoseconds to microseconds, preventing cache eviction, Tokio worker thread starvation, and random disk I/O thrashing.

---

## 2. Ingress Funnel Architecture

Traffic entering the Axum server is bifurcated into two mutually exclusive pipelines: Unauthenticated Routes (PoW-shielded) and Authenticated Routes (stateless MAC + rate-limit shielded).

### Pipeline A: Unauthenticated Boundaries (`/api/auth/*`)
Protects CPU-heavy cryptographic operations (Argon2id, SQLite user creation) from denial-of-service and credential-stuffing attacks.


```

Incoming Request
│
▼
[ Layer 1: Auth IP Governor (tower_governor) ]
• Key: Client IP
• Quota: 2 req/s, Burst: 2
│
▼
[ Layer 2: Stateless Hashcash Guard (pow_guard middleware) ]
• Header: X-Hashcash
• Rejects if len > 168 or len not in (165, 168)
• Single-pass SHA-256 over entire header (requires 16 leading zero bits)
• Validates TTL: (now - 15s) <= timestamp <= (now + 5s)
• Validates BLAKE3 MAC using ephemeral RAM-only key (K_ephemeral)
• Injects verified HashCash struct into Request Extensions
│
▼
[ Layer 3: Route Handlers (login, register) ]
• Deserializes JSON body only AFTER PoW and MAC succeed
• Resolves user credentials against SQLite

```

#### Detailed Hashcash Wire Protocol & Zero-Allocation Slicing
The `X-Hashcash` header eliminates delimiter scanning and serializes directly to a deterministic layout[cite: 6]:

| Offset | Length | Field | Description |
| :--- | :--- | :--- | :--- |
| `0..64` | 64 | `identity_hash` | Hex-encoded SHA-256 of client public identity[cite: 6] |
| `64..80` | 16 | `nonce` | Fixed 16-character hex/ASCII string selected by client[cite: 6] |
| `80..96` | 16 | `timestamp_hex` | Hex-encoded 64-bit Unix seconds[cite: 6, 7] |
| `96..160` | 64 | `mac_hex` | Hex-encoded BLAKE3 keyed hash[cite: 6, 7] |
| `160..` | 5 or 8 | `action` | `"login"` (165 total bytes) or `"register"` (168 total bytes)[cite: 6] |

- **Verification Order (Cheapest to Most Expensive):**
  1. `verify_len`: Header length must be strictly 165 or 168[cite: 6].
  2. `verify_pow`: `Sha256::digest(header.as_bytes())` must have `hash[0] == 0 && hash[1] == 0`[cite: 6].
  3. `verify_action`: `&header[160..]` must equal `"login"` or `"register"`[cite: 6].
  4. `verify_timestamp`: Parse `u64::from_str_radix(&header[80..96], 16)`[cite: 6]. Ensure freshness within 15s window[cite: 6].
  5. `verify_mac`: Stream `timestamp_hex`, raw IP bytes (`match ip { V4(ip) => ip.octets(), V6(ip) => ip.octets() }`), and `action` into `blake3::Hasher::new_keyed(&pow_secret.key())`[cite: 6]. Compare against `mac_hex`[cite: 6].

### Pipeline B: Authenticated Routes (`/api/v1/*`)
Protects Content-Addressable Storage (CAS) operations and ledger synchronization.


```

Incoming Request
│
▼
[ Layer 1: Global IP Governor (tower_governor) ]
• Key: Client IP
• Quota: 25 req/s, Burst: 10
│
▼
[ Layer 2: Stateless Token Pre-Filter (mac_guard) ]
• Header: Authorization: Bearer 
• Verifies token structure, expiration, and BLAKE3 MAC using persistent K_server
• Drops forged/expired tokens in < 1µs in RAM without hitting DB or cache
• Injects TokenHash = BLAKE3(token) into Request Extensions
│
▼
[ Layer 3: Device Token Governor (tower_governor) ]
• KeyExtractor: TokenExtractor reading TokenHash from extensions
• Quota: 15 req/s, Burst: 5
• Clamps runaway device sync loops before touching session storage
│
▼
[ Layer 4: Session Resolution (auth_guard) ]
• Fast Path: In-memory Moka cache (TokenHash -> user_id)
• Slow Path: SQLite WAL lookup (only on cache miss)
• Injects authenticated user_id into Request Extensions
│
▼
[ Layer 5: Route Handlers (CAS Blobs, Ledger Pull/Push) ]

```

---

## 3. Cryptographic Primitives & Key Management

### Key Classes
1. **`K_server` (Persistent Session Secret):**
   - 32-byte secret loaded on boot from a POSIX `0600` configuration file.
   - Used exclusively to sign and verify bearer tokens via native BLAKE3 keyed mode[cite: 9].
   - Survives server restarts to maintain active user sessions.
2. **`K_ephemeral` (RAM-Only PoW Secret):**
   - 32-byte secret randomly initialized in RAM on every Axum boot.
   - Signs Hashcash challenges with a strict 15-second TTL[cite: 3, 7].
   - If the server restarts, inflight PoW puzzles expire harmlessly; clients pull a fresh challenge[cite: 4].
3. **`K_master` (Client-Side User Root Key):**
   - 32-byte root derived strictly on the client from a 12- or 24-word BIP-39 mnemonic.
   - Server never sees, stores, or derives `K_master`.
   - Stored in Android Keystore (backed by TEE / StrongBox).

### Bearer Token Wire Format
The bearer token is opaque to the client and Base64URL-encoded (unpadded) over a packed 72-byte binary struct:
- `session_id` (32 bytes): Secure random bytes.
- `expires_at` (8 bytes, Big-Endian $u64$): Unix timestamp in seconds.
- `blake3_mac` (32 bytes): `blake3::keyed_hash(K_server, &token_bytes[0..40])`.
- **Wire Size:** $72 \times 8 / 6 = 96$ ASCII characters.
- **Fast Reject:** Any bearer token where `len != 96` is dropped in $O(1)$ time.

---

## 4. Multi-App Architecture & Namespaced Ledgers

The user runs two distinct applications: **File Manager** and **Gallery**. Both apps run on the same device and belong to the same user account, but operate as independent Android APKs subject to Android's Linux UID sandbox.


```

```
   File Manager App                        Gallery App

```

(Sandbox UID: u0_a150)                 (Sandbox UID: u0_a151)
│                                       │
▼                                       ▼
[ Local Room DB: Files ]               [ Local Room DB: Media ]
│                                       │
▼                                       ▼
Sync Daemon (Files)                     Sync Daemon (Gallery)
│                                       │
┌─────────┴───────────────────────────────────────┴─────────┐
│                   Axum HTTP Transport                     │
│          Authorization: Bearer <96-char token>            │
└─────────────────────────┬─────────────────────────────────┘
│
▼
[ SQLite: ledger_entries ]
┌─────────────────────────────────────────────────────────┐
│ user_id │ namespace │ sequence_id │  encrypted_payload  │
├─────────┼───────────┼─────────────┼─────────────────────┤
│ 0x01a.. │ "files"   │ 1001        │ [Encrypted Tink...] │
│ 0x01a.. │ "gallery" │ 504         │ [Encrypted Tink...] │
└─────────────────────────────────────────────────────────┘

```

### Protocol Invariants
1. **No Shared Client State:** File Manager and Gallery do not share an SQLite database, nor do they communicate over Android IPC / ContentProviders.
2. **Namespaced Syncing:**
   - File Manager queries: `GET /api/v1/ledger/pull?namespace=files&since_seq=<seq>`.
   - Gallery queries: `GET /api/v1/ledger/pull?namespace=gallery&since_seq=<seq>`.
   - Neither application downloads, decrypts, or executes state transitions for the other domain.
3. **Payload Opacity:** The server stores the `encrypted_payload` as raw BLOBs. The server has no domain types, enums, or knowledge of "nodes", "folders", "albums", or "tags".

---

## 5. Pruning, Snapshots & High-Water Mark Engine

Because clients hold the encryption keys, the server cannot independently compact delta history. Compaction is coordinated via client-side snapshots and server-enforced High-Water Marks.

### Server-Side Schema Requirements

```sql
CREATE TABLE device_sync_watermarks (
    device_id BLOB NOT NULL,
    user_id BLOB NOT NULL,
    namespace TEXT NOT NULL,
    last_synced_seq INTEGER NOT NULL DEFAULT 0,
    last_seen_at INTEGER NOT NULL,
    is_revoked INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (device_id, user_id, namespace),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE ledger_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id BLOB NOT NULL,
    namespace TEXT NOT NULL,
    snapshot_seq INTEGER NOT NULL,
    blob_hash BLOB NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_snapshots_lookup 
ON ledger_snapshots(user_id, namespace, snapshot_seq DESC);

```

### Deterministic Pruning Routine

1. **Trigger:** The Android Sync Daemon tracks local delta sequences. When uncompacted delta count exceeds 1,000 events:
* Daemon dumps current materialized Room database to a serialized binary snapshot.
* Encrypts snapshot using Google Tink.
* Uploads snapshot to CAS (`POST /api/v1/cas/blobs`).
* Registers snapshot sequence: `POST /api/v1/ledger/snapshot` with `{ namespace, snapshot_seq, blob_hash }`.
* Calls `POST /api/v1/ledger/prune` with `{ namespace }`.


2. **Server Pruning Math:**
The server determines the safe truncation point:

$$S_{\text{safe}} = \min \left( \min_{d \in D_{\text{active}}} (\text{last\_synced\_seq}_d), \; \text{snapshot\_seq}_{\text{latest}} \right)$$



Where $D_{\text{active}}$ includes devices where `is_revoked = 0` and `last_seen_at > (now - 30 days)`.
3. **Truncation Execution:**
```sql
DELETE FROM ledger_entries
WHERE user_id = :user_id
  AND namespace = :namespace
  AND sequence_id <= :safe_seq;

```


4. **Stale Device Handling:** If a device remains offline > 30 days and requests a sequence older than the minimum available `sequence_id`, the server responds with `410 Gone`. The client wipes its local delta store and hydrates its database directly from `ledger_snapshots.latest`.

---

## 6. Content-Addressable Storage (CAS) & Encryption

### File Encryption: User-Scoped Convergent Encryption

To achieve cross-app and cross-device deduplication on the mechanical disk without opening the system to public cloud dictionary confirmation attacks:

1. **Derive Blob DEK ($K_{\text{blob}}$):**

$$K_{\text{blob}} = \text{BLAKE3-Keyed}(K_{\text{master}}, \text{file\_plaintext})$$


2. **Derive Deterministic Nonce:**

$$\text{Nonce} = \text{BLAKE3-Keyed}(K_{\text{blob}}, \text{file\_plaintext})[0..12]$$


3. **Encrypt Payload:**

$$\text{Ciphertext} = \text{AES-GCM-Encrypt}(K_{\text{blob}}, \text{Nonce}, \text{file\_plaintext})$$


4. **CAS Key:**

$$\text{CAS\_ID} = \text{BLAKE3}(\text{Ciphertext})$$



* **Security Properties:**
* Identical files uploaded by the same user produce identical ciphertexts across all user devices.
* An attacker without $K_{\text{master}}$ cannot generate $K_{\text{blob}}$, defeating cross-user dictionary confirmation attacks.
* Envelope sharing remains zero-copy: Sharing a file with Bob requires only encrypting the 32-byte $K_{\text{blob}}$ and 12-byte Nonce with Bob's public key. The server stores zero duplicated file bytes.



### Zero-Allocation Coding Rules for Rust Server

* Sad paths facing the public internet must return static string slices (`&'static str`) or zero-allocation error enums to eliminate memory allocator churn under volumetric denial-of-service.
* Dynamic string formatting (`format!`, `String::from`) is forbidden on unauthenticated paths before rate limiters and cryptographic filters pass.
* Streaming hashers (`blake3::Hasher`, `sha2::Sha256`) must ingest raw memory buffers (`&[u8]`, IP octets) without converting primitives to intermediate strings.

```

```
