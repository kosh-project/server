# Kosh Android Client — Contributor and Architecture Guide

Welcome to the Kosh Android client repository. This document serves as the primary technical onboarding guide and architectural reference for contributors. It covers our system philosophy, module layout, cryptographic mechanics, wire protocols, testing workflows, and engineering standards.

---

## 1. System Philosophy: "The Brain" vs. "The Dumb Bucket"

Kosh is an offline-first, zero-knowledge personal cloud storage and digital memory platform. It is designed to replace proprietary cloud storage services while ensuring absolute user privacy and data sovereignty.

To achieve this, the architecture enforces a strict division of responsibility between the Android mobile client and the backend server:

| Dimension | Android Client ("The Brain") | Rust/Axum Backend ("The Dumb Bucket") |
|---|---|---|
| Runtime Environment | Android Edge Runtime (Kotlin 2.4.0, Java 17 toolchain, API 26+) | Headless Linux, Axum 0.8, Tokio async runtime |
| Target Hardware | Modern ARM SoCs (Google Tensor, Qualcomm Snapdragon) | 2nd-generation Intel Core i5 (Sandy Bridge), 10 GB DDR3 RAM, mechanical HDD |
| Trust Boundary | Fully trusted edge; holds private user credentials and master encryption keys | Zero Hardware Trust; treated as an untrusted, potentially compromised remote store |
| Storage Semantics | Relational metadata index (Room), Delta-CRDT action log, Lamport clocks | Content-Addressable Storage (CAS) keyed by BLAKE3 hex hash, append-only delta files |
| Data Visibility | Plaintext files, EXIF metadata, and directory trees exist in memory only | Opaque ciphertext blobs and encrypted action frames |
| Cryptographic Role | Argon2id KDF, Hashcash Proof-of-Work solver, AES-256-GCM session store, Tink `StreamingAead` | Stateless BLAKE3 MAC verification (`mac_guard`), Hashcash verification (`pow_guard`), session token issuance |

### Physical Hardware Realities and I/O Mechanics
The backend host operates on spinning mechanical hard drives. Random disk seeking is an immediate bottleneck that severely impacts throughput:
- **Mandatory `Content-Length`:** The server uses `fallocate(2)` via Tokio to pre-allocate contiguous disk blocks before streaming data to disk. OkHttp requests must declare an exact `Content-Length`. Any request using chunked transfer encoding (`Transfer-Encoding: chunked`) is immediately rejected with HTTP 400 (`BadRequest("Missing content length in header")`).
- **Strict Ingress Funnel and Rate Limiting:** To protect the host CPU and prevent disk thrashing, the server applies a multi-tiered ingress pipeline:
  1. **Global IP Governor:** 25 requests/second per IP, with a burst allowance of 10.
  2. **Auth IP Governor:** 2 requests/second per IP on `/api/auth/*`, with a burst allowance of 2.
  3. **Stateless BLAKE3 MAC Filter (`mac_guard`):** Verifies the 118-byte bearer token in RAM in under 1 microsecond before querying the database.
  4. **Device Governor:** 15 requests/second per authenticated token hash, with a burst allowance of 5.
  5. **Session Resolution (`auth_guard`):** Queries an in-memory cache (10-minute time-to-idle) before hitting SQLite.

### Core System Invariants
1. **Zero-Knowledge Invariant:** The client must never send plaintext file names, folder paths, EXIF metadata, or unencrypted data to the server. The `X-File-Name` header on binary uploads must be an opaque synthetic identifier (such as a UUID with `.enc`).
2. **Zero-Copy Streaming Invariant:** Never buffer entire files into memory on Android. Payloads must stream in 64 KB chunk buffers using OkHttp `StreamingUriRequestBody` and Google Tink `StreamingAead`.
3. **Offline-First Invariant:** All UI interactions mutate local persistence immediately. Network synchronization occurs in the background via coroutines and WorkManager.
4. **Trust-On-First-Use (TOFU) Transport:** All network traffic terminates on TLS. Certificates are self-signed and pinned via SHA-256 fingerprints acquired during terminal QR pairing.

---

## 2. High-Level Architecture and Data Flow

The client strictly adheres to Unidirectional Data Flow (UDF):

```text
[ Jetpack Compose UI ]
        |
        | User actions (clicks, navigation, file pick)
        v
[ ViewModel Layer (Kotlin Coroutines) ]
        |
        | Exposes StateFlow<UiState>
        v
[ Repository Layer (e.g. AuthRepository) ]
        |
        +---> [ Crypto Engine (AndroidKeyStore, HashcashSolver, IdentityManager) ]
        |
        +---> [ Local Persistence (Room Database - Planned SSOT) ]
        |
        v
[ Network Layer (OkHttp 5.2, AuthClient, AssetClient) ]
        |
        v HTTPS / Port 6969
[ Kosh Axum Backend ]
```

### Threading Boundaries and Main Looper Protection
- **`Dispatchers.Main`:** Reserved exclusively for lightweight UI event emission and state rendering.
- **`Dispatchers.Default`:** Reserved for CPU-intensive cryptographic operations:
  - Argon2id key derivation (`IdentityManager.deriveCredentials`)
  - Proof-of-Work puzzle solving (`HashcashSolver.solve`)
  - Local BLAKE3 hash computation
- **`Dispatchers.IO`:** Reserved for blocking I/O:
  - OkHttp network requests (`AuthClient`, `AssetClient`)
  - Room database transactions and queries
  - File and stream operations via `ContentResolver`

---

## 3. Module Breakdown and Responsibilities

The project is structured into seven Gradle modules:

```text
kosh-client/
├── app-gallery/          # Application shell, navigation router, and Hilt root
├── core/
│   ├── model/           # Pure Kotlin JVM wire models and error taxonomy
│   ├── crypto/          # Argon2id key derivation and Hashcash PoW solver
│   ├── network/         # OkHttp network clients, interceptors, and streaming request body
│   └── auth/            # Keystore-backed session persistence and AuthRepository
├── feature/
│   ├── auth/            # Compose login/register screens and AuthViewModel
│   └── gallery/         # Compose gallery prototype and GalleryViewModel
└── .agents/             # System specifications, architecture blueprints, and agent directives
```

### 3.1 `:core:model`
- **Type:** Pure Kotlin JVM library (`jvmToolchain(17)`). Completely free of Android SDK dependencies.
- **Responsibilities:**
  - Wire data transfer objects (DTOs) annotated with `@Serializable`.
  - Content-Addressable Storage enums and serializers (`AssetTag`, `AssetTagSerializer`).
  - Hierarchical error taxonomy (`NetworkResult`).
- **Key Types:**
  - `AssetTag`: Enum mapping storage categories: `GALLERY_META(0)`, `GALLERY_ITEM(1)`, `DRIVE_META(2)`, `DRIVE_ITEM(3)`.
  - `AssetTagSerializer`: Serializer encoding enums as integers `0..3` matching Rust `#[repr(i32)]`.
  - `AuthRequest`: Wire payload sending `{"auth_verifier": "..."}`.
  - `ChallengeResponse`: Wire payload receiving `{"challenge": "..."}`.
  - `UploadResponse`: Untagged envelope receiving `file_name`, nullable `hash`, and nullable `error`, with an `isSuccess` computed property.
  - `NetworkResult<out T>`: Sealed algebraic data type for network success and classified failures.

### 3.2 `:core:crypto`
- **Type:** Android Library (`minSdk 26`, `compileSdk 37`).
- **Dependencies:** `:core:model`, `argon2kt`, Dagger Hilt.
- **Responsibilities:**
  - User identity hashing and client-side password stretching.
  - Proof-of-Work challenge solver for server rate-limiting defenses.
- **Key Classes:**
  - `IdentityManager`:
    - Computes `identity_hash` via SHA-256 over username bytes (64 lowercase hex characters).
    - Computes `auth_verifier` using `Argon2Kt` in `ARGON2_ID` mode ($m = 65536 \text{ KiB}$, $t = 3 \text{ iterations}$, $p = 1$, 32-byte output length).
  - `HashcashSolver`:
    - Zero-allocation Proof-of-Work solver for the 16-bit leading zero SHA-256 target.
    - Operates on `Dispatchers.Default` using pre-allocated byte buffers (165 or 168 bytes).
    - Uses bit-shifts for in-place ASCII hex encoding without intermediate string allocations.
    - Yields cooperatively via `coroutineContext.ensureActive()` every 1024 iterations.

### 3.3 `:core:network`
- **Type:** Android Library.
- **Dependencies:** `:core:model`, OkHttp 5.2, OkHttp Logging Interceptor, Dagger Hilt.
- **Responsibilities:**
  - HTTP transport configuration and dependency injection.
  - Bearer token injection via OkHttp interceptors.
  - Low-level API clients (`AuthClient`, `AssetClient`).
  - Zero-copy streaming from Android `ContentResolver`.
- **Key Classes:**
  - `NetworkModule`:
    - Provides `@PublicOkHttpClient` (unauthenticated client for `/api/auth/*`). Configured with `HttpLoggingInterceptor.Level.HEADERS` to prevent heap exhaustion.
    - Provides `@AuthOkHttpClient` (authenticated client attaching `AuthInterceptor`).
  - `AuthInterceptor`: Reads current token from `TokenProvider` and injects `Authorization: Bearer <token>`.
  - `AuthClient`: Coroutine-based client executing `fetchChallenge`, `register`, and `login` requests.
  - `AssetClient`: Client for binary uploads (`POST /api/v1/upload/{tag}`) and downloads (`GET /api/v1/assets/{hash}`).
  - `StreamingUriRequestBody`: Streams bytes from a content URI in 64 KB buffers with exact `Content-Length`.

### 3.4 `:core:auth`
- **Type:** Android Library.
- **Dependencies:** `:core:model`, `:core:network`, `:core:crypto`, `androidx.security.crypto`, Dagger Hilt.
- **Responsibilities:**
  - Secure hardware-backed token storage and lifecycle.
  - Authentication domain orchestration.
- **Key Classes:**
  - `SessionManager`:
    - Implements `TokenProvider`.
    - Generates and stores a 256-bit AES master key in `AndroidKeyStore`.
    - Encrypts the 118-byte bearer token using AES-256-GCM with dynamic initialization vectors.
    - Exposes `saveToken()`, `getToken()`, and `clearToken()`.
  - `AuthRepository`:
    - Coordinates challenge acquisition, PoW solving, and login/register network calls on `Dispatchers.IO`.
    - Persists session tokens upon successful authentication.

### 3.5 `:feature:auth`
- **Type:** Android Library with Jetpack Compose.
- **Dependencies:** `:core:auth`, `:core:crypto`, `:core:model`, Material 3, Dagger Hilt.
- **Responsibilities:**
  - User authentication UI and state management.
- **Key Classes:**
  - `AuthUiState`: Sealed state model (`Idle`, `Loading`, `Success`, `Error`).
  - `AuthViewModel`: Manages authentication state. Ensures Argon2id derivation executes off the Main Looper thread via `defaultDispatcher`.
  - `AuthScreen`: Compose screen for username/passphrase input and status messaging.

### 3.6 `:feature:gallery`
- **Type:** Android Library with Jetpack Compose.
- **Dependencies:** `:core:network`, `:core:model`, Material 3, Dagger Hilt.
- **Responsibilities:**
  - Photo picker and asset upload interface.
- **Key Classes:**
  - `GalleryViewModel`: Manages photo selection and dispatches upload calls.
  - `GalleryScreen`: Compose screen with photo picker contract and upload progress indicator.
  - `FileHelper`: Utility for querying URI display names and reading input streams.

### 3.7 `:app-gallery`
- **Type:** Android Application (`com.android.application`).
- **Responsibilities:**
  - Application entry point and Hilt dependency injection root.
  - Navigation routing between features.
- **Key Classes:**
  - `KoshApplication`: Application subclass annotated with `@HiltAndroidApp`.
  - `MainActivity`: Single activity hosting Compose navigation.
  - `AppRouter`: Compose `NavHost` directing between authentication and gallery screens.

---

## 4. Cryptographic Mechanics and Wire Protocols

### 4.1 Argon2id Key Derivation
1. `identity_hash`: Hex SHA-256 of the username string. Formatted as 64 lowercase hex characters.
2. `auth_verifier`: Computed using `Argon2Kt` in `ARGON2_ID` mode with parameters $m = 65536 \text{ KiB}$, $t = 3$, $p = 1$, and output length 32 bytes.
3. The server stores and verifies `auth_verifier` verbatim without re-hashing, keeping server CPU usage minimal.

### 4.2 Stateless Hashcash Proof-of-Work Challenge Cycle

```text
[ Mobile Client ]                                                        [ Rust Server ]
        |                                                                        |
        | 1. GET /api/auth/challenge?action=login                                |
        +----------------------------------------------------------------------->| (Computes BLAKE3 HMAC over
        |                                                                        |  timestamp_hex + IP + action)
        | 2. 200 OK { challenge: "000000006745...login" }                        |
        |<-----------------------------------------------------------------------+
        |
   [ HashcashSolver: loops nonces until SHA-256(header) has 16 zero bits ]
        |
        | 3. POST /api/auth/login                                                |
        |    Header: X-Hashcash: <165-byte string>                               |
        |    Body:   { "auth_verifier": "..." }                                  |
        +----------------------------------------------------------------------->|
                                                                                 | (Fast RAM verification <2µs:
                                                                                 |  checks length, 16 zero bits,
                                                                                 |  now - timestamp <= 15s,
                                                                                 |  recomputes BLAKE3 MAC)
                                                                                 |
                                                                                 | (Verifies credentials in DB)
        | 4. 200 OK { token: "uuid.expires.mac" }                                |
        |<-----------------------------------------------------------------------+
```

#### Challenge Format (`GET /api/auth/challenge?action=<login|register>`)
- Response: `{"challenge": "<timestamp_hex><mac_hex><action>"}`
- Layout: 16 hex characters timestamp + 64 hex characters BLAKE3 MAC + 5 or 8 characters action.
- Total length: 85 ASCII characters for login, 88 ASCII characters for register.
- Validity window: Exactly 15 seconds. Requests submitted after 15 seconds receive HTTP 401 (`Challenge expired`).

#### `X-Hashcash` Header Format
Header payload sent in `X-Hashcash`:

| Offset Range | Length | Field Name | Description |
|---|---|---|---|
| `0 .. 64` | 64 chars | `identity_hash` | Hex SHA-256 of the username |
| `64 .. 80` | 16 chars | `nonce` | 64-bit unsigned integer formatted as 16 lowercase hex characters |
| `80 .. 96` | 16 chars | `timestamp_hex` | Hex Unix timestamp received from the challenge |
| `96 .. 160` | 64 chars | `mac_hex` | BLAKE3 MAC received from the challenge |
| `160 ..` | 5 or 8 chars | `action` | `"login"` (5 chars) or `"register"` (8 chars) |

Total header length: 165 bytes for login, 168 bytes for register. The target condition is:
`digest = SHA-256(header_bytes)` where `digest[0] == 0x00 && digest[1] == 0x00` (16 leading zero bits, average ~65,536 iterations).

### 4.3 118-Byte Bearer Token Architecture
Authentication tokens issued by the server are structured 118-byte strings:
$$\text{session\_id}(36\text{ chars UUID v4}) \,.\, \text{expires\_at\_hex}(16\text{ chars}) \,.\, \text{blake3\_mac}(64\text{ chars})$$

- **Stateless Verification (`mac_guard`):** The server verifies `expires_at > now` and checks `blake3::keyed_hash(K_server, payload) == blake3_mac` in memory in under 1 microsecond before querying SQLite.
- **Client Storage:** Persisted in `SharedPreferences` encrypted with AES-256-GCM via `AndroidKeyStore`.
- **Session Revocation:** On HTTP 401, `SessionManager.clearToken()` wipes stored credentials to prevent repeated 401 loops.

### 4.4 Delta-CRDT Sync Ledger Framing
- **Segment Files:** Stored under `vault/ledgers/<user_id>/delta_000000X`.
- **500-Byte Header:** Every segment begins with an immutable 500-byte pre-allocated header (`"KOSH"` [4 bytes] + version [2 bytes] + `prev_id` [4 bytes] + 490 zero bytes). Offsets below 500 are automatically clamped to 500.
- **4-Byte Little-Endian Framing:** `POST /api/v1/sync/delta` prepends `[u32 LE length][payload bytes]`.
- **Cursor Checkpoint:** Endpoint returns `AppendResponse { file_name, offset }`. The client persists `(file_name, offset)` in local Room storage as its sync cursor.
- **Segment Rotation:** Rotates when segment size reaches 5 MB (5,000,000 bytes).
- **Compaction & Pruning:** `DELETE /api/v1/sync/prune?before=X` removes segments `< X` after local snapshot creation. The server strictly forbids pruning the active segment.

---

## 5. Hierarchical Error Taxonomy (`NetworkResult`)

Network and protocol errors are modeled as a typed sealed algebraic data type in `NetworkResult.kt`:

```text
NetworkResult<out T>
├── Success<T>(val data: T)
└── Failure (sealed interface : NetworkResult<Nothing>)
    ├── Connectivity (sealed interface)
    │   ├── NetworkUnavailable(userMessage, cause)
    │   ├── HostUnreachable(host, userMessage, cause)
    │   ├── ConnectionRefused(port, userMessage, cause)
    │   └── ConnectionTimeout(userMessage, cause)
    ├── Socket (sealed interface)
    │   ├── ReadTimeout(userMessage, cause)
    │   ├── WriteTimeout(userMessage, cause)
    │   └── ConnectionReset(userMessage, cause)
    ├── Security (sealed interface)
    │   └── TlsFailed(reason, userMessage, cause)
    ├── Protocol (sealed interface)
    │   └── Serialization(details, userMessage, cause)
    ├── Http (sealed interface)
    │   ├── Unauthorized(serverMessage, isChallengeExpired)
    │   ├── Conflict(serverMessage)
    │   ├── NotFound(resource, serverMessage)
    │   ├── PayloadTooLarge(serverMessage)
    │   ├── RateLimited(retryAfterSeconds, serverMessage)
    │   ├── ClientError(code, serverMessage)
    │   └── ServerError(code, serverMessage)
    └── Unknown(userMessage, cause)
```

### Factory Methods
- `NetworkResult.fromThrowable(t: Throwable): Failure`: Automatically maps Java network exceptions (`UnknownHostException`, `NoRouteToHostException`, `ConnectException`, `SocketTimeoutException`, `SSLException`, `SocketException`, `SerializationException`) into typed failure subtrees with meaningful messages.
- `NetworkResult.fromHttp(code: Int, body: String): Http`: Maps HTTP response codes to classified HTTP error models.

---

## 6. Development Workflow and Testing

### Prerequisites
- **JDK:** OpenJDK 17 or higher. The repository uses Gradle toolchains to resolve Java 17 automatically.
- **Android SDK:** Compile SDK 37, Min SDK 26, Target SDK 37. Android SDK path must be configured in `local.properties` (e.g. `sdk.dir=/home/<user>/Android/Sdk`).
- **Rust Toolchain (Optional, for running backend):** `rustc` and `cargo` (edition 2024 / 1.85+) to run `/home/ton3s/rsProjects/webdav-server`.

### Build Commands
Execute these commands from the root of the repository:

```bash
# Build the application debug APK
./gradlew assembleDebug

# Run all host JVM unit tests across all modules
./gradlew test

# Run unit tests for a specific module
./gradlew :core:crypto:test
./gradlew :feature:auth:test

# Run unit tests with forced rerun
./gradlew testDebugUnitTest --rerun-tasks

# Run Android instrumented tests (requires connected device or AVD emulator)
./gradlew connectedAndroidTest

# Run Android Lint analysis
./gradlew lintDebug
```

### Testing Against the Rust Backend Locally
To test end-to-end authentication and asset streaming against a live server:

1. **Start the Rust Backend:**
   ```bash
   cd /home/ton3s/rsProjects/webdav-server
   cargo run -p webdav-server
   ```
   The backend will listen on port `6969` (HTTPS).

2. **Launch the Ratatui Admin CLI:**
   ```bash
   cd /home/ton3s/rsProjects/webdav-server
   cargo run -p cli
   ```
   Press `p` to open the Device Pairing modal. The terminal will display:
   - Server LAN IP and port
   - TOFU Pairing QR code (encoding raw 32-byte SHA-256 certificate fingerprint)
   - 12 BIP-39 SAS verification words

3. **Android Studio Emulator (AVD) Configuration:**
   - In the Android emulator, the development host is mapped to `10.0.2.2:6969`.
   - Update client base URLs to target `https://10.0.2.2:6969/api` (or `http://10.0.2.2:6969/api` during Phase 0 testing prior to TLS pinner integration).

---

## 7. Engineering Standards and Code Quality

1. **Unidirectional Data Flow (UDF):** Compose UI screens must only observe reactive `StateFlow` streams exposed by ViewModels and emit user events. UI code must never make direct repository or network calls.
2. **Thread Safety:** Heavy CPU operations (Argon2id hashing, Hashcash solving, image transformations) must run on `Dispatchers.Default`. Disk I/O, Room database operations, and OkHttp network calls must run on `Dispatchers.IO`. The Main thread Looper must never be blocked.
3. **Zero-Copy Streaming:** When handling binary payloads, always stream in 64 KB buffers using `InputStream.copyTo(outputStream, bufferSize = 65536)`. Never read full files into `ByteArray` heap buffers.
4. **Network Logging:** Use `HttpLoggingInterceptor.Level.HEADERS` or `BASIC`. Never use `Level.BODY` on binary clients.
5. **Agent Operating Contract (`.agents/AGENTS.md`):** AI agents have read-only access to application source code (`*.kt`, `*.xml`, `*.gradle.kts`). All modifications to code must be performed by the developer. AI agents are permitted to write only to `.agents/*` (specifically `.agents/*.md`).
6. **Documentation and Tone:** Maintain a professional, human, clear, and friendly tone. Avoid emojis in codebase comments, commit messages, and documentation.
