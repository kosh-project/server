# Architectural & Implementation Plan: Ephemeral ECDH Blind Mailbox Relay

## Goal Description

Implement the **Ephemeral ECDH Blind Mailbox Relay** subsystem for Kosh on a dedicated branch (`feat/ecdh-mailbox`).

### The Problem It Solves
In Kosh's zero-knowledge architecture, Root Envelope Encryption protects the true master vault encryption key ($K_{\text{vault}}$) inside a 60-byte encrypted envelope (`wrapped_vault_key`). When a user adds a secondary device (e.g., laptop or tablet) using a 1-touch WebAuthn Passkey:
1. The secondary device authenticates against the server and receives an active Bearer session token plus `wrapped_vault_key`.
2. **The Catch:** `wrapped_vault_key` is encrypted under $K_{\text{recovery}}$ (the 24-word recovery phrase) and is **only unwrapped during catastrophic disaster recovery**. The secondary device possesses neither $K_{\text{recovery}}$ nor the active $K_{\text{vault}}$.
3. Forcing the user to manually enter their 24-word recovery phrase on every new device is hostile UX, error-prone, and exposes mnemonic phrases to physical shoulder-surfing and software keyloggers.

### The Solution: Ephemeral ECDH Blind Mailbox Relay
The new device (receiver) and the existing device (sender) perform a zero-knowledge, cross-device key exchange:
1. **Receiver (New Device):** Generates an ephemeral X25519 keypair and calls authenticated `POST /api/v1/devices/mailbox`. The server allocates a short-lived in-memory mailbox in RAM and returns an ephemeral 8-character Base32 `mailbox_id`.
2. **QR Code Transfer:** Receiver renders a QR code containing `mailbox_id` and its ephemeral X25519 public key.
3. **Sender (Existing Device):** User scans the QR code with their existing device (which already holds $K_{\text{vault}}$ in its hardware Keystore). The sender derives an ephemeral shared secret via X25519, encrypts $K_{\text{vault}}$ directly using ChaCha20-Poly1305 / AES-GCM, and deposits the transit ciphertext into the server via `POST /api/v1/devices/mailbox/{id}/fulfill`.
4. **Pickup & Burn:** The receiver polls `GET /api/v1/devices/mailbox/{id}`. The server delivers the encrypted transit payload and **immediately purges the mailbox from RAM (burn-after-reading)**. The receiver decrypts $K_{\text{vault}}$ directly using its ephemeral private key, stores $K_{\text{vault}}$ securely in its local OS hardware Keystore, and begins syncing.

---

## User Review & Architecture Decisions

> [!IMPORTANT]
> **Decisions Finalized from Review:**
> 1. **Mailbox Identifier Format:** 8-character lowercase Crockford's Base32 string (e.g., `k7x9m2q4`), generated from 40 bits (5 bytes) of cryptographically secure randomness via `rand::rngs::OsRng` / `rand::thread_rng()`. Crockford Base32 avoids visually ambiguous characters (`i`, `l`, `o`, `u`), ensuring optimal QR code density and effortless manual typing fallback.
> 2. **Polling Semantics & Tagged Enum:** `GET /api/v1/devices/mailbox/{id}` returns `HTTP 200 OK` with an internally tagged enum:
>    ```rust
>    #[derive(Serialize)]
>    #[serde(tag = "status", rename_all = "lowercase")]
>    pub enum PickupResponse {
>        Pending,
>        Fulfilled { payload: String },
>    }
>    ```
>    This prevents treating pending states as HTTP errors and deserializes cleanly into typed sealed classes on mobile/desktop clients.

> [!IMPORTANT]
> **5 Critical Architectural & Security Refinements Applied:**
> 1. **Atomic In-Place State Transitions & TTL Preservation:**
>    To prevent TOCTOU race conditions and avoid Moka's `cache.insert()` resetting the 5-minute TTL back to 300 seconds, `MailboxEntry` uses an in-place mutex: `Arc<std::sync::Mutex<MailboxStatus>>` with states `Pending`, `Fulfilled(Vec<u8>)`, and `Consumed`.
>    - `fulfill`: Locks the mutex, asserts state is `Pending` (rejecting already fulfilled/consumed entries with `BadRequest`), and mutates to `Fulfilled(payload)` in-place without re-inserting into Moka.
>    - `pickup`: Locks the mutex, moves out the payload using `std::mem::replace(&mut *guard, MailboxStatus::Consumed)` with **zero heap cloning**, drops the lock, and calls `cache.remove(id).await`.
> 2. **Anti-Enumeration Oracle Protection:**
>    If a caller attempts to fulfill or pickup a mailbox belonging to another user (`entry.user_id != user_id`), the server returns `HTTP 404 Not Found` (`Error::NotFound("Mailbox not found or expired")`), **never `401 Unauthorized`**. This prevents timing/status oracles that could let attackers detect active mailboxes of other users and prevents triggering global 401 token-expiry interceptors on the client.
> 3. **Payload Bounds Enforcement:**
>    `fulfill_mailbox` strictly validates `120 <= request.payload.len() <= 8192` (60 to 4096 raw bytes), rejecting empty strings and oversized payloads with `BadRequest`.
> 4. **Corrected Cryptographic Semantics:**
>    Documentation and comments explicitly reflect that $K_{\text{vault}}$ is transmitted directly across the ECDH channel; `wrapped_vault_key` is not unwrapped by $K_{\text{vault}}$.
> 5. **Collision-Resistant CSPRNG Key Generation:**
>    Mailbox ID generation loops against `cache.contains_key()` with 5 random bytes to guarantee zero ID collisions.

---

## Architecture & Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Recv as New Device (Receiver)
    participant API as Kosh Server
    participant Cache as Moka RAM Cache
    actor Send as Old Device (Sender)

    Note over Recv,API: Step 1: Open Mailbox
    Recv->>API: POST /api/v1/devices/mailbox (Bearer Token)
    API->>Cache: Insert pending MailboxEntry (TTL: 5m, user_id, Mutex(Pending))
    API-->>Recv: 201 Created { mailbox_id: "k7x9m2q4", expires_in: 300 }

    Note over Recv,Send: Step 2: Out-of-Band QR Code
    Recv->>Recv: Render QR: { mailbox_id: "k7x9m2q4", receiver_pubkey }
    Send->>Recv: Camera scans QR Code

    Note over Send,API: Step 3: Fulfill Mailbox
    Send->>Send: Derive ECDH secret & encrypt K_vault directly
    Send->>API: POST /api/v1/devices/mailbox/k7x9m2q4/fulfill (Bearer Token, 120-8192 hex chars)
    API->>Cache: Verify user_id match & atomically mutate Mutex(Pending -> Fulfilled)
    API-->>Send: 204 No Content

    Note over Recv,API: Step 4: Pickup & Burn
    loop Polling (every 1-2s)
        Recv->>API: GET /api/v1/devices/mailbox/k7x9m2q4 (Bearer Token)
        alt Still Pending
            API-->>Recv: 200 OK { "status": "pending" }
        else Fulfilled
            API->>Cache: Atomically swap Mutex(Fulfilled -> Consumed) & remove from Moka
            API-->>Recv: 200 OK { "status": "fulfilled", "payload": "<hex>" }
        end
    end

    Note over Recv: Step 5: Decrypt & Sync
    Recv->>Recv: Decrypt K_vault with ephemeral private key, save to Keystore, start syncing
```

---

## Proposed Changes

### 1. Application Layer (`crates/server/src/app`)

#### [NEW] `crates/server/src/app/mailbox.rs`
Create the dedicated `Mailbox` cache manager:
```rust
use std::sync::{Arc, Mutex};
use std::time::Duration;
use moka::future::Cache;
use rand::RngCore;

use crate::{
    api::{
        self,
        Error::{BadRequest, NotFound},
    },
    app::state::UserId,
};

/// Alphabet for lowercase Crockford's Base32 encoding (excludes i, l, o, u).
const CROCKFORD_BASE32_ALPHABET: &[u8; 32] = b"0123456789abcdefghjkmnpqrstvwxyz";

/// In-memory state of an active blind mailbox.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MailboxStatus {
    /// Mailbox created by receiver, awaiting sender fulfillment.
    Pending,
    /// Sender has deposited the encrypted transit payload.
    Fulfilled(Vec<u8>),
    /// Payload has been retrieved by receiver and mailbox is consumed.
    Consumed,
}

/// An entry stored in the in-memory mailbox cache.
#[derive(Clone)]
pub struct MailboxEntry {
    /// Owner user ID required to match for all operations.
    pub user_id: UserId,
    /// Thread-safe in-place state container.
    pub status: Arc<Mutex<MailboxStatus>>,
}

/// Thread-safe in-memory cache manager for ephemeral cross-device key transfer mailboxes.
#[derive(Clone)]
pub struct Mailbox {
    cache: Cache<String, MailboxEntry>,
}

impl Default for Mailbox {
    fn default() -> Self {
        Self::new()
    }
}

impl Mailbox {
    /// Creates a new `Mailbox` cache with a 5-minute TTL and 1,000-entry capacity.
    #[must_use]
    pub fn new() -> Self {
        let cache = Cache::builder()
            .time_to_live(Duration::from_secs(300))
            .max_capacity(1_000)
            .build();

        Self { cache }
    }

    /// Generates an 8-character lowercase Crockford's Base32 ID from 40 bits of CSPRNG.
    fn generate_id() -> String {
        let mut bytes = [0u8; 5];
        rand::rngs::OsRng.fill_bytes(&mut bytes);

        let n = u64::from_be_bytes([0, 0, 0, bytes[0], bytes[1], bytes[2], bytes[3], bytes[4]]);
        let mut id = String::with_capacity(8);
        for i in (0..8).rev() {
            let index = usize::try_from((n >> (i * 5)) & 0x1f).unwrap_or(0);
            if let Some(&ch) = CROCKFORD_BASE32_ALPHABET.get(index) {
                id.push(ch as char);
            }
        }
        id
    }

    /// Allocates an ephemeral mailbox bound to `user_id`.
    pub async fn create(&self, user_id: UserId) -> String {
        loop {
            let id = Self::generate_id();
            if !self.cache.contains_key(&id) {
                let entry = MailboxEntry {
                    user_id,
                    status: Arc::new(Mutex::new(MailboxStatus::Pending)),
                };
                self.cache.insert(id.clone(), entry).await;
                return id;
            }
        }
    }

    /// Deposits the encrypted transit payload into the mailbox.
    ///
    /// # Errors
    /// - Returns [`NotFound`] if the mailbox does not exist, has expired, or belongs to another user.
    /// - Returns [`BadRequest`] if the mailbox has already been fulfilled or consumed.
    pub async fn fulfill(
        &self,
        id: &str,
        user_id: UserId,
        payload: Vec<u8>,
    ) -> api::Result<()> {
        let entry = self
            .cache
            .get(id)
            .await
            .ok_or(NotFound("Mailbox not found or expired"))?;

        if entry.user_id != user_id {
            return Err(NotFound("Mailbox not found or expired"));
        }

        let mut guard = entry
            .status
            .lock()
            .map_err(|_| api::Error::Internal(crate::error::internal::Error::Message("Mailbox mutex poisoned")))?;

        match *guard {
            MailboxStatus::Pending => {
                *guard = MailboxStatus::Fulfilled(payload);
                Ok(())
            }
            MailboxStatus::Fulfilled(_) | MailboxStatus::Consumed => {
                Err(BadRequest("Mailbox already fulfilled"))
            }
        }
    }

    /// Retrieves the transit payload. If fulfilled, burns the payload from cache atomically.
    ///
    /// # Errors
    /// - Returns [`NotFound`] if the mailbox does not exist, has expired, belongs to another user,
    ///   or has already been consumed.
    pub async fn pickup(
        &self,
        id: &str,
        user_id: UserId,
    ) -> api::Result<Option<Vec<u8>>> {
        let entry = self
            .cache
            .get(id)
            .await
            .ok_or(NotFound("Mailbox not found or expired"))?;

        if entry.user_id != user_id {
            return Err(NotFound("Mailbox not found or expired"));
        }

        let mut guard = entry
            .status
            .lock()
            .map_err(|_| api::Error::Internal(crate::error::internal::Error::Message("Mailbox mutex poisoned")))?;

        match *guard {
            MailboxStatus::Pending => Ok(None),
            MailboxStatus::Consumed => Err(NotFound("Mailbox not found or expired")),
            MailboxStatus::Fulfilled(_) => {
                let old_state = std::mem::replace(&mut *guard, MailboxStatus::Consumed);
                drop(guard);
                self.cache.remove(id).await;

                if let MailboxStatus::Fulfilled(payload) = old_state {
                    Ok(Some(payload))
                } else {
                    Err(NotFound("Mailbox not found or expired"))
                }
            }
        }
    }
}
```

#### [MODIFY] `crates/server/src/app/state.rs`
- Add `pub mailbox: app::Mailbox` to `AppState`.

#### [MODIFY] `crates/server/src/app/builder.rs`
- Add `mailbox: Option<app::Mailbox>` to `AppStateBuilder`.
- Initialize with `mailbox: self.mailbox.unwrap_or_default()` in `build()`.

#### [MODIFY] `crates/server/src/app/mod.rs`
- Add `mod mailbox;` and `pub use mailbox::Mailbox;`.

---

### 2. API Layer (`crates/server/src/api`)

#### [NEW] `crates/server/src/api/devices/mod.rs`
Declare submodule and exports:
```rust
pub mod mailbox;
```

#### [NEW] `crates/server/src/api/devices/mailbox.rs`
Implement route handlers and typed DTOs:
```rust
use axum::{
    Extension, Json,
    extract::{Path, State},
};
use hyper::StatusCode;
use serde::{Deserialize, Serialize};

use crate::{
    Result,
    api::{
        Error::BadRequest,
        Result as ApiResult,
    },
    app,
    error::JsonResult,
};

/// Response payload returned by `POST /api/v1/devices/mailbox`.
#[derive(Debug, Serialize)]
pub struct CreateResponse {
    pub mailbox_id: String,
    pub expires_in: u64,
}

/// Request payload for `POST /api/v1/devices/mailbox/{id}/fulfill`.
#[derive(Debug, Deserialize)]
pub struct FulfillRequest {
    pub payload: String,
}

impl FulfillRequest {
    /// Validates hex encoding and byte length bounds (60 to 4096 bytes).
    pub fn parse_payload(&self) -> ApiResult<Vec<u8>> {
        if self.payload.len() < 120 || self.payload.len() > 8192 {
            return Err(BadRequest(
                "Payload must be between 120 and 8192 hex characters (60 to 4096 bytes)",
            ));
        }

        let bytes = hex::decode(&self.payload)
            .map_err(|_| BadRequest("Invalid hexadecimal payload"))?;

        Ok(bytes)
    }
}

/// Typed response enum for `GET /api/v1/devices/mailbox/{id}`.
#[derive(Debug, Serialize)]
#[serde(tag = "status", rename_all = "lowercase")]
pub enum PickupResponse {
    Pending,
    Fulfilled { payload: String },
}

pub async fn create_mailbox(
    State(state): State<app::State>,
    Extension(user_id): Extension<i64>,
) -> JsonResult<CreateResponse> {
    let mailbox_id = state.mailbox.create(user_id).await;

    Ok(Json(CreateResponse {
        mailbox_id,
        expires_in: 300,
    }))
}

pub async fn fulfill_mailbox(
    State(state): State<app::State>,
    Extension(user_id): Extension<i64>,
    Path(mailbox_id): Path<String>,
    Json(request): Json<FulfillRequest>,
) -> Result<StatusCode> {
    let raw_payload = request.parse_payload()?;
    state.mailbox.fulfill(&mailbox_id, user_id, raw_payload).await?;

    Ok(StatusCode::NO_CONTENT)
}

pub async fn pickup_mailbox(
    State(state): State<app::State>,
    Extension(user_id): Extension<i64>,
    Path(mailbox_id): Path<String>,
) -> JsonResult<PickupResponse> {
    match state.mailbox.pickup(&mailbox_id, user_id).await? {
        None => Ok(Json(PickupResponse::Pending)),
        Some(payload) => Ok(Json(PickupResponse::Fulfilled {
            payload: hex::encode(payload),
        })),
    }
}
```

#### [MODIFY] `crates/server/src/api/mod.rs`
- Add `pub mod devices;`.

#### [MODIFY] `crates/server/src/api/route.rs`
- Mount routes under `protected_routes`:
  ```rust
  .route("/devices/mailbox", post(devices::mailbox::create_mailbox))
  .route("/devices/mailbox/{id}/fulfill", post(devices::mailbox::fulfill_mailbox))
  .route("/devices/mailbox/{id}", get(devices::mailbox::pickup_mailbox))
  ```

---

## Verification Plan

### Automated Tests
1. **Unit Tests (`crates/server/src/app/mailbox/test.rs` & `crates/server/src/api/devices/test.rs`)**:
   - Mailbox ID generation: Crockford Base32 charset verification and length = 8.
   - Lifecycle: `create` -> `fulfill` -> `pickup` (returns `Some(payload)`).
   - Atomic Burn-After-Reading: second `pickup` call returns `NotFound`.
   - Cross-tenant anti-enumeration: User 2 fulfilling or picking up User 1's mailbox returns `NotFound` (`404`), never `Unauthorized` (`401`).
   - Double fulfillment: Calling `fulfill` on an already fulfilled mailbox returns `BadRequest`.
   - Bounds validation: Rejecting payloads $< 120$ hex chars (e.g. empty string) and $> 8192$ hex chars with `BadRequest`.
   - Concurrency race test: Spawning parallel `pickup` tasks asserts that exactly one task consumes the payload and all others receive `NotFound`.
2. **End-to-End Integration Tests (`crates/server/tests/mailbox.rs`)**:
   - `test_mailbox_full_lifecycle_e2e`: Complete receiver open -> polling (receives `"status": "pending"`) -> sender fulfillment -> receiver pickup (receives `"status": "fulfilled"` + payload) -> subsequent pickup returns 404.
   - `test_mailbox_cross_user_isolation_e2e`: Asserts `404 Not Found` when a separate authenticated user attempts to probe or fulfill the mailbox.
   - `test_mailbox_auth_guard_e2e`: Asserts `401 Unauthorized` when calling endpoints without a Bearer token.
3. **Workspace Checks**:
   - `cargo test --workspace`
   - `cargo clippy --workspace --all-targets -- -D warnings`
   - `RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps`
