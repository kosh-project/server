# SYSTEM ARCHITECTURE & DEVELOPMENT CONTEXT
**Project:** Zero-Knowledge Headless NAS
**Server Environment:** Arch Linux (Headless), Intel Core i5 Sandy Bridge, 10GB RAM.
**Server Stack:** Rust, Axum, Tokio, SQLite.
**Client Stack:** Native Android, Kotlin, Room DB, Google Tink (Hardware-Backed Keystore).

## 1. The Core Philosophy: "The Dumb Bucket"
The server operates strictly as a "dumb bucket of bits." It has absolutely zero knowledge of file contents, unencrypted metadata, or folder structures. Its sole purpose is to securely authenticate users and act as a high-speed traffic cop, streaming raw AES-GCM encrypted bytes directly from the network socket to the disk. 

## 2. Cryptography & Authentication (Dual-Auth System)
Authentication (server access) is strictly separated from Encryption (data access).

* **Master Encryption Key (Client-Side Only):** The 256-bit AES-GCM Master Key is derived using **Argon2id** and a 24-word BIP-39 recovery phrase. It never leaves the Android hardware keystore. The server cannot decrypt data under any circumstances.
* **Token/Username Hashing:** Handled via **Blake3** for extreme speed. *Note: Cross-language consistency is maintained by forcing Android Kotlin strings to UTF-8 (`toByteArray(Charsets.UTF_8)`) before hashing.*
* **Primary Authentication (Passkeys/WebAuthn):** Implemented to bypass the heavy CPU cost of Argon2id on the legacy Sandy Bridge hardware. 
    * **Client:** Uses Android's native `Credential Manager API`, allowing the user to select their preferred provider (e.g., Proton Pass, Local Device, YubiKey) via a custom "Pre-Flight" UI configuration (`authenticatorSelection`).
    * **Server:** Uses the `webauthn-rs` crate. In-flight cryptographic challenges are temporarily cached in memory using a fast `DashMap`. Upon successful ECDSA/Ed25519 signature verification, the passkey's Public Key is stored in SQLite.
* **Fallback Authentication (Passwords):** Traditional passwords remain an option if a passkey is lost. Passwords are intentionally hashed on the server using **Argon2id** (memory-hard KDF) to protect against GPU brute-forcing.

## 3. Client Strategy (Native vs. KMP)
The decision was made to strictly adhere to a **Native Client / Generic Server** architecture, rejecting Kotlin Multiplatform (KMP) and web wrappers. This avoids the "cross-platform bridging nightmare," allowing deep, unhindered access to OS-level hardware features (Android WorkManager for background syncs, Tink for hardware crypto, and native UI paradigms).

## 4. Metadata Syncing (Room DB & Protobuf)
To keep clients synchronized without risking "Last Write Wins" database corruption (which happens if swapping raw SQLite `.db` files), the system uses a **Delta Sync Strategy**:
1. **Export:** Android queries the Room DB for pending files, serializes the data into **Protocol Buffers (Protobuf)**, encrypts the byte array via Tink, and uploads it to the server.
2. **Merge:** Other clients download the encrypted manifest, decrypt it, deserialize the Protobuf, and feed the Kotlin objects into Room using `@Insert(onConflict = OnConflictStrategy.REPLACE)`.

## 5. Network Architecture (The Envelope vs. Letter Pattern)
The Axum server has been refactored to optimize Sandy Bridge CPU/RAM usage by abandoning the "Russian Doll Trap" (wrapping Base64 binary data inside JSON payloads).

* **The Data Plane (Heavy Uploads/Syncs):** Totally migrated away from `serde_json`. The server uses Axum's `Bytes` and `Multipart` extractors to grab raw network payloads (`application/octet-stream`) and stream them directly to disk. The server performs zero deserialization on file/manifest uploads.
* **The Control Plane (Auth/Challenges):** Lightweight JSON is retained exclusively for endpoints like WebAuthn challenges, where CPU cost is negligible.
* **Routing Metadata:** Because the upload body is pure encrypted binary, all metadata is shifted to the HTTP Request "Envelope":
    * **Authentication:** Handled exclusively via the `Authorization: Bearer <token>` header.
    * **Asset Types (Drive vs. Gallery vs. Manifest):** Handled entirely via RESTful URL path variables (e.g., `POST /api/vault/upload/gallery`).
* **Upload Progress:** Tracked 100% on the Android client using network interceptors; the Rust server does not waste cycles reporting progress.

Here is the ultimate, hyper-detailed "Master Context" file. It is specifically structured for an AI agent (like your `antigravity` CLI) to parse instantly. It synthesizes your hardware constraints, cryptographic paranoia, architectural epiphanies, and strict developer rules.

Copy everything below the horizontal rule and save it as `system_architecture_context.md`.

---

# SYSTEM ARCHITECTURE & MASTER CONTEXT: Zero-Knowledge Arch Linux NAS

## 1. PROJECT OVERVIEW & PHILOSOPHY

This project is an open-source, easily deployable zero-knowledge storage framework (NAS) intended for home-lab and self-hosting enthusiasts.

* **The "Dumb Bucket" Paradigm:** The server has zero visibility into file contents, unencrypted metadata, directory structures, or filenames. It acts purely as a high-speed traffic controller, routing and storing raw AES-GCM encrypted byte streams.
* **Target Hardware:** Legacy x86_64 desktop (Intel Core i5 2nd-Gen Sandy Bridge, ~3.1GHz, 10GB RAM, budget motherboard, HDD/SD Card storage).
* **Operating System:** Pure, headless Arch Linux (`linux-lts` kernel).
* **Developer Rule 1:** Strict prohibition on JavaScript/TypeScript web-ecosystem utilities or frameworks.
* **Developer Rule 2:** Stick to a **Native Client / Generic Server** model. Kotlin Multiplatform (KMP) is explicitly rejected because the architecture requires deep, bare-metal integration with native OS hardware keystores and background sync APIs.

## 2. SERVER STACK (RUST + AXUM + TOKIO)

The server is written in Rust, compiled locally with `RUSTFLAGS="-C target-cpu=native"` to leverage Sandy Bridge vector extensions (AVX) without relying on external repos that might trigger SIGILL.

* **Testing Architecture:** Integration tests use `reqwest` simulating Android clients. Network isolation is achieved by binding to `127.0.0.1:0` (ephemeral ports). To prevent filesystem pollution during tests, a temporary directory (`tempfile::TmpDir`) is dynamically injected into the router via Axum `State<AppState>`.
* **Concurrency Gotchas:** Axum server tasks must be spawned as "fire-and-forget" (`tokio::spawn(async move { axum::serve().await })`) to prevent async deadlocks during testing. Test parallelism collisions are handled via `--test-threads=1` or the `serial_test` crate.

## 3. CLIENT STACK (NATIVE ANDROID / KOTLIN)

* **Mobile UI Optimization:** To maintain 60/120 FPS in RecyclerView grids without decrypting massive 5GB video files, the app generates and encrypts secondary, tiny (~50KB) WebP/JPEG thumbnails during the ingestion phase.
* **Background Syncing:** Heavy networking pipelines are offloaded to Android's `WorkManager` API, ensuring uploads only occur under strict constraints (e.g., Unmetered Wi-Fi, Charging).

## 4. CRYPTOGRAPHY, SECURITY & AUTHENTICATION

Absolute privacy is the core requirement. All encryption is client-side.

* **Master Encryption Key:** The Android app generates a 24-word BIP-39 recovery phrase, passed through **Argon2id** (memory-hard KDF) to derive a 256-bit symmetric Master Key. This key is stored in the Android Hardware-Backed Keystore (TEE) and gated by biometrics. Encryption of files is handled via **Google Tink**.
* **MitM Immunity (OOB Pairing):** The Rust server auto-generates a self-signed X.509 certificate and displays its SHA-256 fingerprint as an ANSI block QR code in the SSH terminal. The Android app scans this and uses a custom `X509TrustManager` to pin the cert, instantly destroying connections if the hash doesn't match.
* **Dual-Auth System:**
1. **Primary (Fast Lane): Passkeys (WebAuthn).** Handled via `webauthn-rs` on the server and `CredentialManager` on Android. This allows users to use local keys, YubiKeys, or password managers (like Proton Pass) while bypassing heavy CPU hashing on the legacy Sandy Bridge server. In-flight challenge states are cached in memory via `DashMap`.
2. **Fallback (Heavy Lane): Passwords.** Hashed on the server using **Argon2id** to prevent GPU brute-forcing.


* **Token Hashing:** **Blake3** is used for blinding usernames/tokens. (Note: Android strings must be explicitly converted to UTF-8 via `toByteArray(Charsets.UTF_8)` before hashing to match Rust's memory layout).

## 5. NETWORKING & I/O: THE "ENVELOPE VS. LETTER" ARCHITECTURE

To protect the 10GB RAM limit and optimize CPU cycles, the server explicitly **rejects JSON and Multipart** for file transfers. It uses a "Control Plane vs. Data Plane" split.

* **The Control Plane:** Uses standard JSON for lightweight operations (WebAuthn challenges, signals).
* **The Data Plane (Heavy I/O):** Uses Raw HTTP Body streams (`axum::body::Body`, not `Bytes`).
* **Streaming Mechanics:** * The Android client uses OkHttp with Tink's `StreamingAead` to encrypt and push chunks over the network without loading the file into RAM.
* The Rust server pulls raw bytes from the Arch Linux TCP Receive Buffer and appends them directly to disk via `tokio::fs::File::write_all`.
* Pacing is handled entirely by OS-level TCP Flow Control (Sliding Window), requiring zero application-level code.


* **Metadata Routing:** Because the HTTP body contains only raw binary, metadata is shifted to the "Envelope":
* Auth tokens are passed in the `Authorization: Bearer <token>` header.
* Asset categories are defined by the RESTful URL (e.g., `POST /api/vault/upload/gallery` vs `.../drive`).


* **Bare-Metal Disk Allocation:** To prevent Ext4/Btrfs fragmentation on HDDs, the Rust server reads the `Content-Length` header, enforces hard limits (<10GB), and physically pre-allocates the contiguous blocks on the disk using the `fallocate` syscall (via the `fs4` crate). *(Note: If the underlying OS uses Btrfs, the vault directory must have Copy-On-Write disabled via `chattr +C` for fallocate to work properly).*
* **EOF Security:** If the bytes written exceed `Content-Length`, or if the TCP connection drops prematurely, the server instantly deletes the resulting file, as truncated AES-GCM payloads suffer from MAC authentication failures and become permanent garbage.

## 6. DATABASE & SYNCHRONIZATION (DELTA SYNC)

To sync metadata across multiple devices without corrupting the database ("Last Write Wins" failure), the system uses a Protobuf Delta Sync.

1. **Export:** Android queries its local Room DB for pending records, serializes the Kotlin data classes into Protocol Buffers (via `kotlinx.serialization`), encrypts the byte array using Tink, and uploads it to the server as a raw `application/octet-stream`.
2. **Server Action:** The Axum server receives the encrypted Protobuf and dumps it straight to disk without parsing it.
3. **Merge:** Other Android clients download the raw blob, decrypt it, deserialize the Protobuf, and use Room's `@Insert(onConflict = OnConflictStrategy.REPLACE)` to merge the new manifest into their local SQLite state seamlessly.
