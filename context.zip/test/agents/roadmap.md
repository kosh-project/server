# NAS-rs Development Progress Log

## Purpose Of This Document

This document serves as a historical development log for NAS-rs.

Unlike project.md, which describes the current vision and architecture of the project, this file records:

* Major decisions
* Architectural pivots
* Experiments
* Lessons learned
* Current implementation status
* Rejected ideas
* Future intentions

This document should help future contributors or AI agents understand how the project arrived at its current state.

---

# Initial Project Motivation

The project initially started as a learning exercise.

Primary goals:

* Learn systems programming through Rust
* Learn networking
* Learn storage systems
* Learn server-side architecture
* Build a practical self-hosted application

The original idea was simply:

> Build a NAS server in Rust.

At the time the focus was heavily infrastructure-oriented.

Questions revolved around:

* SMB
* NFS
* Storage protocols
* File serving
* Network interoperability

The project had not yet developed a strong product identity.

---

# Early NAS Research

Several storage protocols were investigated.

These included:

## SMB

The first serious protocol considered.

Reasons:

* Native Windows support
* Linux support
* Android support through file managers
* Familiar NAS workflow

The project initially explored implementing SMB directly in Rust.

After research this idea was abandoned.

Reason:

SMB is an extremely mature and complex protocol.

Reimplementing it would consume enormous development effort while providing little product value.

Decision:

Use Samba for SMB support when needed.

Do not attempt to build an SMB implementation.

---

## NFS

NFS was investigated.

Observations:

* Excellent Linux integration
* Native filesystem semantics
* Strong Unix compatibility

Problems:

* Poor support for ordinary users
* Weak Android experience
* Less suitable for consumer-focused workflows

Decision:

Not a priority.

---

## WebDAV

WebDAV was investigated as a more web-friendly alternative.

Observations:

* HTTP-based
* Easier mobile integration
* Easier remote access
* Better fit for consumer workflows

Conclusion:

Much more aligned with long-term goals than SMB.

However WebDAV itself was eventually deprioritized in favor of building a direct HTTP API.

---

# Major Architectural Pivot

The most significant change in project direction occurred after evaluating real-world usage patterns.

Original thinking:

"How do I expose files?"

New thinking:

"How do users want to interact with files?"

This fundamentally changed the project.

Focus shifted away from:

* Protocols
* Network shares
* Filesystem mounts

Toward:

* User experience
* Upload workflows
* Mobile integration
* Media organization

This marked the transition from:

NAS project

to

Personal storage platform.

---

# Samba Experiment

A real Samba server was configured on an Arch Linux machine.

Objectives:

* Understand SMB behavior
* Evaluate usability
* Determine whether SMB should be core functionality

Steps completed:

* Installed Samba
* Created SMB share
* Configured users
* Tested authentication
* Connected from Linux
* Connected from Android
* Connected from Chromebook

Problems encountered:

* Android clients failed to connect
* Network discovery inconsistencies
* Firewall configuration issues

Investigation eventually revealed:

The nftables firewall was blocking SMB traffic.

Required ports:

TCP:

* 139
* 445

UDP:

* 137
* 138

After updating firewall rules:

SMB connectivity worked successfully.

Lessons learned:

* Most "network" problems are actually firewall problems.
* Samba itself was not the issue.
* SMB is already solved extremely well by existing software.

This experience strongly reinforced the decision not to reimplement SMB.

---

# Product Identity Discovery

One of the most important realizations emerged while evaluating potential users.

Question:

Would non-technical family members use SMB shares?

Answer:

Probably not.

Most users want:

* Upload button
* Gallery
* Timeline
* Photo backup

They do not care about:

* SMB
* NFS
* Mount points
* Network drives

This realization shifted the project toward:

Mobile-first storage.

---

# Gallery Concept Emergence

The project gradually evolved beyond file storage.

Several observations were made:

Users think in:

* Memories
* Photos
* Albums
* Events

Not:

* Directories
* Paths
* Mount points

This led to the introduction of:

Gallery-oriented thinking.

Potential future interfaces:

## Photos

Timeline-based browsing.

## Albums

Collection-based browsing.

## Files

Traditional filesystem browsing.

All views would operate on the same underlying storage.

---

# Google Photos Takeout Insight

One of the strongest project ideas emerged during discussion about cloud migration.

Observation:

Google allows users to export their photos.

However:

The resulting Takeout archive is difficult to use.

Common issues:

* Nested directories
* Sidecar JSON files
* Broken chronology
* Metadata fragmentation

Potential future feature:

Google Photos Takeout Importer

Capabilities:

* Parse archives
* Parse JSON sidecars
* Reconstruct chronology
* Rebuild media timelines
* Recover organization

This became one of the most promising future differentiators.

---

# Storage Architecture Evolution

Initially:

Storage was viewed as files on disk.

Later realization:

Storage consists of two separate concerns.

## Bytes

Stored by filesystem.

## Meaning

Stored by metadata.

This led to the concept of:

Filesystem
+
Metadata Index

rather than relying solely on directory traversal.

---

# Metadata Philosophy

Several future metadata categories were identified.

Examples:

* MIME type
* SHA256 hash
* Upload date
* EXIF date
* Camera information
* GPS coordinates

Important realization:

The filesystem should never become the primary query engine.

Queries should eventually operate through metadata indexes.

---

# Media Asset Model

Another major conceptual shift occurred.

Initially:

Photo = File

Later:

Photo = Asset

Potential future asset structure:

Media Asset

* Original File
* Thumbnail
* Metadata
* Timeline Entry
* Search Index

This mirrors how mature photo platforms operate.

---

# Image Compression Research

Research was conducted into image optimization.

Topics explored:

* Megapixels
* JPEG compression
* WebP
* AVIF
* Image resizing

Important observations:

Resolution reduction often provides greater savings than encoder quality adjustments.

Potential future modes:

Original
Optimized
Space Saver

No implementation exists yet.

---

# Android Client Vision

The Android application became the primary planned user interface.

Current direction:

Single application.

Planned sections:

Photos
Files
Sync
Settings

Earlier ideas involving multiple separate applications were postponed.

Reason:

Single-app development is more realistic for a solo developer.

---

# Security Research

A future zero-knowledge architecture was explored.

Ideas discussed:

* Recovery phrases
* BIP-39
* Argon2id
* AES-GCM
* Client-side encryption
* Manifest encryption

Long-term goal:

Server stores encrypted blobs.

Server should not understand:

* Filenames
* Directory structures
* Media contents

No implementation currently exists.

This remains a future objective.

---

# Backend Technology Selection

Language:

Rust

Framework:

Axum

Reasons:

* Async support
* Strong type system
* Excellent performance
* Clean architecture

Database candidate:

SQLite

Reason:

Simple
Embedded
Sufficient for single-server deployment

No database integration exists yet.

---

# Current Source Architecture

Project currently contains:

* App state abstraction
* Router abstraction
* Upload endpoint
* Logging system

Architecture is transitioning toward:

API Layer
↓
Service Layer
↓
Storage Layer

The project is actively moving away from:

Everything in main.rs

toward maintainable module separation.

---

# First Successful Upload Pipeline

A working upload endpoint was implemented.

Capabilities:

* Accept multipart uploads
* Receive file data
* Write files to disk
* Compute SHA256 hashes

This was the first major milestone.

Future improvements planned:

* Atomic commits
* Temporary upload files
* Better error handling
* Metadata extraction

---

# Lessons Learned So Far

1. Product thinking matters more than protocol thinking.

2. SMB is useful but should not be the center of the project.

3. Metadata is more valuable than raw storage.

4. Gallery experiences are more compelling than filesystem exposure.

5. Migration and organization may become stronger differentiators than storage itself.

6. Architecture quality matters early.

7. Working software beats speculative design.

8. Mobile-first workflows better match intended users.

---

# Current State

Implemented:

* Rust backend
* Axum server
* Multipart uploads
* File persistence
* SHA256 generation
* Application state abstraction
* Initial architecture refactoring

Not Implemented:

* SQLite
* Metadata index
* Authentication
* User management
* Android client
* Gallery APIs
* Synchronization
* Google Takeout imports
* Encryption
* Thumbnail generation

---

# Immediate Next Steps

1. Refactor upload pipeline.
2. Introduce storage service abstraction.
3. Implement SQLite metadata index.
4. Add MIME detection.
5. Create media listing endpoints.
6. Begin gallery-oriented API design.

---

# Current Project Maturity

The project is currently in the foundation-building phase.

The architecture is still evolving.

No public release exists.

No stable API exists.

No client application exists.

The primary objective at this stage is establishing strong architectural foundations before introducing higher-level features.

The project should be considered experimental but directionally stable.

The core vision has largely solidified around:

> Self-hosted personal storage and digital memory infrastructure.
