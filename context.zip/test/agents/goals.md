okay one more goal..

the user can be authenticated and assigned a token, via passkey signing method also
that also doesn't violate the idea of Zero Knowledge vault,
This will be an alternative method, that means, user can be signed in with this
method also,

Also for more convinience, we've to allow the client to provide user the choice...
to generate/save/fetch passkey
- stored via hardware method (locally on same android device)
- stored via software method (stored via password managers or something)
- stored via external device (other android device or security key)


also we'll do things, something like this... 
- User wants to log in via passkey, they send a request an endpoint, lets call it `/api/v1/auth/{user_id}/passkey`
- We make a challenge with webauthn to generate the test in response, and save this test in a cache (dash_map)
- Then user will again make a request after completing the challenge at some other endpoint
- We'll look into dash_map cache... if cache expired, or challenge doesn't meet expected result, user is not authorized
