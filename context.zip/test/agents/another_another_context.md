The following `context.md` captures the complete architectural blueprint, technical specifications, and implementation roadmap established for the Kosh zero-knowledge storage framework to guide your agent.

```markdown
# KOSH Zero-Knowledge Storage Engine: Agent Context & System Blueprint

## 1. System Overview & Core Philosophy

The Kosh framework operates on a **Zero Hardware Trust** model where the backend is treated as an untrusted, hostile environment[cite: 1]. The architecture cleanly decouples metadata orchestration from physical data storage[cite: 1]:

*   **The Server (The "Dumb Bucket"):** Implemented in Rust (Axum, Tokio, SQLx)[cite: 1]. It acts as a blind, append-only repository that persists raw binary payloads without parsing or decrypting filenames, directory structures, or file content[cite: 1].
*   **The Client (The "Brain"):** Implemented in Kotlin/Android[cite: 1]. It executes all cryptographic derivation, CRDT conflict resolution, payload chunking, and local edge operations (e.g., Room database migrations, on-device AI)[cite: 1].
*   **The Map vs. The Territory:**
    *   *The Map (Metadata Plane):* Local SQLite/Room state serialized into Protobuf delta logs and periodic Master Snapshots[cite: 1].
    *   *The Territory (Data Plane):* Physical files encrypted with Google Tink `StreamingAead` stored in a global Content-Addressable Storage (CAS) pool keyed by ciphertext Blake3 hashes[cite: 1].

---

## 2. Server-Side Architecture (Rust / Axum)

### A. Delta Ledger & Disk Actor Pipeline
*   **Single-Writer Actor:** All write operations flow through a bounded Tokio `mpsc` channel (`tokio::sync::mpsc::channel(1000)`) into a dedicated single-threaded Disk Committer Actor to serialize disk I/O and prevent thread contention[cite: 1].
*   **Backpressure Handling:** The bounded channel applies backpressure automatically up to the TCP window, throttling uploads when disk I/O slows and preventing Out-Of-Memory (OOM) failures under heavy concurrency.
*   **RocksDB `CURRENT` Pointer Rotation:**
    *   Delta files follow the naming convention `delta_00001.bin`, `delta_00002.bin`, etc.
    *   The active file pointer is maintained in a 10-byte file named `CURRENT`.
    *   When an active segment hits the size threshold (e.g., 5MB), the Actor writes `delta_0000X` to `CURRENT.tmp` and executes `tokio::fs::rename("CURRENT.tmp", "CURRENT")` for crash-proof $O(1)$ atomic pointer updates without directory scanning.
*   **Header Format:** Each `.bin` file reserves an immutable 500-byte header:
    *   Bytes 0–3: Magic bytes (`KOSH`).
    *   Bytes 4–5: Schema Version (`0x0001`).
    *   Bytes 6–9: `previous_id` (e.g., `4`).
    *   Bytes 10–499: Zero-padded for future recovery flags.
    *   *Note:* The server strips this 500-byte internal header before streaming delta blocks to the client.
*   **Write-Back Journaling:** Delta writes acknowledge clients immediately upon writing to the OS page cache. Heavy disk synchronization (`file.sync_data()`) is deferred to periodic timers, buffer saturation, destructive operations, or graceful shutdown signals (`SIGINT`/`SIGTERM`)[cite: 1].

### B. Sync, Compaction & High-Water Mark Pruning
*   **Read Path (Sync):** Clients request deltas via `GET /api/v1/sync/delta?offset=X`. Axum translates global byte offsets to segment files and zero-copy streams `[u32 Length][Encrypted Payload]` blocks using `ReaderStream`[cite: 1].
*   **Compaction Read Trigger:** When a client requests an offset that has already been pruned, Axum returns HTTP `410 Gone` / `416 Range Not Satisfiable`. The client catches this and pivots to `GET /api/v1/sync/snapshot`.
*   **Atomic Prune Path:**
    *   The client generates a compacted Master Snapshot and uploads it via `POST /api/v1/sync/snapshot` with the header `X-Snapshot-Inclusive-Offset: <offset>`.
    *   Axum writes `snapshot_v2.bin` and instructs the Committer Actor to delete only segment files whose byte boundaries fall strictly *below* the inclusive offset, preserving any concurrent uploads appended by other devices.

### C. CAS Data Plane & Upload Resumption
*   **Contiguous Disk Persistence:** Every blob is stored as a single, contiguous binary file on disk (no scattered 256KB HAMT chunk files).
*   **Path Sharding:** Blobs in `/vault/cas/` must be sharded by hash prefixes (`/vault/cas/ab/cd/abcdef1234...`) via `resolve_blob_path()` to preserve Ext4 `htree` lookup speeds at scale.
*   **Resumable Upload Staging:**
    *   Incomplete uploads are written to `/vault/cas/.staging/{upload_id}`.
    *   Clients query upload progress via `GET /cas/upload/status/{upload_id}`.
    *   Resumption snaps strictly to segment boundaries (e.g., 1MB–4MB intervals). Once completed, the file is atomically moved to its final CAS hash destination via `tokio::fs::rename`.

### D. Zero-Knowledge Garbage Collection (ZK-GC)
*   **Reachability Manifest:** Because the server cannot decrypt the snapshot, the client uploads a plaintext list of all referenced active Blake3 hashes during compaction.
*   **Ownership Ledger:** Axum maintains a server-side relational mapping `(blob_uuid, user_id)` to isolate user sweeps and prevent cross-tenant hash manipulation.
*   **Ext4 Quarantine Mechanism:**
    *   Orphaned blobs (present on disk/ownership table but missing from the client manifest) are not deleted immediately.
    *   Axum moves orphaned blobs to `/vault/cas/.quarantine/` via `rename` ($O(1)$) and tags them with a 30-day Time-To-Live (TTL).
    *   A background chron-job permanently unlinks files only after the 30-day quarantine period expires, enabling full cryptographic rollbacks if a rogue client submits an invalid manifest.
    *   GC sweeps ignore blobs created within the last 24 hours to protect in-flight concurrent uploads.

---

## 3. Client-Side Architecture (Android / Kotlin)

### A. Cryptographic Pipeline (Google Tink)
*   **Envelope Encryption:**
    *   Key Encryption Key (KEK): Derived from user credentials using Argon2id/HKDF; never touches the network.
    *   Data Encryption Key (DEK): Random 256-bit key generated per file, encrypted by the KEK, and stored inside the local SQLite metadata schema.
*   **Streaming AEAD:** Uses Google Tink's `StreamingAead` (AES-GCM-HKDF) with segment nonces derived from `(Stream_Header_Salt, Segment_Index)`[cite: 1].
*   **Memory Footprint:** Plaintext and ciphertext streams are wrapped directly using `streamingAead.newEncryptingStream()` and `streamingAead.newDecryptingStream()` to stream multi-gigabyte files within minimal heap memory[cite: 1].

### B. CRDT Monotonicity & Replay Defense
*   **Lamport Clocks:** Every metadata mutation carries a monotonic `(lamport_clock, device_id)`. Local Room database writes enforce updates using:
    ```sql
    WHERE excluded.lamport_clock > nodes.lamport_clock
    ```
*   **Action Idempotency:** Each delta action contains an `action_uuid`. The client logs executed UUIDs in an `applied_actions` table within the same transaction to discard replayed ciphertext attacks.

### C. OS Background Execution
*   **Foreground Services:** User-initiated large file uploads and downloads must be managed inside a `Foreground Service` bound to an ongoing notification to prevent Android's `ActivityManager` and Doze mode from severing TCP sockets or killing coroutines.
*   **WorkManager Usage:** Reserved strictly for deferrable background jobs (e.g., periodic CRDT sync merges, offline Reachability Manifest generation, local quantized ML face clustering) gated by `requiresCharging()` and `requiresDeviceIdle()`.

---

## 4. Current Codebase Implementation Status


```

webdav-server/
├── crates/
│   ├── cli/             # Terminal TUI harness for ledger/state inspection (85% complete)
│   └── server/
│       ├── src/
│       │   ├── api/
│       │   │   ├── assets.rs       # CAS endpoints (Needs resumable staging & range seeks)
│       │   │   ├── sync.rs         # Delta sync (Needs snapshot inclusive pruning integration)
│       │   │   ├── middleware/     # JWT Auth guards and request logging (Complete)
│       │   │   └── route.rs        # Axum router setup (Complete)
│       │   ├── storage/
│       │   │   ├── file.rs         # CAS I/O (Needs prefix path sharding: /cas/ab/cd/hash)
│       │   │   ├── service.rs      # High-level storage orchestration (Needs ZK-GC Actor)
│       │   │   └── ledger/
│       │   │       ├── committer.rs # Disk Committer Actor (Single-writer channel in place)
│       │   │       ├── segment.rs   # Delta segment management (Needs RocksDB CURRENT rename)
│       │   │       └── handle.rs    # Ledger handle interface
│       │   └── logger/             # Custom structured logging framework (Complete)

```

---

## 5. Agent Directive & Next Steps

When generating or modifying code for this repository, the agent must adhere to the following rules:

1.  **Strict Zero-Knowledge Boundary:** Never introduce server-side logic that expects plaintext metadata, file names, or client operational preferences[cite: 1].
2.  **Append-Only Invariance:** Never mutate existing delta logs in-place; all state transitions occur via log rotation or atomic pointer swaps.
3.  **Path Resolution:** Always route CAS storage operations through sharded paths (`/cas/xx/yy/uuid`) rather than placing flat files in the root folder.
4.  **Inclusive Compaction:** Always bind snapshot pruning to explicit byte offsets (`X-Snapshot-Inclusive-Offset`) to prevent data loss across concurrent clients.
5.  **Defensive GC:** Never allow clients to execute immediate physical file unlinks; always stage logical deletions through the 30-day quarantine workflow.

```
