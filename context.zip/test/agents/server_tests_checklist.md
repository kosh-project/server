# Server Crate — Complete Test Coverage Checklist

This file lists every test that should exist in `crates/server`.
Tests marked with ✅ already pass. Everything else is `[ ]` — your job.

Organized by module, then by concern. Each entry shows the test name and what it proves.

---

## `model/user.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `user_create_succeeds` | `User::create()` inserts a new row without error |
| `[ ]` | `user_create_duplicate_returns_unique_violation` | Inserting the same `identity_hash` twice returns `sqlx::Error::Database` with a unique constraint violation |
| `[ ]` | `user_verify_correct_credentials_returns_user_id` | `User::verify()` returns `Some(id)` when both `identity_hash` and `auth_verifier` match |
| `[ ]` | `user_verify_wrong_auth_verifier_returns_none` | `User::verify()` returns `None` (not an error) when the verifier is wrong — proves the server does not leak "user exists" information |
| `[ ]` | `user_verify_nonexistent_identity_hash_returns_none` | `User::verify()` returns `None` when no user with that hash exists |

---

## `model/session.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `session_create_returns_uuid_string` | `Session::create()` returns a non-empty UUID v4 string |
| `[ ]` | `session_create_stores_blake3_hash_not_raw_token` | After `Session::create()`, the raw token is NOT in the `sessions` table — only its BLAKE3 hash is |
| `[ ]` | `session_create_sets_correct_expiry` | `expires_at` is set to `created_at + 30 days` |
| `[ ]` | `session_verify_valid_token_returns_session` | `Session::verify()` returns `Some(session)` for a freshly created token |
| `[ ]` | `session_verify_wrong_token_returns_none` | `Session::verify()` returns `None` for a random byte hash that was never inserted |
| `[ ]` | `session_verify_expired_session_returns_none` | `Session::verify()` returns `None` for a session whose `expires_at` is in the past — proves the expiry check actually works |

---

## `model/asset.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `delete_asset_with_single_owner` | Ref count hits 0 → `delete()` returns `true` (caller must wipe blob) |
| ✅ | `delete_asset_with_more_than_one_owners` | Other owners still exist → `delete()` returns `false` (blob preserved) |
| ✅ | `attempt_to_delete_unowned_asset` | Non-owner cannot delete → `delete()` returns `false` |
| `[ ]` | `asset_create_succeeds_for_all_tag_variants` | `Asset::create()` works correctly for all four `AssetTag` values: `GalleryMeta`, `GalleryItem`, `DriveMeta`, `DriveItem` |
| `[ ]` | `asset_owned_by_returns_true_for_owner` | `Asset::owned_by()` returns `true` when the user owns the hash |
| `[ ]` | `asset_owned_by_returns_false_for_non_owner` | `Asset::owned_by()` returns `false` when a different user tries to claim ownership |
| `[ ]` | `asset_owned_by_returns_false_for_nonexistent_hash` | `Asset::owned_by()` returns `false` when the hash does not exist at all |
| `[ ]` | `concurrent_delete_by_two_users_only_wipes_once` | Two users `delete()` the same hash simultaneously — exactly one gets `true` (wipe needed) and one gets `false`, and the physical blob is removed exactly once |

---

## `model/asset.rs` — `AssetTag` parsing

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `asset_tag_parses_all_valid_variants` | `"0"` → `GalleryMeta`, `"1"` → `GalleryItem`, `"2"` → `DriveMeta`, `"3"` → `DriveItem` |
| `[ ]` | `asset_tag_rejects_unknown_string` | `"99"` or `"photo"` or `""` all return `Err(())` |

---

## `storage/transaction.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `successful_commit_and_hash` | Full commit: file written, hash returned |
| ✅ | `zero_byte_stream_creates_empty_file` | 0-byte upload succeeds and file exists on disk |
| ✅ | `aborted_test_cleans_up_garbage` | Mid-stream connection abort deletes the temp staging file |
| ✅ | `transaction_fails_if_vault_missing` | Returns `CreateTempFile` error when the vault directory does not exist |
| ✅ | `hardcoded_hash_correctness` | BLAKE3("hello world") matches the pre-calculated expected hash |
| ✅ | `mismatch_content_fails_plus_cleans_up` | Content-Length mismatch (premature EOF) fails and cleans up |
| `[ ]` | `large_stream_hashes_correctly` | A 10MB stream produces the correct BLAKE3 hash (proves chunked hashing is not broken) |
| `[ ]` | `commit_produces_final_file_not_temp_file` | After a successful commit, the `.tmp` file is gone and the final CAS file exists at `vault/{hash}` |

---

## `storage/service.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `validation_success` | Valid filename + existing vault passes pre-flight check |
| ✅ | `reject_invalid_filename` | Filenames containing `/` or `\` are rejected with `InvalidFileName` |
| ✅ | `validation_rejects_existing_file` | Duplicate filename is rejected |
| ✅ | `concurrent_write_collisions_dont_panic` | Two identical concurrent uploads resolve safely via CAS dedup |
| `[ ]` | `get_blob_returns_file_for_existing_hash` | `get_blob()` returns a readable file handle for an existing blob |
| `[ ]` | `get_blob_returns_not_found_for_missing_hash` | `get_blob()` returns `storage::Error::NotFound` for a hash that was never committed |
| `[ ]` | `delete_blob_removes_file_from_vault` | `delete_blob()` physically removes the file from the vault directory |
| `[ ]` | `delete_blob_on_nonexistent_hash_does_not_panic` | `delete_blob()` on a hash that does not exist either returns `Ok(())` or `NotFound`, and does NOT panic |
| `[ ]` | `path_traversal_attack_rejected` | A filename like `../../etc/passwd` is rejected before reaching the filesystem |
| `[ ]` | `empty_filename_rejected` | An empty string as filename is rejected |

---

## `api/middleware/auth_guard.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `auth_guard_bypasses_db_on_cache_hit` | Moka cache is checked before hitting SQLite |
| `[ ]` | `auth_guard_rejects_missing_authorization_header` | Request with no `Authorization` header gets `401 Unauthorized` |
| `[ ]` | `auth_guard_rejects_malformed_bearer_prefix` | Token like `"Token abc123"` (not `"Bearer abc123"`) gets `401 Unauthorized` |
| `[ ]` | `auth_guard_rejects_invalid_token_via_db_path` | A completely fabricated token (not in DB) gets `401 Unauthorized`, proving the DB fallback path works correctly |
| `[ ]` | `auth_guard_rejects_expired_session` | A token that exists in the DB but whose `expires_at` is in the past gets `401 Unauthorized` |
| `[ ]` | `auth_guard_accepts_valid_token_via_db_path` | A real valid token (not in cache) is looked up in the DB, user_id is injected into extensions, and the request proceeds (proves the DB path, not just the cache path) |
| `[ ]` | `auth_guard_caches_verified_token_after_db_lookup` | After the first successful DB lookup, the token hash is stored in the Moka cache, so a second request does NOT hit the DB again |

---

## `api/auth/register.rs` (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `register_valid_user_returns_201` | A well-formed registration request returns `201 Created` |
| `[ ]` | `register_duplicate_identity_hash_returns_409` | Registering the same `identity_hash` twice returns `409 Conflict` — this is the most critical HTTP-level security test for the auth flow |
| `[ ]` | `register_invalid_hex_identity_hash_returns_400` | Sending `"identity_hash": "not_hex!!!"` returns `400 Bad Request` |
| `[ ]` | `register_missing_identity_hash_field_returns_400` | A JSON body missing the `identity_hash` key entirely returns `400 Bad Request` |
| `[ ]` | `register_missing_auth_verifier_field_returns_400` | A JSON body missing `auth_verifier` returns `400 Bad Request` |
| `[ ]` | `register_empty_body_returns_400` | Sending an empty body returns `400 Bad Request` (not `500`) |

---

## `api/auth/login.rs` (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `login_valid_credentials_returns_200_with_token` | Correct `identity_hash` + `auth_verifier` returns `200 OK` with a `{ "token": "..." }` JSON body |
| `[ ]` | `login_returns_token_that_is_non_empty_string` | The returned token string is not empty and is a valid UUID format |
| `[ ]` | `login_wrong_auth_verifier_returns_401` | Correct `identity_hash` but wrong `auth_verifier` returns `401 Unauthorized` — proves the verifier check actually fires |
| `[ ]` | `login_nonexistent_identity_hash_returns_401` | An `identity_hash` that was never registered returns `401 Unauthorized` (not 404, not 500) |
| `[ ]` | `login_invalid_hex_identity_hash_returns_400` | Sending `"identity_hash": "xyz!!!"` returns `400 Bad Request` |
| `[ ]` | `login_missing_fields_returns_400` | A malformed or empty JSON body returns `400 Bad Request` |

---

## `api/assets.rs` — Upload (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `test_multipart_upload_integrity` | Full pipeline: upload 1MB random bytes, verify bytes on disk match exactly |
| `[ ]` | `upload_missing_x_file_name_header_returns_400` | Request without the `X-File-Name` header returns `400 Bad Request` |
| `[ ]` | `upload_missing_content_length_header_returns_400` | Request without a `Content-Length` header returns `400 Bad Request` |
| `[ ]` | `upload_invalid_tag_in_path_returns_400` | Path `/api/v1/upload/99` (invalid tag) returns `400 Bad Request` |
| `[ ]` | `upload_unauthenticated_returns_401` | Request without a Bearer token returns `401 Unauthorized` |
| `[ ]` | `upload_registers_asset_ownership_in_database` | After upload, `Asset::owned_by()` returns `true` for the uploading user |
| `[ ]` | `upload_duplicate_content_returns_same_hash` | Uploading the same bytes twice returns the same BLAKE3 hash both times (proves CAS dedup at the HTTP level) |
| `[ ]` | `upload_content_length_over_10gb_returns_400` | `Content-Length: 10000000001` returns `400 Bad Request` without actually streaming anything |

---

## `api/assets.rs` — Download (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `download_owned_asset_returns_200_with_correct_bytes` | User downloads their own asset and receives the exact bytes they uploaded |
| `[ ]` | `download_sets_correct_content_type_header` | Response has `Content-Type: application/octet-stream` |
| `[ ]` | `download_cross_user_access_returns_404` | User A uploads a file. User B tries to download it by guessing the hash. Gets `404 Not Found` (not `403`, by design) |
| `[ ]` | `download_nonexistent_hash_returns_404` | A random valid-hex hash that was never uploaded returns `404 Not Found` |
| `[ ]` | `download_invalid_hex_hash_returns_400` | A path like `/api/v1/assets/not-hex!!!` returns `400 Bad Request` |
| `[ ]` | `download_unauthenticated_returns_401` | Request without a Bearer token returns `401 Unauthorized` |

---

## `api/assets.rs` — Delete (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `delete_owned_asset_returns_204` | Owner deletes their asset and receives `204 No Content` |
| `[ ]` | `delete_single_owner_wipes_blob_from_vault` | After deletion with one owner, the physical blob file no longer exists on disk |
| `[ ]` | `delete_with_multiple_owners_preserves_blob` | User A and User B both own the same blob. User A deletes. The blob still exists on disk for User B |
| `[ ]` | `delete_cross_user_returns_204_but_no_db_change` | User B tries to delete User A's asset. Returns `204` (no error, nothing leaked) but the asset record in the DB is untouched — proves the ownership check in `Asset::delete()` works |
| `[ ]` | `delete_nonexistent_hash_returns_204` | Deleting a hash that was never uploaded returns `204 No Content` (idempotent) — important for client retry logic |
| `[ ]` | `delete_invalid_hex_hash_returns_400` | A malformed hex hash in the path returns `400 Bad Request` |
| `[ ]` | `delete_unauthenticated_returns_401` | Request without a Bearer token returns `401 Unauthorized` |

---

## `api/route.rs` — General Route Behavior (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `quick_dev` | `/health` and `/storage` respond correctly (smoke test) |
| `[ ]` | `health_endpoint_returns_correct_json` | `GET /health` returns `200 OK` with `{ "health": "ok" }` |
| `[ ]` | `storage_endpoint_requires_auth` | `GET /api/v1/storage` without a Bearer token returns `401 Unauthorized` |
| `[ ]` | `unknown_route_returns_404` | A request to a path that doesn't exist (e.g. `/api/v1/unicorn`) returns `404 Not Found` |
| `[ ]` | `protected_routes_reject_unauthenticated_requests` | Every protected endpoint (`/upload`, `/assets`) returns `401` without authentication |

---

## `logger/service.rs`

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| ✅ | `logger_commits_multiple_entries_to_disk` | Sequential bincode framing is correct; entries are independently deserializable |
| ✅ | `broadcasting_works_via_unix_socket` | Bincode bytes are broadcast to `/tmp/kosh-cli.sock` |
| ✅ | `file_rotation_on_every_new_day` | Two logs with different dates produce two separate `.bin` files |
| `[ ]` | `graceful_shutdown_flushes_all_pending_entries` | After sending `Level::Shutdown`, the logger finishes writing all queued entries before the task exits |
| `[ ]` | `log_entries_deserialize_with_correct_fields` | A log entry written to disk deserializes back to the exact same `Entry` struct (module, level, message, timestamp all match) |

---

## `error/` — Error Sanitization (HTTP integration)

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `internal_storage_error_returns_500_without_leaking_details` | A storage layer failure returns `500 Internal Server Error` with no internal message in the body |
| `[ ]` | `internal_db_error_returns_500_without_leaking_details` | A database failure returns `500 Internal Server Error` with no SQL error message in the body |
| `[ ]` | `conflict_error_returns_409` | `crate::Error::Conflict` returns `409 Conflict` |
| `[ ]` | `api_bad_request_returns_400_with_message` | `api::Error::BadRequest("some reason")` returns `400` with `"some reason"` in the body (safe to expose) |
| `[ ]` | `api_unauthorized_returns_401_with_message` | `api::Error::Unauthorized("reason")` returns `401` with `"reason"` in the body |

---

## Full End-to-End Flow Tests (integration)

These test entire user journeys, not just individual endpoints.

| Status | Test Name | What it proves |
|--------|-----------|----------------|
| `[ ]` | `full_register_login_upload_download_delete_flow` | The complete lifecycle: register → login → upload → download → verify bytes match → delete → verify blob gone from disk |
| `[ ]` | `two_users_share_blob_independent_ownership` | User A and User B upload identical bytes. Both own it. User A deletes. User B can still download. User B deletes. Blob is gone from disk. |
| `[ ]` | `token_obtained_from_login_works_on_protected_endpoints` | The token returned by `/api/auth/login` can immediately be used to call `/api/v1/upload` and `/api/v1/assets` |
| `[ ]` | `session_token_is_invalidated_after_expiry` | A token that has expired cannot authenticate requests (requires manipulating `expires_at` directly in the DB) |

---

## Test Count Summary

| Category | Already Passing | Still Needed |
|----------|----------------|--------------|
| `model/user` | 0 | 5 |
| `model/session` | 0 | 6 |
| `model/asset` | 3 | 5 |
| `model/asset` — AssetTag | 0 | 2 |
| `storage/transaction` | 6 | 2 |
| `storage/service` | 4 | 6 |
| `api/middleware/auth_guard` | 1 | 6 |
| `api/auth/register` (HTTP) | 0 | 6 |
| `api/auth/login` (HTTP) | 0 | 6 |
| `api/assets` — upload (HTTP) | 1 | 7 |
| `api/assets` — download (HTTP) | 0 | 6 |
| `api/assets` — delete (HTTP) | 0 | 7 |
| `api/route` (HTTP) | 1 | 4 |
| `logger/service` | 3 | 2 |
| `error` — sanitization (HTTP) | 0 | 5 |
| End-to-end flows | 0 | 4 |
| **Total** | **19** | **79** |

